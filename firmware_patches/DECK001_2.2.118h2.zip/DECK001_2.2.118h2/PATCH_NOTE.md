# Patch 2.2.118h2: Pulse beat grid (+ the 2.2.118h sync fix)

Based on: DECK001 v2.2.118 source ZIP. Includes patch 2.2.118h unchanged (exact BPM through DECK LINK,
`player.cpp` + `deck_link.cpp`), so apply this instead of 2.2.118h, not on top of it.
New dependencies: none (plain C++17, no libraries; ~1.2 MB of weights as a header).

## What changed
1. **New analyser, Pulse** (`pulse_beat.h/.cpp`, `pulse_weights.h`): a small neural beat / downbeat tracker
   (81 k parameters, distilled from the Beat This! research model and fine-tuned on 820 hand-annotated DJ
   tracks), then one straight tempo + phase line through its beats, then the bar line. No tempo range cap
   in the network; the result is folded into the deck's 60-200 BPM range (half / double time).
2. **`beat_grid.cpp`**: `estimateBeatGrid()` runs Pulse on `song.pcmStereo` first. The old analyser
   (unchanged, now `estimateBeatGridLegacy`) runs only when Pulse finds no steady tempo (<60 % of its beats on
   one line), the track is < 25 s, or `DECK001_BEAT_ANALYZER=legacy` is set.
   - `firstBeatSeconds` is now **the bar line (beat 1)**: the first downbeat at or after 0 s (moved back one
     bar if > 3 s, for the cache's +-3 s check).
   - `bpm` is snapped to a whole BPM when Pulse's tempo is within 0.02 BPM of it (phase refitted for the whole
     BPM); `rawBpm` keeps the fitted value.
   - `confidence` = 0.5 + 0.5 x (share of beats on the line - 0.6) / 0.3, so 0.5-1.0 for every Pulse grid
     (>= 0.5 = DECK LINK "reliable").
   - GRID RESET (UI thread) reuses the last 8 Pulse results per decoded track, so it stays instant.
   - `DECK001_MUSICAL_DIAG=1` prints a `BEAT ANALYSIS pulse ...` line.
3. **`beat_grid_cache.cpp`**: cache format 3 -> 4, so automatic grids from older firmware are re-analysed
   once with Pulse. MANUAL grids from v2 and v3 caches are kept (user corrections never lost).
4. **Makefile**: `pulse_beat.cpp` in SOURCES and SEAMLESS_LIVE_SOURCES; `pulse_beat.o` built with
   `-O3 -ffast-math` (about 2.5x faster than -O2; changes logits by < 2e-5).
5. **Tests**: new `tests/run_pulse_v22118h2.sh` (C++ log-mel and network vs the PyTorch reference, a
   synthetic 128-BPM grid). Test scripts that link `beat_grid.cpp` now also link `pulse_beat.cpp`;
   `test_bpm_cache_migration_v22113.cpp` checks v2 and v3 caches against format 4.

## Results (200 DJ tracks with hand-marked beats, none used in training)
House, techno, trance, drum & bass (Raveform dataset). End to end through the patched `beat_grid.cpp`
(built as a PC tool, same code):

| | v2.2.118 | **2.2.118h2** |
|---|---|---|
| Tempo right (not half / double / 3:2) | 158 / 195 (81 %) | **193 / 195 (99 %)** |
| Grid offset from the beats, median | 7.0 ms | **3.2 ms** |
| Grid more than 20 ms off | 32 % of tracks | **16 %** |
| Bar line on the human downbeats | 75 % | **87 %** |
| Tracks with > 90 % of bar lines right | 75 % | **87 %** |
| Grids marked reliable (confidence >= 0.5) | 18 % | 100 % (see note) |

Note on confidence: v2.2.118 marks only 18 % of these grids as reliable, so DECK LINK treats most real tracks
as unreliable today. 2.2.118h2 marks every steady Pulse grid reliable, including the 2 of 195 with a wrong
tempo family. If a stricter gate is wanted, `beatPeaks` / `onGridShare` / `barPhaseShare` in
`PulseBeat::Result` are the inputs to tune it.

Bar line = the share of the human-marked downbeats that the grid's bar line hits (+-70 ms). v2.2.118 makes
no downbeat claim; its first beat is often the first kick, which is often beat 1.

## Speed
Pulse costs 4.9 ms per second of audio on one PC core (Windows, incl. reading the file), against
0.4 ms for the old analyser: about 1.9 s for a 6.5-min track instead of 0.15 s. This runs where the old analyser ran (track preparation / analysis thread), and the
result is cached per file. **Needs measuring on the Pi**: a Pi 5 should be 2-3x slower than the PC per core,
so a few seconds per new track. If that is too slow, the network is the part to thread or shrink.

## What was verified
- `sh tests/run_fast_v22118.sh` and `sh tests/run_integration_v22118.sh`: all PASS (Linux x86-64, g++).
- `2.2.118h2.diff` applied with `patch -p1` to a clean v2.2.118 tree gives exactly the files in `src/`.
- `sh tests/run_pulse_v22118h2.sh`: PASS (log-mel max error 4e-4, logits 1e-5 vs PyTorch).
- The table above: the patched `beat_grid.cpp` + `pulse_beat.cpp` built on Windows (w64devkit g++), on decoded
  real tracks.

## Not verified
- Not built as the full firmware on the Pi, not run on the Pi, no Pi timing.
- Not listened to on the decks: grid placement on screen, Seamless / AUTO PILOT, BEAT sync with the new
  bar-line anchor, GRID RESET timing.
- DECK LINK part: same as 2.2.118h (protocol 3; both decks must run it).

## How to try it
1. On the Mac (Pi offline): copy `src/` over a clean v2.2.118 tree (or `patch -p1 < 2.2.118h2.diff`, then copy
   `src/tests/fixtures/pulse/*.f32`, the two binary test fixtures the diff can't carry), run the tests
   above, build, install on both decks.
2. Load tracks you know: BPM, grid lines on the kicks, and the bar line on beat 1 (first kick after a
   breakdown, start of a phrase). Compare with `DECK001_BEAT_ANALYZER=legacy`.
3. Note the load-to-grid time on the Pi for a 6-7 min track (`DECK001_MUSICAL_DIAG=1` shows when the
   `BEAT ANALYSIS pulse` line appears).
