#include "beat_grid_cache.h"
#include "mp3_waveform.h"
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <chrono>
#include <limits>
#include <string>
#include <system_error>

namespace {
namespace fs=std::filesystem;
constexpr int kCacheFormat=4;   // 4: v2.2.118h2 Pulse grids (bar-line anchor); v2/v3 automatic grids re-analysed
std::uint64_t hashPath(const std::string& s) {
    std::uint64_t h=14695981039346656037ULL;
    for(unsigned char c:s){ h^=c;h*=1099511628211ULL; }
    return h;
}
fs::path cachePath(const std::string& filename) {
    const fs::path source=fs::absolute(filename).lexically_normal();
    std::ostringstream name;
    name<<std::hex<<std::setfill('0')<<std::setw(16)<<hashPath(source.string())<<".grid";
    return fs::path(std::getenv("DECK001_CACHE_ROOT")?std::getenv("DECK001_CACHE_ROOT"):
                    "/home/toomom/DECK001/cache")/name.str();
}
bool attributes(const std::string& path,std::uintmax_t& size,std::int64_t& stamp) {
    std::error_code ec;
    size=fs::file_size(path,ec);if(ec)return false;
    const auto time=fs::last_write_time(path,ec);if(ec)return false;
    stamp=std::chrono::duration_cast<std::chrono::nanoseconds>(time.time_since_epoch()).count();
    return true;
}
}
bool loadBeatGridCache(const std::string& filename,BeatGrid& grid) {
    std::uintmax_t size=0;std::int64_t timestamp=0;
    if(!attributes(filename,size,timestamp))return false;
    std::ifstream in(cachePath(filename));
    int version=0;std::uintmax_t oldSize=0;std::int64_t oldTime=0;
    BeatGrid tmp;
    int estimated=0,manual=0,snapped=0;
    if(!(in>>version>>oldSize>>oldTime>>tmp.bpm>>tmp.rawBpm>>tmp.firstBeatSeconds
          >>tmp.confidence>>estimated>>manual>>snapped))return false;
    // Reanalyze old AUTOMATIC v2 caches because v3 confidence now includes
    // tempo competition and onset evidence. Keep v2 MANUAL grids valid so
    // user corrections are never lost during a firmware update.
    // v2.2.118h2: automatic v3 grids are re-analysed with Pulse; MANUAL v2/v3 grids stay (user corrections).
    if((version!=kCacheFormat && !((version==2 || version==3) && manual!=0)) ||
       size!=oldSize || timestamp!=oldTime)return false;
    if(!std::isfinite(tmp.bpm)||tmp.bpm<60||tmp.bpm>220||
       !std::isfinite(tmp.rawBpm)||!std::isfinite(tmp.firstBeatSeconds)||
       !std::isfinite(tmp.confidence)||tmp.confidence<0||tmp.confidence>1 ||
       tmp.firstBeatSeconds< -3.0||tmp.firstBeatSeconds>3.0 || estimated!=1)return false;
    tmp.estimated=true;tmp.fromCache=true;tmp.manual=(manual!=0);tmp.integerTempoSelected=(snapped!=0);
    grid=tmp;
    return true;
}
bool saveBeatGridCache(const std::string& filename,const BeatGrid& grid) {
    if(!grid.estimated || !std::isfinite(grid.bpm)||!std::isfinite(grid.firstBeatSeconds))return false;
    std::uintmax_t size=0;std::int64_t timestamp=0;
    if(!attributes(filename,size,timestamp))return false;
    const auto target=cachePath(filename);
    std::error_code ec;fs::create_directories(target.parent_path(),ec);if(ec)return false;
    const auto temporary=target.string()+".tmp";
    {
        std::ofstream out(temporary,std::ios::trunc);
        if(!out)return false;
        out<<std::setprecision(17)<<kCacheFormat<<' '<<size<<' '<<timestamp<<' '
           <<grid.bpm<<' '<<grid.rawBpm<<' '<<grid.firstBeatSeconds<<' '
           <<grid.confidence<<' '<<int(grid.estimated)<<' '<<int(grid.manual)
           <<' '<<int(grid.integerTempoSelected)<<'\n';
        out.flush();if(!out)return false;
    }
    fs::rename(temporary,target,ec);
    if(ec){fs::remove(temporary);return false;}
    return true;
}
void clearBeatGridCache(const std::string& filename) {
    std::error_code ec;fs::remove(cachePath(filename),ec);
}

std::string legacyBeatGridFilePath(const std::string& path){return cachePath(path).string();}
