#pragma once
struct Mp3Waveform;
// v2.2.118h2: Pulse (pulse_beat.h) gives tempo, phase and the bar line (firstBeatSeconds = a downbeat when
// the track has clear bars); the original onset autocorrelation is the fallback for tracks without a steady
// tempo, or for every track with DECK001_BEAT_ANALYZER=legacy.
void estimateBeatGrid(Mp3Waveform& song);
