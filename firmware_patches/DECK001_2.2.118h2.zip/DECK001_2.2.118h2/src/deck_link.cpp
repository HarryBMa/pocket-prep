#include "deck_link.h"
#include "musical_timing.h"
#include "deck_link_phase.h"
#include "deck_link_election.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <cstdio>
#include <string>
#include "deck_link_capabilities.h"
#include "deck_link_transfer_scheduler.h"
#include <cerrno>
#include <unistd.h>
#include <limits>

namespace DeckLink {
namespace {
constexpr std::array<std::uint8_t,8> kMagic{{'D','E','C','K','0','0','1','L'}};
constexpr std::uint8_t kProtocol=3; // 3: BPM sent in 1e-5 BPM (was 0.1); both decks must run it
// A 10ms timing packet is 160B (~128 kbit/s for eight transmitters), far
// below Gigabit Ethernet capacity. Only the non-audio worker sends packets.
constexpr auto kHeartbeat=std::chrono::milliseconds(10);
constexpr auto kPeerGrace=std::chrono::milliseconds(5000);
constexpr auto kPhaseFresh=std::chrono::milliseconds(500);
constexpr auto kRetry=std::chrono::milliseconds(100);
constexpr auto kTimingPeriod=std::chrono::milliseconds(500);
constexpr auto kTimingFresh=std::chrono::seconds(3);
std::uint64_t monotonicUs() noexcept {
    return static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::microseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count());
}
bool supports90(const DeckLink::Message& m) noexcept {
    return DeckLinkCapabilities::atLeast({m.major,m.minor,m.patch},2,2,90);
}
bool supports105(const DeckLink::Message& m) noexcept {
    return DeckLinkCapabilities::atLeast({m.major,m.minor,m.patch},2,2,105);
}
bool supports100(const DeckLink::Message& m) noexcept {
    return DeckLinkCapabilities::atLeast({m.major,m.minor,m.patch},2,2,100);
}
bool supports99(const DeckLink::Message& m) noexcept {
    return DeckLinkCapabilities::atLeast({m.major,m.minor,m.patch},2,2,99);
}
bool supports97(const DeckLink::Message& m) noexcept {
    return DeckLinkCapabilities::atLeast({m.major,m.minor,m.patch},2,2,97);
}
bool supports92(const DeckLink::Message& m) noexcept {
    return DeckLinkCapabilities::atLeast({m.major,m.minor,m.patch},2,2,92);
}
bool supports91(const DeckLink::Message& m) noexcept {
    return DeckLinkCapabilities::atLeast({m.major,m.minor,m.patch},2,2,91);
}
bool supportsTiming(const DeckLink::Message& m) noexcept {
    return DeckLinkCapabilities::atLeast({m.major,m.minor,m.patch},2,2,89);
}
void write64(std::uint8_t* p,std::uint64_t value) noexcept {
    for(int i=7;i>=0;--i){p[i]=static_cast<std::uint8_t>(value&0xff);value>>=8;}
}
std::uint64_t read64(const std::uint8_t* p) noexcept {
    std::uint64_t result=0;
    for(int i=0;i<8;++i)result=(result<<8)|p[i];
    return result;
}
void write32(std::uint8_t* p,std::uint32_t value) noexcept {
    for(int i=3;i>=0;--i){p[i]=static_cast<std::uint8_t>(value&0xff);value>>=8;}
}
std::uint32_t read32(const std::uint8_t* p) noexcept {
    std::uint32_t value=0;
    for(int i=0;i<4;++i)value=(value<<8)|p[i];
    return value;
}
std::uint64_t identity(const std::string& nic) {
    std::ifstream mac("/sys/class/net/"+nic+"/address");
    std::string bytes;
    if(mac)std::getline(mac,bytes);
    if(bytes.empty()){
        std::ifstream machine("/etc/machine-id");
        if(machine)std::getline(machine,bytes);
    }
    if(bytes.empty())bytes="deck001-unidentified";
    std::uint64_t hash=14695981039346656037ULL;
    for(const unsigned char c:bytes){hash^=c;hash*=1099511628211ULL;}
    return hash?hash:1;
}
} // namespace
bool encode(const Message& msg,std::array<std::uint8_t,kMessageBytes>& bytes) noexcept {
    if(!std::isfinite(msg.bpm) || msg.bpm<0 || msg.bpm>400 || !msg.id)return false;
    bytes.fill(0);
    std::copy(kMagic.begin(),kMagic.end(),bytes.begin());
    bytes[8]=kProtocol;
    bytes[9]=static_cast<std::uint8_t>((msg.master?1:0)|(msg.playing?2:0)|
              (msg.hasPhase?4:0)|(msg.hasWaveform?8:0)|(msg.updateOffered?16:0));
    write64(bytes.data()+12,msg.id);
    write64(bytes.data()+20,msg.claimClock);
    write32(bytes.data()+152,msg.sequence);
    write32(bytes.data()+156,msg.epoch);
    // Optional 32-bit sender monotonic tick split across previously unused
    // extension bytes. Never compare different Pi clock origins directly.
    bytes[43]=static_cast<std::uint8_t>(msg.senderTickMs>>24);
    bytes[53]=static_cast<std::uint8_t>(msg.senderTickMs>>16);
    bytes[54]=static_cast<std::uint8_t>(msg.senderTickMs>>8);
    bytes[55]=static_cast<std::uint8_t>(msg.senderTickMs);
    write32(bytes.data()+28,static_cast<std::uint32_t>(std::lround(msg.bpm*100000))); // 1e-5 BPM: 0.1 BPM steps drift ~20 ms/min
    if(!std::isfinite(msg.phase)||!std::isfinite(msg.sourceSeconds)||
       msg.sourceSeconds<0||msg.sourceSeconds>4294967)return false;
    write32(bytes.data()+32,static_cast<std::uint32_t>(std::lround(
        std::clamp(msg.phase,0.0,0.999999)*1000000.0)));
    write32(bytes.data()+36,static_cast<std::uint32_t>(std::lround(msg.sourceSeconds*1000.0)));
    bytes[40]=msg.major;bytes[41]=msg.minor;bytes[42]=msg.patch;
    // The original 160-byte, protocol-v2 packet remains unchanged in size.
    // Older peers simply ignore this optional beatgrid metadata.
    if(!std::isfinite(msg.gridBpm)||msg.gridBpm<0||msg.gridBpm>400 ||
       !std::isfinite(msg.waveSpanSeconds)||msg.waveSpanSeconds<0||
       msg.waveSpanSeconds>60 || msg.beatInBar>3)return false;
    write32(bytes.data()+44,static_cast<std::uint32_t>(std::lround(msg.gridBpm*100)));
    write32(bytes.data()+48,static_cast<std::uint32_t>(std::lround(msg.waveSpanSeconds*1000)));
    bytes[52]=msg.beatInBar;
    std::copy(msg.waveform.begin(),msg.waveform.end(),bytes.begin()+56);
    return true;
}
bool decode(const std::uint8_t* data,std::size_t size,Message& out) noexcept {
    if(!data || size!=kMessageBytes ||
       !std::equal(kMagic.begin(),kMagic.end(),data) ||
       data[8]!=kProtocol || data[10]!=0 || data[11]!=0 || (data[9]&~31u))return false;
    Message m;
    m.id=read64(data+12);
    m.claimClock=read64(data+20);
    m.sequence=read32(data+152);m.epoch=read32(data+156);
    m.senderTickMs=(std::uint32_t(data[43])<<24)|
                   (std::uint32_t(data[53])<<16)|
                   (std::uint32_t(data[54])<<8)|std::uint32_t(data[55]);
    m.bpm=read32(data+28)/100000.0;
    m.master=bool(data[9]&1);m.playing=bool(data[9]&2);
    m.hasPhase=bool(data[9]&4);m.hasWaveform=bool(data[9]&8);
    m.updateOffered=bool(data[9]&16);
    m.major=data[40];m.minor=data[41];m.patch=data[42];
    m.gridBpm=read32(data+44)/100.0;
    m.waveSpanSeconds=read32(data+48)/1000.0;
    m.beatInBar=data[52];
    if(m.gridBpm>400 || m.waveSpanSeconds>60 || m.beatInBar>3)return false;
    if(read32(data+32)>1000000)return false;
    m.phase=read32(data+32)/1000000.0;
    m.sourceSeconds=read32(data+36)/1000.0;
    std::copy_n(data+56,kWaveBins,m.waveform.begin());
    if(!m.id || m.bpm>400)return false;
    out=m;return true;
}
Service::Service(std::string iface):interfaceName_(std::move(iface)) {
    if(const char* override=std::getenv("DECK001_LINK_IFACE"))
        if(*override)interfaceName_=override;
    id_=identity(interfaceName_);
    // Session epoch distinguishes delayed frames from previous process boots.
    // This is a freshness nonce, not a cryptographic identity or signature.
    const auto ticks=Clock::now().time_since_epoch().count();
    const auto mix=static_cast<std::uint64_t>(ticks)^id_^
        (static_cast<std::uint64_t>(::getpid())<<32);
    epoch_=static_cast<std::uint32_t>((mix>>32)^mix);
    if(!epoch_)epoch_=1;
}
Service::~Service()=default;
void Service::reopen(Clock::time_point now) {
    if(transport_.available() || now<nextOpen_)return;
    nextOpen_=now+kRetry;
    if(const char* disabled=std::getenv("DECK001_LINK_DISABLED"))
        if(*disabled=='1')return;
    if(transport_.open(interfaceName_)) {
        lastTransportError_=0;
        nextSend_={}; // HELLO on the very next worker tick.
        std::fprintf(stderr,"DECK LINK DIRECT: native Ethernet on %s ready\n",interfaceName_.c_str());
    } else {
        const int error=transport_.lastError();
        if(error && error!=lastTransportError_) {
            lastTransportError_=error;
            std::fprintf(stderr,"DECK LINK DIRECT: Ethernet socket error %d on %s; CAP_NET_RAW required\n",
                error,interfaceName_.c_str());
        }
    }
}
void Service::sendTimingRequest(const Peer& peer,Clock::time_point now) {
    if(!transport_.available()||!supportsTiming(peer.message))return;
    DeckLinkTiming::Packet request;
    request.kind=1;request.source=id_;request.target=peer.message.id;
    request.t1us=monotonicUs();
    request.nonce=(static_cast<std::uint64_t>(epoch_)<<32)|++timingNonceSequence_;
    if(!request.nonce)request.nonce=1;
    std::array<std::uint8_t,DeckLinkTiming::kBytes> buffer{};
    if(DeckLinkTiming::encode(request,buffer) && transport_.broadcast(buffer.data(),buffer.size())) {
        pendingTimingNonce_=request.nonce;pendingTimingPeer_=peer.message.id;
    }
    nextTimingSend_=now+kTimingPeriod;
}
void Service::handleTiming(const DeckLinkTiming::Packet& packet,Clock::time_point now) {
    if(packet.target!=id_||packet.source==id_||!transport_.available())return;
    Peer* peer=nullptr;
    for(auto& candidate:peers_)if(candidate.valid&&candidate.message.id==packet.source) {
        peer=&candidate;break;
    }
    if(!peer||!supportsTiming(peer->message)||now-peer->lastRx>=kPeerGrace)return;
    if(packet.kind==1) {
        DeckLinkTiming::Packet answer;
        answer.kind=2;answer.source=id_;answer.target=packet.source;
        answer.nonce=packet.nonce;answer.t1us=packet.t1us;
        answer.t2us=monotonicUs();
        answer.t3us=monotonicUs();
        std::array<std::uint8_t,DeckLinkTiming::kBytes> buffer{};
        if(DeckLinkTiming::encode(answer,buffer))transport_.broadcast(buffer.data(),buffer.size());
        return;
    }
    if(packet.kind!=2||packet.source!=pendingTimingPeer_||
       packet.nonce!=pendingTimingNonce_)return;
    const auto result=DeckLinkTiming::estimate(packet,id_,pendingTimingNonce_,monotonicUs());
    pendingTimingNonce_=0;pendingTimingPeer_=0;
    if(!result.valid)return;
    peer->timingValid=true;peer->roundTripMs=result.rttMs;
    peer->clockOffsetMs=result.offsetMs;
    if(peer->timingSamples<1000000000u)++peer->timingSamples;
    peer->lastTimingRx=now;
    if(now-lastTimingLog_>=std::chrono::seconds(5)) {
        lastTimingLog_=now;
        std::fprintf(stderr,
           "DECK LINK TIMING v2.2.89: peer=%016llx rtt=%.3fms offset_est=%.3fms samples=%u (NOT DAC phase)\n",
           static_cast<unsigned long long>(peer->message.id),peer->roundTripMs,
           peer->clockOffsetMs,peer->timingSamples);
    }
}
bool Service::allPeersSupport91(Clock::time_point now) const noexcept {
    bool any=false;
    for(const auto& peer:peers_)if(peer.valid && now-peer.lastRx<kPeerGrace) {
        any=true;if(!supports91(peer.message))return false;
    }
    return any;
}
bool Service::allPeersSupport97(Clock::time_point now) const noexcept {
    bool any=false;
    for(const auto& peer:peers_)if(peer.valid && now-peer.lastRx<kPeerGrace){
        any=true;if(!supports97(peer.message))return false;
    }
    return any;
}
void Service::sendDetail(const LocalState& local,Clock::time_point now) {
    // Full static analyzed-track cache supersedes repeated 1536-bin windows
    // only when ALL peers are v97-capable. Older releases retain their path.
    if(allPeersSupport97(now))return;
    if(!transport_.available()||!local.hasDetailedWaveform||!local.detailGeneration||
       local.detailGeneration==lastDetailSentGeneration_||!allPeersSupport91(now))return;
    if(!std::isfinite(local.detailCenterSeconds)||local.detailCenterSeconds<0||
       local.detailCenterSeconds>4294967.0||!std::isfinite(local.detailSpanSeconds)||
       local.detailSpanSeconds<=0||local.detailSpanSeconds>60)return;
    DeckLinkWaveDetail::Chunk chunk;
    chunk.senderId=id_;chunk.epoch=epoch_;
    chunk.generation=local.detailGeneration;chunk.deviceNumber=local.deviceNumber;
    chunk.centerMs=static_cast<std::uint32_t>(std::lround(local.detailCenterSeconds*1000.0));
    chunk.spanMs=static_cast<std::uint32_t>(std::lround(local.detailSpanSeconds*1000.0));
    for(std::uint8_t i=0;i<DeckLinkWaveDetail::kChunks;++i) {
        chunk.index=i;
        std::copy_n(local.detailWaveform.begin()+std::size_t(i)*DeckLinkWaveDetail::kChunkBins,
                    DeckLinkWaveDetail::kChunkBins,chunk.peaks.begin());
        std::array<std::uint8_t,DeckLinkWaveDetail::kBytes> bytes{};
        if(!DeckLinkWaveDetail::encode(chunk,bytes)||
           !transport_.broadcast(bytes.data(),bytes.size()))return;
    }
    lastDetailSentGeneration_=local.detailGeneration;
}
bool Service::handleDetail(const DeckLinkWaveDetail::Chunk& chunk,Clock::time_point now) {
    if(chunk.senderId==id_)return false;
    for(auto& peer:peers_)if(peer.valid && peer.message.id==chunk.senderId &&
       peer.epoch==chunk.epoch && supports91(peer.message) && now-peer.lastRx<kPhaseFresh) {
        if(peer.detailGeneration && static_cast<std::int32_t>(chunk.generation-peer.detailGeneration)<=0)
            return false;
        if(peer.detailPartialGeneration!=chunk.generation) {
            if(peer.detailPartialGeneration &&
               static_cast<std::int32_t>(chunk.generation-peer.detailPartialGeneration)<=0)
                return false;
            peer.detailPartialGeneration=chunk.generation;
            peer.detailMask=0;
            peer.detailCenterMs=chunk.centerMs;peer.detailSpanMs=chunk.spanMs;
            peer.deviceNumber=chunk.deviceNumber;
        }
        if(peer.detailCenterMs!=chunk.centerMs||peer.detailSpanMs!=chunk.spanMs)return false;
        std::copy(chunk.peaks.begin(),chunk.peaks.end(),
                  peer.detailPartial.begin()+std::size_t(chunk.index)*DeckLinkWaveDetail::kChunkBins);
        peer.detailMask|=std::uint8_t(1u<<chunk.index);
        if(peer.detailMask==((1u<<DeckLinkWaveDetail::kChunks)-1u)) {
            peer.detailWaveform=peer.detailPartial;
            peer.detailGeneration=chunk.generation;
            peer.detailMask=0;peer.lastDetailRx=now;
            return true;
        }
        return false;
    }
    return false;
}
// Static analysis traffic is one bounded chunk per worker tick, BELOW music
// heartbeat priority. If the receiver misses a fragment the sender cycles
// unacknowledged chunks; a complete checksum-valid cache returns an ACK.
void Service::sendStatic(const LocalState& local,Clock::time_point now) {
    if(!transport_.available() || !local.staticWave || !allPeersSupport97(now) ||
       now<nextStaticSend_)return;
    const auto& cache=*local.staticWave;
    if(cache.bins.empty()||cache.bins.size()>DeckLinkStaticWave::kMaxBins)return;
    bool pending=false;
    for(const auto& peer:peers_)if(peer.valid && now-peer.lastRx<kPeerGrace &&
       supports97(peer.message) && (peer.staticAckGeneration!=cache.generation ||
                                    peer.staticAckHash!=cache.hash))pending=true;
    if(!pending)return;
    if(lastStaticSentGeneration_!=cache.generation || lastStaticSentHash_!=cache.hash){
       // The first (empty->loaded) track can publish metadata before the
       // async static analysis is ready. A newly prepared cache MUST begin a
       // fresh transfer cycle even if the peer was connected while empty.
       nextStaticChunk_=0;
       lastStaticSentGeneration_=cache.generation;
       lastStaticSentHash_=cache.hash;
       for(auto& peer:peers_) {
           peer.requestedStaticIndex=UINT32_MAX;
           peer.requestedStaticGeneration=peer.requestedStaticHash=0;
       }
    }
    const std::size_t chunks=(cache.bins.size()+DeckLinkStaticWave::kSamplesPerChunk-1)/
        DeckLinkStaticWave::kSamplesPerChunk;
    // A bounded three-chunk burst is about 86KB/s, still background to the
    // 100Hz music + motion packets already transmitted earlier this tick.
    // Urgent v99 missing-chunk requests take one of these three slots.
    for(int budget=0;budget<3;++budget) {
        // Prioritize one valid peer-specific resend, rotating over peers to
        // prevent a noisy receiver from starving another. Broadcast remains
        // unchanged: all peers can benefit from a repaired fragment.
        const auto requestSlot=DeckLinkTransferScheduler::select(
            peers_,nextStaticRequesterSlot_,chunks,cache.generation,cache.hash,
            [now](const Peer& candidate) noexcept {
                return candidate.valid && now-candidate.lastRx<kPeerGrace &&
                       supports99(candidate.message);
            });
        Peer* requester=requestSlot<peers_.size()?&peers_[requestSlot]:nullptr;
        const bool resend=requester!=nullptr;
        const std::size_t index=resend?requester->requestedStaticIndex:nextStaticChunk_;
        DeckLinkStaticWave::Chunk fragment;
        fragment.senderId=id_;fragment.epoch=epoch_;fragment.generation=cache.generation;
        fragment.durationMs=cache.durationMs;fragment.hash=cache.hash;
        fragment.totalBins=static_cast<std::uint32_t>(cache.bins.size());
        fragment.index=static_cast<std::uint32_t>(index);
        fragment.count=static_cast<std::uint8_t>(std::min(DeckLinkStaticWave::kSamplesPerChunk,
            cache.bins.size()-index*DeckLinkStaticWave::kSamplesPerChunk));
        std::copy_n(cache.bins.begin()+index*DeckLinkStaticWave::kSamplesPerChunk,
                    fragment.count,fragment.data.begin());
        std::array<std::uint8_t,DeckLinkStaticWave::kBytes> bytes{};
        if(!DeckLinkStaticWave::encode(fragment,bytes) ||
           !transport_.broadcast(bytes.data(),bytes.size()))break;
        if(resend) {
            requester->requestedStaticIndex=UINT32_MAX;
            nextStaticRequesterSlot_=(requestSlot+1)%peers_.size();
        } else nextStaticChunk_=(nextStaticChunk_+1)%chunks;
    }
    nextStaticSend_=now+std::chrono::milliseconds(10);
}
bool Service::handleStatic(const DeckLinkStaticWave::Chunk& chunk,Clock::time_point now) {
    if(chunk.senderId==id_)return false;
    for(auto& peer:peers_)if(peer.valid && peer.message.id==chunk.senderId &&
       peer.epoch==chunk.epoch && supports97(peer.message) &&
       now-peer.lastRx<kPeerGrace) {
        // Never display a previous USB/INTERNAL track's late data.
        if(!peer.trackView.generation || peer.trackView.generation!=chunk.generation ||
           !peer.trackView.valid) {
            ++peer.waveTrace.generationRejects;return false;
        }
        if(peer.trackView.durationMs!=chunk.durationMs) {
            ++peer.waveTrace.durationRejects;return false;
        }
        ++peer.waveTrace.chunks;
        if(peer.staticHasPreviousIndex && chunk.index<peer.lastStaticChunkIndex)
            peer.staticSawCycle=true;
        peer.lastStaticChunkIndex=chunk.index;
        peer.staticHasPreviousIndex=true;
        peer.lastStaticChunkRx=now;
        if(peer.staticAssembler.accept(chunk)) {
            ++peer.waveTrace.completions;
            peer.staticAckGeneration=0;peer.staticAckHash=0;
            peer.lastStaticAckSent={};peer.staticSawCycle=false;
            return true;
        }
        return false;
    }
    return false;
}
bool Service::handleStaticAck(const DeckLinkStaticWave::Ack& ack,Clock::time_point now) {
    if(ack.targetId!=id_ || ack.targetEpoch!=epoch_ ||
       ack.generation!=lastStaticSentGeneration_ ||
       ack.hash!=lastStaticSentHash_)return false;
    for(auto& peer:peers_)if(peer.valid && peer.message.id==ack.senderId &&
        supports97(peer.message) && now-peer.lastRx<kPeerGrace){
        peer.staticAckGeneration=ack.generation;peer.staticAckHash=ack.hash;
        // Completed delivery makes an old selective request obsolete.
        peer.requestedStaticIndex=UINT32_MAX;
        return false;
    }
    return false;
}
bool Service::handleStaticRequest(const DeckLinkStaticWave::Request& r,
                                  Clock::time_point now) {
    if(r.targetId!=id_||r.targetEpoch!=epoch_)return false;
    for(auto& peer:peers_)if(peer.valid && peer.message.id==r.requesterId &&
       supports99(peer.message) && now-peer.lastRx<kPeerGrace) {
        if(r.index==DeckLinkStaticWave::kReofferIndex) {
            // v100 cache-miss reoffer: a receiver without any fragments can
            // recover after asymmetric Ethernet loss. Validate generation
            // against the most recently offered local track before resetting.
            if(!supports100(peer.message) ||
               r.generation!=lastStaticSentGeneration_)return false;
            peer.staticAckGeneration=0;peer.staticAckHash=0;
            lastStaticSentGeneration_=0;nextStaticChunk_=0;nextStaticSend_={};
            return false;
        }
        // Reject delayed/mismatched requests; do not resurrect a previous
        // song's fragment after the local generation changes.
        if(r.generation!=lastStaticSentGeneration_ ||
           r.hash!=lastStaticSentHash_)return false;
        peer.requestedStaticIndex=r.index;
        peer.requestedStaticGeneration=r.generation;
        peer.requestedStaticHash=r.hash;
        // A genuine missing-chunk request overrides a stale completion ACK.
        if(r.generation==lastStaticSentGeneration_ && r.hash==lastStaticSentHash_) {
            peer.staticAckGeneration=0;peer.staticAckHash=0;
        }
        nextStaticSend_={};
        return false;
    }
    return false;
}
void Service::sendStaticRequests(Clock::time_point now) {
    if(!transport_.available())return;
    for(auto& peer:peers_)if(peer.valid && supports99(peer.message) &&
       now-peer.lastRx<kPeerGrace &&
       now-peer.lastStaticRequestSent>=std::chrono::milliseconds(500)) {
        const bool missingEntireCache=supports100(peer.message) &&
            peer.trackView.valid && peer.trackView.generation &&
            !peer.staticAssembler.complete() && !peer.staticAssembler.pending();
        const bool missingChunk=DeckLinkStaticWave::needsMissingChunk(
            peer.staticAssembler.pending(),peer.staticSawCycle,peer.lastStaticChunkRx,now);
        if(!missingEntireCache && !missingChunk)continue;
        const auto index=missingEntireCache?DeckLinkStaticWave::kReofferIndex:
            peer.staticAssembler.firstMissing();
        if(index==UINT32_MAX && !missingEntireCache)continue;
        DeckLinkStaticWave::Request r{id_,peer.message.id,peer.epoch,
            missingEntireCache?peer.trackView.generation:peer.staticAssembler.pendingGeneration(),
            missingEntireCache?1u:peer.staticAssembler.pendingHash(),index};
        std::array<std::uint8_t,DeckLinkStaticWave::kRequestBytes> bytes{};
        if(DeckLinkStaticWave::encodeRequest(r,bytes) &&
           transport_.broadcast(bytes.data(),bytes.size())) {
            ++peer.waveTrace.requests;
            peer.lastStaticRequestSent=now;
        }
    }
}
void Service::sendStaticAcks(Clock::time_point now) {
    if(!transport_.available())return;
    for(auto& peer:peers_)if(peer.valid && now-peer.lastRx<kPeerGrace &&
        supports97(peer.message) &&
        now-peer.lastStaticAckSent>=std::chrono::seconds(1)) {
        const auto cache=peer.staticAssembler.complete();
        if(!cache || cache->generation!=peer.trackView.generation)continue;
        DeckLinkStaticWave::Ack ack{id_,peer.message.id,peer.epoch,
                                    cache->generation,cache->hash};
        std::array<std::uint8_t,DeckLinkStaticWave::kAckBytes> bytes{};
        if(DeckLinkStaticWave::encodeAck(ack,bytes) &&
           transport_.broadcast(bytes.data(),bytes.size()))peer.lastStaticAckSent=now;
    }
}
// A separate compact source-time observation, still on the non-audio worker.
// The remote visual clock predicts between observations at display FPS.
// Atomic beatgrid parameters are additive and v100-only. A beatgrid edit
// transmits promptly; refresh periodically for reconnect and lost packets.
void Service::sendGrid(const LocalState& local,Clock::time_point now) {
    if(!transport_.available() || !local.motion.trackGeneration ||
       !local.motion.gridRevision)return;
    bool supported=false;
    for(const auto& peer:peers_)if(peer.valid && supports100(peer.message) &&
        now-peer.lastRx<kPeerGrace)supported=true;
    if(!supported)return;
    if(now<nextGridSend_ && lastGridSentGeneration_==local.motion.trackGeneration &&
       lastGridSentRevision_==local.motion.gridRevision)return;
    DeckLinkGrid::Packet grid;
    grid.senderId=id_;grid.epoch=epoch_;
    grid.generation=local.motion.trackGeneration;
    grid.revision=local.motion.gridRevision;
    grid.valid=local.hasPhase && local.gridBpm>0;
    grid.bpm=grid.valid?local.gridBpm:0.0;
    grid.firstBeatSeconds=local.motion.firstBeatSeconds;
    std::array<std::uint8_t,DeckLinkGrid::kBytes> bytes{};
    if(DeckLinkGrid::encode(grid,bytes) &&
       transport_.broadcast(bytes.data(),bytes.size())) {
        lastGridSentGeneration_=grid.generation;
        lastGridSentRevision_=grid.revision;
        nextGridSend_=now+std::chrono::seconds(1);
    }
}
bool Service::handleGrid(const DeckLinkGrid::Packet& grid,Clock::time_point now) {
    if(grid.senderId==id_)return false;
    for(auto& peer:peers_)if(peer.valid && supports100(peer.message) &&
       peer.message.id==grid.senderId && peer.epoch==grid.epoch &&
       now-peer.lastRx<kPeerGrace && peer.trackView.valid &&
       peer.trackView.generation==grid.generation) {
        if(peer.grid.generation==grid.generation && peer.grid.revision &&
           static_cast<std::int32_t>(grid.revision-peer.grid.revision)<0)return false;
        const bool changed=peer.grid.generation!=grid.generation ||
            peer.grid.revision!=grid.revision || peer.grid.bpm!=grid.bpm ||
            peer.grid.firstBeatSeconds!=grid.firstBeatSeconds;
        peer.grid=grid;peer.lastGridRx=now;
        return changed;
    }
    return false;
}
void Service::sendMotion(const LocalState& local,Clock::time_point now) {
    if(!transport_.available() || !local.motion.trackGeneration ||
       !allPeersSupport97(now) || now<nextMotionSend_)return;
    auto p=local.motion;
    p.senderId=id_;p.epoch=epoch_;
    if(++motionSequence_==0)++motionSequence_;
    p.sequence=motionSequence_;
    std::array<std::uint8_t,DeckLinkMotion::kBytes> bytes{};
    if(DeckLinkMotion::encode(p,bytes))transport_.broadcast(bytes.data(),bytes.size());
    nextMotionSend_=now+std::chrono::milliseconds(10);
}
bool Service::handleMotion(const DeckLinkMotion::Packet& pkt,Clock::time_point now) {
    if(pkt.senderId==id_)return false;
    for(auto& peer:peers_)if(peer.valid && peer.message.id==pkt.senderId &&
       peer.epoch==pkt.epoch && supports97(peer.message) &&
       now-peer.lastRx<kPeerGrace){
        if(!peer.trackView.generation || pkt.trackGeneration!=peer.trackView.generation ||
           !peer.trackView.valid) {
            // A newer track's motion may arrive ahead of its track metadata.
            // Hide the old waveform immediately; do not confuse two tracks.
            if(peer.trackView.generation &&
               static_cast<std::int32_t>(pkt.trackGeneration-peer.trackView.generation)>0) {
                peer.trackView={};peer.staticAssembler.reset();
                peer.grid={};peer.lastGridRx={};
                peer.visualMotion.reset();peer.lastMotionCaptureAgeMs=-1.0;
                peer.staticSawCycle=false;peer.staticHasPreviousIndex=false;
                return true;
            }
            return false;
        }
        const auto old=peer.visualMotion.packet();
        const bool meaningful=DeckLinkMotion::needsRepaint(
            old,pkt,peer.visualMotion.valid());
        double captureAgeMs=-1.0;
        if(peer.timingValid && now-peer.lastTimingRx<kTimingFresh &&
           peer.timingSamples>0 && pkt.captureTickUs) {
            const double receiverUs=double(DeckLinkMotion::monotonicUs(now));
            const double senderCaptureLocalUs=double(pkt.captureTickUs)-
                peer.clockOffsetMs*1000.0;
            const double ageMs=(receiverUs-senderCaptureLocalUs)*0.001;
            if(std::isfinite(ageMs) && ageMs>=0.0 && ageMs<=120.0)
                captureAgeMs=ageMs;
        }
        const bool accepted=peer.visualMotion.observe(pkt,now,
            peer.timingValid?peer.roundTripMs:0.0,captureAgeMs);
        if(accepted){
            peer.lastMotionRxUs=DeckLinkMotion::monotonicUs(now);
            peer.lastMotionCaptureAgeMs=captureAgeMs;
            if(meaningful)++peer.motionRedrawEvents;
        }
        // Ordinary playback observations update only the predictor; true
        // stopped-scrub movement and transport discontinuities wake the UI.
        return accepted && meaningful;
    }
    return false;
}
// Version-gated current-track negotiation; the request is independent of any
// known track generation. This closes the late-join deadlock where the receiver
// cannot request waveform fragments until it first receives track metadata.
void Service::sendTrackRequests(Clock::time_point now) {
    if(!transport_.available())return;
    for(auto& peer:peers_)if(peer.valid && supports105(peer.message) &&
       now-peer.lastRx<kPeerGrace && peer.message.hasWaveform &&
       (!peer.trackView.valid || !peer.trackView.generation) &&
       now-peer.lastTrackRequestSent>=std::chrono::milliseconds(350)) {
        DeckLinkTrackHandshake::Packet p;
        p.kind=DeckLinkTrackHandshake::Kind::Request;
        p.senderId=id_;p.senderEpoch=epoch_;
        p.targetId=peer.message.id;p.targetEpoch=peer.epoch;
        std::array<std::uint8_t,DeckLinkTrackHandshake::kBytes> bytes{};
        if(DeckLinkTrackHandshake::encode(p,bytes) &&
           transport_.broadcast(bytes.data(),bytes.size()))
            peer.lastTrackRequestSent=now;
    }
}
void Service::handleTrackHandshake(const DeckLinkTrackHandshake::Packet& p,
                                  Clock::time_point now) {
    if(p.targetId!=id_ || p.targetEpoch!=epoch_ || p.senderId==id_)return;
    for(auto& peer:peers_)if(peer.valid && supports105(peer.message) &&
       now-peer.lastRx<kPeerGrace && peer.message.id==p.senderId &&
       peer.epoch==p.senderEpoch) {
        if(p.kind==DeckLinkTrackHandshake::Kind::Request) {
            // The currently loaded track is advertised on the next tick,
            // without requiring any new track load or playback transition.
            nextViewSend_={};lastViewGeneration_=0;
            nextMotionSend_={};nextGridSend_={};
            // A requesting peer may have lost its cache; never rely on a
            // previously acknowledged transfer at this join boundary.
            peer.staticAckGeneration=0;peer.staticAckHash=0;
            nextStaticSend_={};
        } else if(p.kind==DeckLinkTrackHandshake::Kind::Accepted) {
            peer.trackAcceptedGeneration=p.generation;
        }
        return;
    }
}
// Track view packets are optional and separate from the 160-byte heartbeat.
// Only an actual v92 peer advertises/consumes this additional data.
void Service::sendTrackView(const LocalState& local,Clock::time_point now) {
    if(!transport_.available() || !local.hasTrackView || !local.trackView.generation)return;
    bool supports=false;
    for(const auto& peer:peers_)if(peer.valid && now-peer.lastRx<kPeerGrace &&
                                  supports92(peer.message))supports=true;
    if(!supports)return;
    if(now<nextViewSend_ && local.trackView.generation==lastViewGeneration_)return;
    auto packet=local.trackView;
    packet.senderId=id_;packet.epoch=epoch_;
    std::array<std::uint8_t,DeckLinkTrackView::kBytes> bytes{};
    if(DeckLinkTrackView::encode(packet,bytes) &&
       transport_.broadcast(bytes.data(),bytes.size())) {
        lastViewGeneration_=packet.generation;
        nextViewSend_=now+std::chrono::seconds(2);
    }
}
bool Service::handleTrackView(const DeckLinkTrackView::Packet& packet,
                              Clock::time_point now) {
    if(packet.senderId==id_)return false;
    for(auto& peer:peers_)if(peer.valid && peer.message.id==packet.senderId &&
       peer.epoch==packet.epoch && supports92(peer.message) &&
       now-peer.lastRx<kPeerGrace) {
        if(peer.trackView.generation &&
           static_cast<std::int32_t>(packet.generation-peer.trackView.generation)<0)return false;
        const bool changed=peer.trackView.generation!=packet.generation ||
                           peer.trackView.title!=packet.title ||
                           peer.trackView.valid!=packet.valid ||
                           peer.trackView.durationMs!=packet.durationMs;
        if(peer.trackView.generation!=packet.generation){
            peer.staticAssembler.reset();peer.visualMotion.reset();
            peer.staticSawCycle=false;peer.staticHasPreviousIndex=false;
            peer.lastStaticChunkRx={};peer.lastStaticRequestSent={};
            peer.staticAckGeneration=0;peer.staticAckHash=0;
        }
        if(peer.trackView.generation!=packet.generation) {
            peer.grid={};peer.lastGridRx={};
        }
        peer.trackView=packet;peer.lastViewRx=now;
        if(supports105(peer.message) && packet.valid &&
           (changed || peer.trackAcceptedGeneration!=packet.generation)) {
            DeckLinkTrackHandshake::Packet ack;
            ack.kind=DeckLinkTrackHandshake::Kind::Accepted;
            ack.senderId=id_;ack.senderEpoch=epoch_;
            ack.targetId=peer.message.id;ack.targetEpoch=peer.epoch;
            ack.generation=packet.generation;
            std::array<std::uint8_t,DeckLinkTrackHandshake::kBytes> bytes{};
            if(DeckLinkTrackHandshake::encode(ack,bytes) &&
               transport_.broadcast(bytes.data(),bytes.size()))
                peer.trackAcceptedGeneration=packet.generation;
        }
        return changed;
    }
    return false;
}
bool Service::allPeersSupport90(Clock::time_point now) const noexcept {
    bool any=false;
    for(const auto& peer:peers_)if(peer.valid && now-peer.lastRx<kPeerGrace) {
        any=true;
        if(!supports90(peer.message))return false;
    }
    return any;
}
void Service::sendSyncReport(const LocalState& local,Clock::time_point now) {
    if(!transport_.available() || !allPeersSupport90(now))return;
    const Peer* leader=nullptr;
    std::uint64_t winningClaim=localClaimClock_,winningId=id_;
    for(const auto& peer:peers_)if(peer.valid && now-peer.lastRx<kPhaseFresh &&
        DeckLinkElection::peerWins(winningClaim,winningId,peer.message.claimClock,peer.message.id)) {
        winningClaim=peer.message.claimClock;winningId=peer.message.id;
        leader=&peer;
    }
    DeckLinkSyncReport::Packet packet;
    packet.senderId=id_;packet.senderEpoch=epoch_;
    packet.sequence=++reportSequence_;
    packet.mode=localMaster_?SyncMode::Off:(syncMode_!=SyncMode::Off?syncMode_:takeoverMode_);
    packet.masterId=leader && !localMaster_?leader->message.id:0;
    packet.masterEpoch=leader && !localMaster_?leader->epoch:0;
    packet.tempoApplied=packet.masterId && packet.mode!=SyncMode::Off && local.playing &&
        leader && leader->message.playing && local.linkedTempoApplied;
    packet.beatLocked=packet.tempoApplied && packet.mode==SyncMode::Beat && local.linkedBeatLocked;
    std::array<std::uint8_t,DeckLinkSyncReport::kBytes> bytes{};
    if(DeckLinkSyncReport::encode(packet,bytes))transport_.broadcast(bytes.data(),bytes.size());
}
bool Service::handleSyncReport(const DeckLinkSyncReport::Packet& packet,Clock::time_point now) {
    if(packet.senderId==id_)return false;
    for(auto& peer:peers_)if(peer.valid && peer.message.id==packet.senderId &&
       peer.epoch==packet.senderEpoch && supports90(peer.message) &&
       now-peer.lastRx<kPhaseFresh) {
        if(peer.report.senderEpoch==packet.senderEpoch && peer.report.sequence &&
           static_cast<std::int32_t>(packet.sequence-peer.report.sequence)<=0)return false;
        const bool changed=peer.report.mode!=packet.mode ||
            peer.report.tempoApplied!=packet.tempoApplied ||
            peer.report.beatLocked!=packet.beatLocked ||
            peer.report.masterId!=packet.masterId ||
            peer.report.masterEpoch!=packet.masterEpoch;
        peer.report=packet;peer.lastReportRx=now;
        return changed;
    }
    return false;
}
void Service::sendMessage(const LocalState& local) {
    if(!transport_.available())return;
    Message message;
    message.id=id_;message.claimClock=localClaimClock_;
    message.epoch=epoch_;message.sequence=++sequence_;
    message.senderTickMs=static_cast<std::uint32_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            Clock::now().time_since_epoch()).count());
    message.bpm=local.bpm;message.master=localMaster_;message.playing=local.playing;
    message.hasPhase=local.hasPhase;message.phase=local.phase;
    message.sourceSeconds=local.sourceSeconds;
    message.gridBpm=local.gridBpm;message.waveSpanSeconds=local.waveSpanSeconds;
    message.beatInBar=local.beatInBar;
    message.hasWaveform=local.hasWaveform;message.waveform=local.waveform;
    // OTA offers are intentionally independent of music sync. A raw-Ethernet
    // MAC is NOT an IPv6 address; never advertise a broken update endpoint.
    message.updateOffered=false;
    message.major=local.major;message.minor=local.minor;message.patch=local.patch;
    std::array<std::uint8_t,kMessageBytes> bytes{};
    if(encode(message,bytes))transport_.broadcast(bytes.data(),bytes.size());
}
bool Service::handle(const Message& message,Clock::time_point now,
                     const std::array<std::uint8_t,6>& mac) {
    if(message.id==id_ || message.epoch==0 || message.sequence==0)return false;
    Peer* selected=nullptr;
    Peer* unused=nullptr;
    for(auto& peer:peers_) {
        if(peer.valid && peer.message.id==message.id){selected=&peer;break;}
        if(!peer.valid && !unused)unused=&peer;
    }
    if(!selected)selected=unused;
    // A timed-out slot can be reused by a different physical peer; never
    // carry its completed cache or an ACK to the new identity.
    if(selected && selected->message.id!=0 && selected->message.id!=message.id)
        *selected=Peer{};
    // Never evict a healthy deck to admit a fifth device. Protocol/registry
    // support one local unit plus three remote units, independent of transport.
    if(!selected)return false;
    if(selected->valid && selected->epoch==message.epoch) {
        // Signed difference safely handles uint32 sequence wrap.
        if(static_cast<std::int32_t>(message.sequence-selected->sequence)<=0)
            return false;
    }
    const bool newlyConnected=!selected->valid;
    const bool dataChanged=newlyConnected || selected->message.master!=message.master ||
        selected->message.playing!=message.playing ||
        selected->message.bpm!=message.bpm ||
        selected->message.hasWaveform!=message.hasWaveform ||
        selected->message.claimClock!=message.claimClock;
    if(selected->epoch!=0 && selected->epoch!=message.epoch) {
        // A prior process' sync reports/locks are never valid for this epoch.
        selected->report={};selected->lastReportRx={};
        // New peer process: old RTT/clock model must never be reused.
        selected->timingValid=false;selected->timingSamples=0;
        selected->detailGeneration=0;selected->detailPartialGeneration=0;
        selected->detailMask=0;selected->lastDetailRx={};
        selected->trackView={};selected->lastViewRx={};
        selected->trackAcceptedGeneration=0;selected->lastTrackRequestSent={};
        selected->grid={};selected->lastGridRx={};
        selected->staticAssembler.reset();selected->visualMotion.reset();
        selected->staticSawCycle=false;selected->staticHasPreviousIndex=false;
        selected->lastStaticChunkRx={};selected->lastStaticRequestSent={};
        selected->staticAckGeneration=0;
        selected->staticAckHash=0;selected->lastStaticAckSent={};
        selected->requestedStaticIndex=UINT32_MAX;
    }
    if(newlyConnected) {
        // Returning Ethernet connection with the same process epoch: the
        // receiver may have discarded its cache while we retained an ACK.
        // Re-offer safely; a receiver with a complete matching cache ACKs
        // again without replacing good data.
        selected->staticAckGeneration=0;selected->staticAckHash=0;
        selected->requestedStaticIndex=UINT32_MAX;
        selected->lastStaticAckSent={};
        selected->lastStaticRequestSent={};
        lastStaticSentGeneration_=0;nextStaticChunk_=0;nextStaticSend_={};
        // Late join: the other controller may already be minutes into a song.
        // Send its CURRENT track identity before bulk chunks, rather than
        // requiring a local track change or waiting for the 2-second advert.
        nextViewSend_={};lastViewGeneration_=0;
        nextGridSend_={};lastGridSentRevision_=0;
        nextMotionSend_={};
    }
    selected->valid=true;selected->message=message;
    selected->epoch=message.epoch;selected->sequence=message.sequence;
    selected->mac=mac;selected->lastRx=now;
    observedClaimClock_=std::max(observedClaimClock_,message.claimClock);
    if(newlyConnected)std::fprintf(stderr,"DECK LINK DIRECT: connected id=%016llx\n",
        static_cast<unsigned long long>(message.id));
    // Live visual movement is owned by the KMS-paced UI renderer. Do not
    // mark a *full* scene dirty every 33ms merely because a peer exists.
    return dataChanged;
}
void Service::electMaster(bool localPlaying) noexcept {
    const auto old=localMaster_;
    std::uint64_t winningClaim=localClaimClock_;
    std::uint64_t winningId=id_;
    for(const auto& peer:peers_)if(peer.valid) {
        // Explicit claims win over automatic NIC ordering, with deterministic
        // stable ID tie-breaking. The local *claim* never echoes peer clocks.
        if(DeckLinkElection::peerWins(winningClaim,winningId,
                peer.message.claimClock,peer.message.id)) {
            winningClaim=peer.message.claimClock;
            winningId=peer.message.id;
        }
    }
    // First PLAYING unit in a newly connected v2.2.90 group takes ownership.
    // With no one playing the stable NIC-ID election remains the fallback.
    // After a claim has been announced, new peers cannot steal leadership by
    // joining or pressing PLAY. Only explicit TAKE MASTER increments Lamport.
    if(winningClaim==0 && allPeersSupport90(Clock::now())) {
        bool winnerPlaying=localPlaying;
        std::uint64_t autoWinner=id_;
        for(const auto& peer:peers_)if(peer.valid &&
            Clock::now()-peer.lastRx<kPeerGrace) {
            if((peer.message.playing && !winnerPlaying) ||
               (peer.message.playing==winnerPlaying && peer.message.id>autoWinner)) {
                winnerPlaying=peer.message.playing;autoWinner=peer.message.id;
            }
        }
        winningId=autoWinner;
        // Idle groups stay provisional; first PLAY can still take MASTER.
        if(winnerPlaying && winningId==id_) {
            localClaimClock_=1;winningClaim=1;
        }
    }
    localMaster_=(winningId==id_);
    if(old && !localMaster_ && hadSyncedFollowers_ && !explicitSyncOff_ &&
       syncMode_==SyncMode::Off)takeoverMode_=SyncMode::Beat;
    if(localMaster_)takeoverMode_=SyncMode::Off;
    if(old!=localMaster_) {
        nextSend_={};nextSyncReport_={};
        // Never re-use an old follower's lock report after leadership changes.
        for(auto& peer:peers_){peer.report={};peer.lastReportRx={};}
    }
}
const Service::Peer* Service::primary(Clock::time_point now) const noexcept {
    const Peer* selected=nullptr;
    for(const auto& peer:peers_) {
        if(!peer.valid || now-peer.lastRx>=kPeerGrace)continue;
        if(!selected || DeckLinkElection::peerWins(selected->message.claimClock,
            selected->message.id,peer.message.claimClock,peer.message.id))
            selected=&peer;
    }
    return selected;
}
bool Service::tick(double bpm,bool playing) {
    LocalState local;local.bpm=bpm;local.playing=playing;
    return tick(local);
}
bool Service::tick(const LocalState& local) {
    auto now=Clock::now();
    const bool previousLocalMaster=localMaster_;
    const bool previousConnected=primary(now)!=nullptr;
    bool changed=false;
    reopen(now);
    for(int i=0;transport_.available() && i<64;++i) {
        std::array<std::uint8_t,768> bytes{};
        std::array<std::uint8_t,6> mac{};
        const int length=transport_.receive(bytes.data(),bytes.size(),mac);
        if(length<=0)break;
        Message message;
        DeckLinkTiming::Packet timing{};
        DeckLinkSyncReport::Packet syncReport{};
        DeckLinkWaveDetail::Chunk detail{};
        DeckLinkTrackView::Packet trackView{};
        DeckLinkStaticWave::Chunk staticChunk{};
        DeckLinkStaticWave::Ack staticAck{};
        DeckLinkStaticWave::Request staticRequest{};
        DeckLinkMotion::Packet motion{};
        DeckLinkGrid::Packet grid{};
        DeckLinkTrackHandshake::Packet trackHandshake{};
        if(length==static_cast<int>(DeckLinkGrid::kBytes)) {
            if(DeckLinkGrid::decode(bytes.data(),static_cast<std::size_t>(length),grid))
                changed=handleGrid(grid,Clock::now())||changed;
        } else if(length==static_cast<int>(DeckLinkMotion::kBytes)) {
            if(DeckLinkMotion::decode(bytes.data(),static_cast<std::size_t>(length),motion))
                changed=handleMotion(motion,Clock::now())||changed;
        } else if(length==static_cast<int>(DeckLinkTrackHandshake::kBytes)) {
            if(DeckLinkTrackHandshake::decode(bytes.data(),static_cast<std::size_t>(length),trackHandshake))
                handleTrackHandshake(trackHandshake,Clock::now());
        } else if(length==static_cast<int>(DeckLinkStaticWave::kBytes)) {
            if(DeckLinkStaticWave::decode(bytes.data(),static_cast<std::size_t>(length),staticChunk))
                changed=handleStatic(staticChunk,Clock::now())||changed;
        } else if(length==static_cast<int>(DeckLinkStaticWave::kAckBytes)) {
            if(DeckLinkStaticWave::decodeAck(bytes.data(),static_cast<std::size_t>(length),staticAck))
                changed=handleStaticAck(staticAck,Clock::now())||changed;
        } else if(length==static_cast<int>(DeckLinkStaticWave::kRequestBytes)) {
            if(DeckLinkStaticWave::decodeRequest(bytes.data(),static_cast<std::size_t>(length),staticRequest))
                changed=handleStaticRequest(staticRequest,Clock::now())||changed;
        } else if(length==static_cast<int>(DeckLinkTrackView::kBytes)) {
            if(DeckLinkTrackView::decode(bytes.data(),static_cast<std::size_t>(length),trackView))
                changed=handleTrackView(trackView,Clock::now())||changed;
        } else if(length==static_cast<int>(DeckLinkWaveDetail::kBytes)) {
            if(DeckLinkWaveDetail::decode(bytes.data(),static_cast<std::size_t>(length),detail))
                changed=handleDetail(detail,Clock::now())||changed;
        } else if(length==static_cast<int>(DeckLinkSyncReport::kBytes)) {
            if(DeckLinkSyncReport::decode(bytes.data(),static_cast<std::size_t>(length),syncReport))
                changed=handleSyncReport(syncReport,Clock::now())||changed;
        } else if(length==static_cast<int>(DeckLinkTiming::kBytes)) {
            if(DeckLinkTiming::decode(bytes.data(),static_cast<std::size_t>(length),timing))
                handleTiming(timing,Clock::now());
        }else if(decode(bytes.data(),static_cast<std::size_t>(length),message))
            changed=handle(message,Clock::now(),mac)||changed;
    }
    now=Clock::now();
    for(auto& peer:peers_) {
        // A lock report must disappear promptly even if its heartbeat remains
        // inside the longer link-loss grace period.
        if(peer.valid && peer.report.sequence && now-peer.lastReportRx>=kPhaseFresh) {
            peer.report={};peer.lastReportRx={};changed=true;
        }
        if(peer.valid && now-peer.lastRx>=kPeerGrace) {
            std::fprintf(stderr,"DECK LINK DIRECT: peer inactive id=%016llx age=%lldms\n",
                static_cast<unsigned long long>(peer.message.id),
                static_cast<long long>(std::chrono::duration_cast<std::chrono::milliseconds>(now-peer.lastRx).count()));
            if(peer.message.id==lastPrimaryId_)lastPrimaryRx_=peer.lastRx;
            peer.valid=false;changed=true;
        }
    }
    // Once an old linked group has fully expired, do not carry its leadership
    // claim into a newly formed group. This preserves first-active election.
    bool hasFreshPeer=false;
    for(const auto& peer:peers_)if(peer.valid && now-peer.lastRx<kPeerGrace)
        hasFreshPeer=true;
    if(!hasFreshPeer) {
        localClaimClock_=0;observedClaimClock_=0;
    }
    if(localMaster_) {
        const auto reference=Clock::now();
        hadSyncedFollowers_=false;
        for(const auto& peer:peers_)if(peer.valid && reference-peer.lastRx<kPhaseFresh &&
           reference-peer.lastReportRx<kPhaseFresh && peer.report.masterId==id_ &&
           peer.report.masterEpoch==epoch_ && peer.report.senderEpoch==peer.epoch &&
           peer.report.beatLocked)hadSyncedFollowers_=true;
    }
    electMaster(local.playing);
    lastPlaying_=local.playing;
    if(localMaster_!=previousLocalMaster)changed=true;
    const Peer* selected=primary(now);
    if(selected) {
        if(selected->message.id!=lastPrimaryId_)changed=true;
        lastPrimaryId_=selected->message.id;
        lastPrimaryRx_=selected->lastRx;
        lastPrimaryHadWaveform_=selected->message.hasWaveform;
        lastPrimaryWaveform_=selected->message.waveform;
        lastPrimaryHadDetail_=selected->detailGeneration!=0 &&
            now-selected->lastDetailRx<std::chrono::seconds(2);
        if(lastPrimaryHadDetail_) {
            lastPrimaryDetailedWaveform_=selected->detailWaveform;
            lastPrimaryDetailCenterSeconds_=selected->detailCenterMs/1000.0;
            lastPrimaryDetailSpanSeconds_=selected->detailSpanMs/1000.0;
            lastPrimaryDeviceNumber_=selected->deviceNumber;
        }
        lastPrimarySourceSeconds_=selected->message.sourceSeconds;
        lastPrimaryGridBpm_=selected->message.gridBpm;
        lastPrimaryPhase_=selected->message.phase;
        lastPrimaryBpm_=selected->message.bpm;
        lastPrimaryPlaying_=selected->message.playing;
        lastPrimaryHasPhase_=selected->message.hasPhase;
        lastPrimaryBeatInBar_=selected->message.beatInBar;
    }
    if((selected!=nullptr)!=previousConnected)changed=true;
    const bool staleNow=!selected && lastPrimaryHadWaveform_ &&
        now-lastPrimaryRx_<std::chrono::seconds(10);
    if(staleNow!=lastStaleState_){lastStaleState_=staleNow;changed=true;}
    if(selected && transport_.available() && now>=nextTimingSend_)
        sendTimingRequest(*selected,now);
    if(transport_.available() && now>=nextSend_) {
        sendMessage(local);
        nextSend_=now+kHeartbeat;
    }
    // Small transport observations must never queue behind bulk waveform
    // fragments. Raw 100Hz music heartbeat is sent just above this block.
    sendMotion(local,now);
    sendGrid(local,now);
    sendDetail(local,now);
    sendTrackView(local,now);
    sendTrackRequests(now);
    sendStaticRequests(now);
    sendStaticAcks(now);
    sendStatic(local,now);
    if(transport_.available() && now>=nextSyncReport_) {
        sendSyncReport(local,now);
        nextSyncReport_=now+std::chrono::milliseconds(100);
    }
    return changed;
}
bool Service::claimMaster() {
    const auto now=Clock::now();
    if(!snapshot().connected || localMaster_ || !allPeersSupport90(now))return false;
    // Explicit claim always outranks automatic election. Heartbeats carry the
    // claim; all peers converge through the existing deterministic comparator.
    localClaimClock_=std::max(localClaimClock_,observedClaimClock_)+1;
    nextSend_={};return true;
}
bool Service::setSyncMode(SyncMode mode) {
    if(static_cast<unsigned>(mode)>2)return false;
    const auto status=snapshot();
    if(!status.connected || status.localMaster || !status.peerMaster)return false;
    syncMode_=mode;
    takeoverMode_=SyncMode::Off; // explicit selection cancels temporary inherited following
    explicitSyncOff_=mode==SyncMode::Off;
    nextSyncReport_={};return true;
}
bool Service::toggleSync() {
    const auto effective=syncMode_!=SyncMode::Off?syncMode_:takeoverMode_;
    return setSyncMode(static_cast<SyncMode>((static_cast<unsigned>(effective)+1)%3));
}
Snapshot Service::snapshot() const noexcept {
    const auto now=Clock::now();
    const Peer* selected=primary(now);
    Snapshot out;
    for(const auto& peer:peers_)if(peer.valid && now-peer.lastRx<kPeerGrace) {
        if(out.peerCount<out.peerIds.size())out.peerIds[out.peerCount]=peer.message.id;
        ++out.peerCount;
    }
    out.connected=selected!=nullptr;
    out.needsLegacyDetail=!allPeersSupport97(now);
    out.localMaster=selected!=nullptr && localMaster_;
    out.syncMode=syncMode_!=SyncMode::Off?syncMode_:takeoverMode_;
    out.takeoverAvailable=selected && !localMaster_ && allPeersSupport90(now);
    out.staleWaveform=!selected && lastPrimaryHadWaveform_ &&
        now-lastPrimaryRx_<std::chrono::seconds(10);
    if(!selected) {
        out.hasWaveform=out.staleWaveform;
        if(out.staleWaveform) {
            out.waveform=lastPrimaryWaveform_;
            out.hasDetailedWaveform=lastPrimaryHadDetail_;
            if(out.hasDetailedWaveform) {
                out.detailWaveform=lastPrimaryDetailedWaveform_;
                out.detailCenterSeconds=lastPrimaryDetailCenterSeconds_;
                out.detailSpanSeconds=lastPrimaryDetailSpanSeconds_;
                out.peerDeviceNumber=lastPrimaryDeviceNumber_;
            }
            out.peerSourceSeconds=lastPrimarySourceSeconds_;
            out.peerGridBpm=lastPrimaryGridBpm_;
            out.peerPhase=lastPrimaryPhase_;
            out.peerBpm=lastPrimaryBpm_;
            out.peerPlaying=lastPrimaryPlaying_;
            out.hasPhase=lastPrimaryHasPhase_;
            out.peerBeatInBar=lastPrimaryBeatInBar_;
        }
        return out;
    }
    const auto& m=selected->message;
    const auto age=now-selected->lastRx;
    const bool phaseFresh=age<kPhaseFresh;
    out.peerId=m.id;
    // If the selected peer is not actual MASTER due to network partitions,
    // synchronizing to it would be incorrect; only follow elected leader.
    std::uint64_t winningClaim=localClaimClock_,winningId=id_;
    for(const auto& peer:peers_)if(peer.valid &&
       DeckLinkElection::peerWins(winningClaim,winningId,
            peer.message.claimClock,peer.message.id)) {
        winningClaim=peer.message.claimClock;winningId=peer.message.id;
    }
    out.peerMaster=!localMaster_ && m.id==winningId;
    out.syncEnabled=out.syncMode!=SyncMode::Off && out.peerMaster && phaseFresh;
    out.peerPlaying=m.playing;
    out.peerBpm=m.bpm;
    // v2.2.102 UI-only mirror. Never infer BEAT lock from BPM equality or
    // role. Old/unreported peers render UNKNOWN, not an invented blue lock.
    std::uint32_t masterEpoch=epoch_;
    if(winningId!=id_) for(const auto& candidate:peers_)
        if(candidate.valid && candidate.message.id==winningId)
            {masterEpoch=candidate.epoch;break;}
    const bool reportMatchesSession=selected->report.mode==SyncMode::Off ||
        (selected->report.masterId==winningId &&
         selected->report.masterEpoch==masterEpoch);
    if(now-selected->lastReportRx<kPhaseFresh &&
       selected->report.senderId==m.id && selected->report.senderEpoch==selected->epoch &&
       selected->report.sequence!=0 && reportMatchesSession) {
        out.peerReportFresh=true;
        out.peerReportedMode=selected->report.mode;
        out.peerReportedTempoApplied=selected->report.tempoApplied;
        out.peerReportedBeatLocked=selected->report.beatLocked;
    }
    out.hasPhase=m.hasPhase && phaseFresh;
    out.hasWaveform=m.hasWaveform;
    out.peerPhase=m.phase;out.peerSourceSeconds=m.sourceSeconds;
    if(selected->visualMotion.valid() &&
       selected->visualMotion.packet().trackGeneration==selected->trackView.generation) {
        out.peerMotionValid=true;
        out.remoteVisualClock=selected->visualMotion;
        out.motion=selected->visualMotion.packet();
        out.lastRemoteMotionRxUs=selected->lastMotionRxUs;
        out.remoteMotionRedrawEvents=selected->motionRedrawEvents;
        out.peerSourceSeconds=selected->visualMotion.position(now);
        out.peerLoopActive=selected->visualMotion.packet().looping;
        out.peerLoopStart=selected->visualMotion.packet().loopStart;
        out.peerLoopEnd=selected->visualMotion.packet().loopEnd;
        out.peerFirstBeatSeconds=selected->visualMotion.packet().firstBeatSeconds;
    }
    out.peerGridBpm=m.gridBpm;out.peerWaveSpanSeconds=m.waveSpanSeconds;
    if(supports100(m)) {
        const auto& grid=selected->grid;
        const bool match=grid.generation==selected->trackView.generation &&
            selected->trackView.valid && selected->visualMotion.valid() &&
            grid.revision==selected->visualMotion.packet().gridRevision;
        // Don't splice a new beat origin into an older BPM observation.
        out.peerGridAtomic=match && grid.valid;
        out.hasPhase=out.hasPhase && out.peerGridAtomic;
        if(out.peerGridAtomic) {
            out.peerGridBpm=grid.bpm;
            out.peerFirstBeatSeconds=grid.firstBeatSeconds;
            out.peerGridRevision=grid.revision;
            // STATUS phase was sampled on a different control tick than the
            // audible, timestamped transport. Prefer a single sample-time
            // beat observation when calibration and identity are coherent.
            // No UI-smoothed VisualClock position is ever used for audio sync.
            const auto& motion=selected->visualMotion.packet();
            const auto receiverNowUs=DeckLinkMotion::monotonicUs(now);
            const double elapsed=receiverNowUs>=selected->lastMotionRxUs &&
                selected->lastMotionRxUs!=0?
                double(receiverNowUs-selected->lastMotionRxUs)*1e-6:-1.0;
            const double captureAge=selected->lastMotionCaptureAgeMs*0.001+elapsed;
            // Only change phase semantics when BOTH ends run the v2.2.118+
            // contract. Older peers continue using their proven status path.
            if(m.major==2 && m.minor==2 && m.patch>=118 &&
               selected->lastMotionCaptureAgeMs>=0.0 &&
               selected->timingValid && now-selected->lastTimingRx<kTimingFresh &&
               selected->lastMotionRxUs && elapsed>=0.0 && elapsed<0.15 &&
               captureAge>=0.0 && captureAge<0.20 &&
               motion.playing==m.playing && grid.bpm>0.0) {
                double observedPhase=0.0;
                if(DeckLinkPhase::capturedAudiblePhase(motion.sourceSeconds,
                        motion.playing?motion.speed:0.0,captureAge,
                        grid.bpm,grid.firstBeatSeconds,motion.looping,
                        motion.loopStart,motion.loopEnd,observedPhase)) {
                    out.peerPhase=observedPhase;
                    out.phaseAtReceiverNow=true; // no double compensation
                }
            }
        }
    }
    out.peerBeatInBar=m.beatInBar;
    out.peerAgeSeconds=std::max(0.0,std::chrono::duration<double>(age).count());
    out.timingValid=selected->timingValid && now-selected->lastTimingRx<kTimingFresh;
    if(out.timingValid) {
        out.estimatedRoundTripMs=selected->roundTripMs;
        out.estimatedClockOffsetMs=selected->clockOffsetMs;
        out.timingSamples=selected->timingSamples;
    }
    out.waveform=m.waveform;
    // Immutable cached track analysis does not expire just because one
    // optional 2-second metadata packet was delayed. The selected peer is
    // already heartbeat-fresh; a NEW motion generation invalidates old data.
    out.hasTrackView=selected->trackView.generation!=0 &&
        selected->trackView.valid;
    if(out.hasTrackView)out.trackView=selected->trackView;
    out.waveTrace=selected->waveTrace;
    out.waveTrace.generation=selected->trackView.generation;
    out.waveTrace.pending=selected->staticAssembler.pending();
    out.waveTrace.pendingGeneration=selected->staticAssembler.pendingGeneration();
    out.waveTrace.complete=bool(selected->staticAssembler.complete());
    const auto staticCache=selected->staticAssembler.complete();
    if(staticCache && out.hasTrackView &&
       staticCache->generation==out.trackView.generation)
        out.staticWave=staticCache;
    out.hasDetailedWaveform=selected->detailGeneration!=0 &&
        now-selected->lastDetailRx<std::chrono::seconds(2);
    if(out.hasDetailedWaveform) {
        out.detailWaveform=selected->detailWaveform;
        out.detailCenterSeconds=selected->detailCenterMs/1000.0;
        out.detailSpanSeconds=selected->detailSpanMs/1000.0;
        out.peerDeviceNumber=selected->deviceNumber;
    }
    // A lock is attributed ONLY to a fresh v90 follower report referencing
    // this exact MASTER identity + process epoch. Peer heartbeat role alone
    // never implies musical sync.
    if(out.localMaster) {
        std::uint8_t locks=0,tempos=0;
        for(const auto& peer:peers_)if(peer.valid && now-peer.lastRx<kPhaseFresh &&
            now-peer.lastReportRx<kPhaseFresh && peer.report.senderEpoch==peer.epoch &&
            peer.report.masterId==id_ && peer.report.masterEpoch==epoch_ &&
            !peer.message.master && peer.report.tempoApplied) {
            ++tempos;
            if(peer.report.beatLocked && peer.report.mode==SyncMode::Beat)++locks;
        }
        out.lockedFollowerCount=locks;out.tempoFollowerCount=tempos;
        // Cache whether there actually was a linked group only via tick(),
        // not by mutating const snapshot.
    }
    // Native Ethernet is not an updater endpoint; the Mac installer provisions
    // each Pi independently. Legacy update agent remains for future IP adapter.
    out.peerUpdateAvailable=false;
    out.peerVersion=std::to_string(m.major)+"."+
        std::to_string(m.minor)+"."+std::to_string(m.patch);
    return out;
}
} // namespace DeckLink
