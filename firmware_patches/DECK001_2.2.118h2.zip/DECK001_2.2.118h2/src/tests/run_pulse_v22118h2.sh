#!/bin/sh
# v2.2.118h2: Pulse C++ vs the PyTorch reference (log-mel, network logits) and a synthetic 128-BPM grid.
set -eu
cd "$(dirname "$0")/.."
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT HUP INT TERM
${CXX:-g++} -std=c++17 -O3 -ffast-math -Wall -Wextra -Wpedantic -I. \
    tests/test_pulse_beat_v22118h2.cpp pulse_beat.cpp -o "$tmp/pulse"
"$tmp/pulse" tests/fixtures/pulse
printf 'PASS v2.2.118h2 PULSE\n'
