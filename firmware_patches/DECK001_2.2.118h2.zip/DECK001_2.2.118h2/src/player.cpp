#include "player.h"
#include "vinyl_scrub.h"
#include "audio_alsa.h"
#include "seamless_live_engine.h"
#include "audio_resample.h"
#include "keylock_wsola.h"
#include "keylock_signalsmith.h"
#include "keylock_transition.h"
#include "transient_map.h"
#include "audio_output_safety.h"
#include "audio_master_limiter.h"
#include "standalone_audio_output.h"
#include "pitch_nudge.h"
#include "fx_processor.h"
#include "mp3_waveform.h"
#include "settings.h"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <utility>
#include <vector>

Player::Player(std::shared_ptr<const Mp3Waveform> track, std::string device,
               std::int64_t initialTransportCue,bool seamlessExperimental,KeylockFftBackend fftBackend,KeylockEngine engine)
    : track_(std::move(track)), seamlessExperimental_(seamlessExperimental), device_(std::move(device)),
      baseBpm_(track_->beatGrid.bpm>0?track_->beatGrid.bpm:120.0),targetBpm_(baseBpm_) {
    if(initialTransportCue>=0 &&
       static_cast<std::uint64_t>(initialTransportCue)<track_->totalFrames) {
        initialSourceFrame_=static_cast<std::uint64_t>(initialTransportCue);
        transportCueFrame_.store(initialTransportCue);
        audiblePosition_.store(initialSourceFrame_);
        audiblePrecisePosition_.store(static_cast<double>(initialSourceFrame_));
    }
    fftBackend_=fftBackend==KeylockFftBackend::Pffft && KeylockSignalsmith::pffftAvailable()?
        KeylockFftBackend::Pffft:KeylockFftBackend::Standard;
    engine_=engine==KeylockEngine::DeckStretch && KeylockDeckStretch::available()?
        KeylockEngine::DeckStretch:KeylockEngine::Standard;
    AudioResample::warmup(); // No coefficient-table construction in audio thread.
    VinylScrub::warmup(); // Stopped-scrub speed-aware sinc tables also built off-worker.
    // Exactly one output worker, regardless of the Seamless Load setting.
    // `seamlessExperimental_` is capability only, not an engine selector.
    thread_ = std::thread(&Player::worker, this);
}
Player::~Player() {
    { std::lock_guard<std::mutex> lock(mutex_); exiting_ = true; }
    wake_.notify_one();
    if (thread_.joinable()) thread_.join();
}
void Player::adjustTempoDetents(int steps) {
    if(!steps) return;
    // Integer tenths avoid drift from repeated changes. Limit normal varispeed
    // to +/-20%, leaving the original beat grid completely untouched.
    const int current=static_cast<int>(std::lround(targetBpm_.load()*10.0));
    const int lo=static_cast<int>(std::ceil(baseBpm_*8.0));
    const int hi=static_cast<int>(std::floor(baseBpm_*12.0));
    targetBpm_.store(std::clamp(current+steps,lo,hi)*0.1);
}
void Player::resetTempo() { targetBpm_.store(baseBpm_); }
bool Player::setLinkedTempoBpm(double bpm) noexcept {
    if(!std::isfinite(bpm) || bpm<=0 || !std::isfinite(baseBpm_) || baseBpm_<=0)
        return false;
    // Linked sync must follow the peer's exact tempo. Rounding it to 0.1 BPM (as the
    // manual tempo steps do) leaves up to 0.05 BPM of error, which drifts ~20 ms per
    // minute at 126 BPM and is never corrected in BPM-only sync.
    if(bpm<baseBpm_*0.8 || bpm>baseBpm_*1.2)return false;
    targetBpm_.store(bpm,std::memory_order_relaxed);
    return true;
}
bool Player::setKeyShift(int semitones) {
    std::lock_guard<std::mutex> lock(mutex_);
    const int handover=seamlessStatus_.load(std::memory_order_relaxed);
    if((handover==2 || handover==3) || (semitones!=0 && !KeylockSpectral::anyAvailable()))return false;
    keyShift_=std::clamp(semitones,-6,6);
    return true;
}
bool Player::beginScrub() {
    std::lock_guard<std::mutex> lock(mutex_);
    if(!track_ || track_->totalFrames<2 ||
       track_->pcmStereo.size()/2<track_->totalFrames || requestedPlaying_.load() ||
       audioMotion_.load() || targetPlaying_ || navigationPending_ || visualPreview_ ||
       seamlessStatus_.load()!=0 || exiting_)return false;
    scrubTouchTimestampNs_=0;
    scrubTarget_=std::clamp(audiblePrecisePosition_.load(),0.0,
        double(track_->totalFrames-1));
    scrubGesture_=true;
    scrubPendingCommit_=true;
    scrubVisualTarget_.store(scrubTarget_);
    scrubVisualActive_.store(true);
    ++scrubRevision_;
    wake_.notify_one();
    return true;
}
void Player::moveScrub(double frame) {
    std::lock_guard<std::mutex> lock(mutex_);
    if(!scrubGesture_ || requestedPlaying_.load() || targetPlaying_ ||
       audioMotion_.load() || !track_ || !track_->totalFrames)return;
    scrubTarget_=std::clamp(frame,0.0,double(track_->totalFrames-1));
    scrubTouchTimestampNs_=static_cast<std::uint64_t>(std::chrono::duration_cast<
        std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count());
    scrubVisualTarget_.store(scrubTarget_);
    ++scrubRevision_;
    wake_.notify_one();
}
void Player::endScrub() noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    if(!scrubGesture_)return;
    scrubGesture_=false;
    ++scrubRevision_;
    wake_.notify_one();
}
void Player::toggle() { if (requestedPlaying_.load()) stopVinyl(); else start(); }
void Player::start() {
    {
        std::lock_guard<std::mutex> lock(mutex_);
        scrubGesture_=false;
        ++scrubRevision_;
        scrubVisualActive_.store(false);
        const bool freshStart=!audioMotion_.load();
        if(freshStart) {
            // The first PLAY frame must not extrapolate the previous ALSA
            // session's timestamp (B10). Hold the exact stopped/CUE frame
            // until our worker reports genuinely audible new-session data.
            visualStartFrame_.store(scrubPendingCommit_ ? scrubTarget_ :
                                    audiblePrecisePosition_.load());
            visualStartPending_.store(true);
            audibleTimestampNs_.store(0);
            visualEpoch_.fetch_add(1);
        }
        targetPlaying_ = true;
        ++transportRequestSerial_;
        requestedPlaying_.store(true);
        audioMotion_.store(true); // UI scheduling follows the latest transport request.
    }
    wake_.notify_one();
}
bool Player::offerSeamless(std::unique_ptr<DeckAudio::LiveResidentSource> incoming) {
    if(!seamlessExperimental_ || !incoming || !requestedPlaying_.load())return false;
    std::unique_ptr<DeckAudio::LiveResidentSource> previousFailure;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        const auto status=seamlessStatus_.load();
        if((status!=0 && status!=4) || seamlessIncoming_)return false;
        if(status==4) {
            for(auto& retired:seamlessRetired_)if(retired) {
                previousFailure=std::move(retired);break;
            }
            seamlessError_.clear();
        }
        // Reserve a mailbox slot for the next worker completion. If the UI
        // has not reclaimed previous jobs, decline this offer on the UI thread.
        bool freeSlot=false;
        for(const auto& retired:seamlessRetired_)if(!retired){freeSlot=true;break;}
        if(!freeSlot)return false;
        seamlessDecision_.store(0,std::memory_order_release);
        pendingSeamlessEngine_=incoming->keylockEngine();
        pendingSeamlessFft_=incoming->keylockFftBackend();
        seamlessIncoming_=std::move(incoming);
        seamlessAudibleIncomingGain_.store(0.0f,std::memory_order_release);
        seamlessAudibleIncomingValid_.store(false,std::memory_order_release);
        seamlessStatus_.store(1,std::memory_order_release);
    }
    // Failed B's PCM is freed on the UI thread, never the worker.
    previousFailure.reset();
    wake_.notify_one();return true;
}
std::unique_ptr<DeckAudio::LiveResidentSource> Player::releaseRetiredSeamless() {
    std::lock_guard<std::mutex> lock(mutex_);
    for(auto& retired:seamlessRetired_)if(retired)return std::move(retired);
    return {};
}
std::string Player::seamlessError() const {
    std::lock_guard<std::mutex> lock(mutex_);return seamlessError_;
}
bool Player::adoptSeamlessTrack(std::shared_ptr<const Mp3Waveform> incoming,std::int64_t initialCue) {
    if(!seamlessExperimental_ || !incoming || seamlessStatus_.load()!=3)return false;
    std::lock_guard<std::mutex> lock(mutex_);
    if(seamlessStatus_.load()!=3)return false;
    // The worker owns its independent live source. UI-side track_ changes
    // only after the current mixer source has been promoted.
    track_=std::move(incoming);
    engine_=pendingSeamlessEngine_;
    fftBackend_=pendingSeamlessFft_;
    baseBpm_=track_->beatGrid.bpm>0?track_->beatGrid.bpm:120.;
    if(initialCue>=0 && std::uint64_t(initialCue)<track_->totalFrames)
        transportCueFrame_.store(initialCue);
    else transportCueFrame_.store(-1);
    loop_={};loopHalfBeatStep_.reset();loopDragHalfBeatStep_.reset();
    navigationPending_=false;visualPreview_=false;
    ++previewSerial_;previewFramesRemaining_.store(0);
    seamlessStatus_.store(0,std::memory_order_release);
    seamlessAudibleIncomingGain_.store(0.0f,std::memory_order_release);
    visualEpoch_.fetch_add(1);
    return true;
}
void Player::fadeOutForTrackChange() {
    if (!audioMotion_.load()) return;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        trackChangeFadeRequested_ = true;
        targetPlaying_ = false;
        ++transportRequestSerial_;
        requestedPlaying_.store(false);
    }
    wake_.notify_one();
    // The worker sets audioMotion_ false only AFTER snd_pcm_drain(). This
    // prevents the old ALSA device from dropping a live waveform mid-sample.
    std::unique_lock<std::mutex> lock(mutex_);
    wake_.wait(lock,[&]{return !audioMotion_.load() || !lastError_.empty();});
}
void Player::stopVinyl() {
    {
        std::lock_guard<std::mutex> lock(mutex_);
        targetPlaying_ = false;
        ++transportRequestSerial_;
        requestedPlaying_.store(false);
    }
    wake_.notify_one();
}
bool Player::setTransportCueAtCurrent() {
    if(audioMotion_.load() || requestedPlaying_.load())return false;
    const auto frame=position(); // protects any pending navigation preview
    if(frame>=track_->totalFrames)return false;
    transportCueFrame_.store(static_cast<std::int64_t>(frame));
    return true;
}
bool Player::atTransportCue() const {
    const auto cue=transportCueFrame_.load();
    if(cue<0 || audioMotion_.load())return false;
    // Tolerate the final fractional sample of a completed stop/seek.
    const auto at=static_cast<std::int64_t>(position());
    return std::llabs(at-cue)<=std::max(1,track_->sampleRate/1000);
}
void Player::returnToTransportCue() {
    if(transportCueFrame_.load()<0)return;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        cueReturnPending_=true;
        targetPlaying_=false;
        ++transportRequestSerial_;
        requestedPlaying_.store(false);
    }
    wake_.notify_one();
}

bool Player::startTransportCuePreview() {
    const auto cue=transportCueFrame_.load();
    if(cue<0 || static_cast<std::uint64_t>(cue)>=track_->totalFrames)return false;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        // Rapid CUE taps must supersede the old return/fade, not be rejected
        // because the audio queue is still settling after the prior release.
        cueReturnPending_=false;
        pendingShiftActive_=false;pendingShiftFrames_=0;
        Navigation next{};
        next.target=static_cast<std::uint64_t>(cue);
        if(!audioMotion_.load()) {
            visualStartFrame_.store(static_cast<double>(cue));
            visualStartPending_.store(true);
            audibleTimestampNs_.store(0);
            visualEpoch_.fetch_add(1);
        }
        next.loop=loop_;
        if(next.loop.active && (next.target<next.loop.start || next.target>=next.loop.end))
            next.loop.active=false;
        next.activateLoopOnCommit=next.loop.active!=loop_.active;
        next.quantized=false;
        next.transportCuePreview=true;
        queueNavigationLocked(next);
        targetPlaying_=true;
        ++transportRequestSerial_;
        requestedPlaying_.store(true);
        audioMotion_.store(true);
    }
    wake_.notify_one();
    return true;
}
void Player::triggerPerformanceCue(std::uint64_t frame,bool quantized,BeatNavigation::Grid grid) {
    if(frame>=track_->totalFrames)return;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        const bool wasPlaying=requestedPlaying_.load();
        Navigation next{};
        next.target=frame;
        next.loop=visualPreview_?previewLoop_:loop_;
        if(next.loop.active && (frame<next.loop.start || frame>=next.loop.end))
            next.loop.active=false;
        next.activateLoopOnCommit=true;
        next.quantized=wasPlaying && quantized && grid.valid();
        next.matchCuePhase=next.quantized;
        next.grid=grid;
        pendingShiftActive_=false;pendingShiftFrames_=0;
        queueNavigationLocked(next);
        // An incoming performance CUE is newer transport intent even if
        // a previous stop is currently waiting in the ALSA drain.
        ++transportRequestSerial_;
        if(!wasPlaying) {
            targetPlaying_=true;requestedPlaying_.store(true);audioMotion_.store(true);
        }
    }
    wake_.notify_one();
}
void Player::triggerPerformanceLoop(std::uint64_t first,std::uint64_t end,
                                    bool quantized,BeatNavigation::Grid grid) {
    if(first>=end || end>track_->totalFrames)return;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        const bool wasPlaying=requestedPlaying_.load();
        Navigation next{};
        next.target=first;
        next.loop={true,first,end};
        next.activateLoopOnCommit=true; // do not change loop_ early
        next.quantized=wasPlaying && quantized && grid.valid();
        next.matchCuePhase=next.quantized;
        next.grid=grid;
        pendingShiftActive_=false;pendingShiftFrames_=0;
        queueNavigationLocked(next);
        // An incoming performance CUE is newer transport intent even if
        // a previous stop is currently waiting in the ALSA drain.
        ++transportRequestSerial_;
        if(!wasPlaying) {
            targetPlaying_=true;requestedPlaying_.store(true);audioMotion_.store(true);
        }
    }
    wake_.notify_one();
}

double Player::audibleSourceTravelEstimate() const {
    double travel = audibleSourceTravel_.load();
    const auto stamped = audibleTimestampNs_.load();
    if (audioMotion_.load() && stamped > 0) {
        const auto now = std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();
        const double seconds = std::clamp((now - stamped) * 1e-9,
            0.0, Settings::kVisualClockMaxExtrapolationMs * 0.001);
        travel += seconds * track_->sampleRate *
                  std::max(0.0, audiblePlaybackSpeed_.load());
    }
    return travel;
}
double Player::previewPreciseFrameLocked() const {
    if (!visualPreview_) return static_cast<double>(audiblePosition_.load());
    if (track_->totalFrames == 0) return 0.0;
    // A saved CUE target is an ABSOLUTE source position. While the audio
    // worker waits for the quantize beat, it has not begun playback from
    // that point. Advancing it from the press time caused a visible rewind
    // (often perceived as a stutter) on the audible handoff. Beatjump is
    // relative to the live head and deliberately keeps advancing instead.
    if (previewFixedUntilAudible_)
        return static_cast<double>(previewPosition_);
    // Source travel is recorded with the SAME audible ALSA history as the
    // waveform position. A slowed track now advances its preview at 0.84x,
    // not 1.0x; this clock remains monotonic across loop wraps.
    const double advanced = std::max(0.0,
        audibleSourceTravelEstimate() - previewSourceTravelAtRequest_);
    const double maximum = static_cast<double>(track_->totalFrames - 1);
    double position = std::clamp(static_cast<double>(previewPosition_) + advanced,
                                 0.0, maximum);
    if (previewLoop_.active && previewLoop_.end > previewLoop_.start) {
        const double length = static_cast<double>(previewLoop_.end - previewLoop_.start);
        const double relative = std::max(0.0, position - previewLoop_.start);
        position = previewLoop_.start + std::fmod(relative, length);
    }
    return position;
}

double Player::seamlessIncomingVisualPosition() const noexcept {
    // Before the first B sample is audible the prepared cursor is stationary;
    // showing its pre-roll source start is correct. No render-ahead movement.
    if(!seamlessAudibleIncomingValid_.load(std::memory_order_acquire))
        return seamlessIncomingCursor_.load(std::memory_order_relaxed);
    const double audible=seamlessAudibleIncomingCursor_.load(std::memory_order_relaxed);
    const auto stamped=audibleTimestampNs_.load(std::memory_order_acquire);
    if(stamped<=0)return audible;
    const auto now=std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
    const double elapsed=std::clamp((now-stamped)*1e-9,0.0,
        Settings::kVisualClockMaxExtrapolationMs*0.001);
    return std::max(0.0,audible+elapsed*
        std::max(0.0,seamlessAudibleIncomingSpeed_.load(std::memory_order_relaxed)));
}

std::uint64_t Player::previewFrameLocked() const {
    return static_cast<std::uint64_t>(previewPreciseFrameLocked());
}
std::uint64_t Player::position() const {
    if(scrubVisualActive_.load())return static_cast<std::uint64_t>(scrubVisualTarget_.load());
    std::lock_guard<std::mutex> lock(mutex_);
    return previewFrameLocked();
}
VisualTransport Player::visualTransport() const {
    if(scrubVisualActive_.load()) {
        VisualTransport state{};
        state.precisePosition=scrubVisualTarget_.load();
        state.position=static_cast<std::uint64_t>(state.precisePosition);
        state.visualSerial=visualEpoch_.load();
        return state;
    }
    std::lock_guard<std::mutex> lock(mutex_);
    VisualTransport state{};
    state.position = previewFrameLocked();
    state.precisePosition = previewPreciseFrameLocked();
    state.sourceFramesPerSecond = audioMotion_.load() &&
        !(visualPreview_ && previewFixedUntilAudible_) ?
        std::max(0.0,audiblePlaybackSpeed_.load())*track_->sampleRate : 0.0;
    state.visualSerial = (previewSerial_ << 32) ^ visualEpoch_.load();
    state.awaitingFreshAudio=visualStartPending_.load();
    if(state.awaitingFreshAudio) {
        // The waveform remains at the known stopped/CUE position until the
        // first new sample is confirmed audible. No interpolation, no seek.
        state.precisePosition=visualStartFrame_.load();
        state.position=static_cast<std::uint64_t>(state.precisePosition);
        state.sourceFramesPerSecond=0.0;
        return state;
    }
    if (!visualPreview_) {
        // ALSA reports the actually audible frame only when the PCM worker
        // finishes a chunk. Interpolate the fractional visual position between
        // those reports; never drive playback from this display prediction.
        const double exact = audiblePrecisePosition_.load();
        const auto stamped = audibleTimestampNs_.load();
        double estimate = exact;
        if (audioMotion_.load() && stamped > 0) {
            const auto now = std::chrono::duration_cast<std::chrono::nanoseconds>(
                std::chrono::steady_clock::now().time_since_epoch()).count();
            const double seconds = std::clamp((now - stamped) * 1e-9,
                0.0, Settings::kVisualClockMaxExtrapolationMs * 0.001);
            estimate += seconds * track_->sampleRate * audiblePlaybackSpeed_.load();
            if (loop_.active && !loop_.boundarySlide &&
                loop_.end > loop_.start && estimate >= loop_.end) {
                const double length = static_cast<double>(loop_.end-loop_.start);
                estimate = loop_.start + std::fmod(estimate-loop_.start,length);
            }
        }
        state.precisePosition = std::clamp(estimate, 0.0,
            static_cast<double>(track_->totalFrames ? track_->totalFrames-1 : 0));
    }
    state.pendingQuantizedJump = visualPreview_ && previewQuantized_ &&
                                 requestedPlaying_.load();
    state.pendingRelativeLoopMove = visualPreview_ && previewRelativeShift_;
    if (state.pendingQuantizedJump && track_->sampleRate > 0) {
        // The ghost is drawn on the SOURCE timeline, not the wall clock.
        // Count remaining output frames, then convert using actual tempo.
        state.secondsUntilJump = static_cast<double>(previewFramesRemaining_.load()) /
            static_cast<double>(track_->sampleRate) *
            std::max(0.0, audiblePlaybackSpeed_.load());
    }
    return state;
}
bool Player::previewPending() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return visualPreview_;
}
#if defined(DECK001_B12_TRACE)
Player::B12VisualSnapshot Player::b12VisualSnapshot() const {
    std::lock_guard<std::mutex> lock(mutex_);
    B12VisualSnapshot snapshot{};
    snapshot.transportRequest=transportRequestSerial_;
    snapshot.navigationSerial=previewSerial_;
    snapshot.visualEpoch=visualEpoch_.load();
    snapshot.targetPlaying=targetPlaying_;
    snapshot.audioMotion=audioMotion_.load();
    snapshot.cueReturnPending=cueReturnPending_;
    snapshot.visualPreview=visualPreview_;
    snapshot.quantizedPreview=previewQuantized_;
    snapshot.fixedPreview=previewFixedUntilAudible_;
    snapshot.visualStartPending=visualStartPending_.load();
    snapshot.audiblePrecise=audiblePrecisePosition_.load();
    snapshot.audibleSpeed=audiblePlaybackSpeed_.load();
    snapshot.audibleOutputClock=audibleOutputClock_.load();
    snapshot.audibleTimestampNs=audibleTimestampNs_.load();
    return snapshot;
}
#endif
void Player::seek(std::uint64_t frame) { navigateTo(frame,false,{}); }
void Player::queueNavigationLocked(Navigation command) {
    command.serial = ++previewSerial_;
    command.loopRevision = loopRevision_;
    command.previewClockAtRequest = audibleOutputClock_.load();
    navigation_ = command;
    navigationPending_ = true;
    const bool alreadyWaiting = visualPreview_ && previewQuantized_;
    visualPreview_ = true;
    previewPosition_ = command.target;
    previewLoop_ = command.loop;
    previewStartOutputFrame_ = audibleOutputClock_.load();
    previewSourceTravelAtRequest_ = audibleSourceTravelEstimate();
    previewQuantized_ = command.quantized && requestedPlaying_.load();
    previewRelativeShift_ = command.relativeShift;
    // An absolute CUE waits at its saved position for a phase match. The
    // preview for a relative move keeps advancing with the audio head.
    previewFixedUntilAudible_ = previewQuantized_ && !command.relativeShift;
    if (previewQuantized_ && command.grid.valid() && !alreadyWaiting) {
        // The UI does not know whether the worker has already crossed the
        // next beat (ALSA's audible head lags its render head). Until the
        // worker reports an exact output-frame countdown, use a conservative
        // quantize-cycle upper bound plus two small chunks of queue headroom. This
        // avoids the ghost first moving BACKWARDS as timing becomes known.
        const double measuredSpeed = audiblePlaybackSpeed_.load();
        const double audibleSpeed = measuredSpeed > 0.1 ? measuredSpeed :
            std::max(0.6, targetBpm_.load()/baseBpm_);
        const double maxSourceWait=BeatNavigation::quantizeInterval(command.grid,command.matchCuePhase);
        const double estimate = (maxSourceWait +
            2.0 * Settings::kAudioChunkFrames) / audibleSpeed;
        previewFramesRemaining_.store(static_cast<std::uint64_t>(std::ceil(estimate)));
    } else if (!previewQuantized_) previewFramesRemaining_.store(0);
    wake_.notify_one();
}
void Player::navigateTo(std::uint64_t frame,bool quantized,BeatNavigation::Grid grid) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (track_->totalFrames == 0) return;
    const std::uint64_t base = visualPreview_ ? previewFrameLocked() : audiblePosition_.load();
    LoopRegion region = visualPreview_ ? previewLoop_ : loop_;
    const double requested=static_cast<double>(std::min(frame,track_->totalFrames-1));
    // Quantization means preservation of beat/bar phase. Do not round the
    // source position to a different beat, then start audio halfway into it.
    const double target=quantized && grid.valid()
        ? BeatNavigation::barPhaseMatchedTarget(requested,static_cast<double>(base),grid)
        : requested;
    if(target<0 || target>=track_->totalFrames) return;
    const auto delta=static_cast<std::int64_t>(std::llround(target))-static_cast<std::int64_t>(base);
    if(region.active) {
        std::uint64_t a=0,b=0;
        if(!BeatNavigation::shiftLoop(region.start,region.end,track_->totalFrames,delta,a,b)) return;
        region.start=a;region.end=b;
    }
    const bool phaseLocked = quantized && grid.valid();
    if(phaseLocked) {
        if(!pendingShiftActive_) pendingShiftFrames_=0;
        pendingShiftFrames_+=delta;
        pendingShiftActive_=true;
    } else {pendingShiftActive_=false;pendingShiftFrames_=0;}
    Navigation command{};
    command.target=static_cast<std::uint64_t>(std::llround(target));
    command.loop=region;
    command.quantized=phaseLocked;
    command.grid=grid;
    command.relativeShift=phaseLocked;
    command.shiftFrames=phaseLocked?pendingShiftFrames_:0;
    queueNavigationLocked(command);
}
bool Player::queueRelativeShiftLocked(std::int64_t delta,bool quantized,
                                      BeatNavigation::Grid grid,bool requireActiveLoop) {
    // One lock / one scheduling path for both Beatjump and SHIFT+LOOP.
    // Keep a later request's preview as the anchor, not an older audio head.
    if(delta==0 || track_->totalFrames==0) return false;
    const std::uint64_t base=visualPreview_ ? previewFrameLocked() : audiblePosition_.load();
    LoopRegion region=visualPreview_ ? previewLoop_ : loop_;
    if(requireActiveLoop && (!region.active || region.end<=region.start)) return false;
    const auto dest=static_cast<std::int64_t>(base)+delta;
    if(dest<0 || dest>=static_cast<std::int64_t>(track_->totalFrames)) return false;
    if(region.active) {
        std::uint64_t a=0,b=0;
        if(!BeatNavigation::shiftLoop(region.start,region.end,track_->totalFrames,delta,a,b)) return false;
        region.start=a;region.end=b;
    }
    if(!pendingShiftActive_) pendingShiftFrames_=0;
    pendingShiftFrames_+=delta;
    pendingShiftActive_=true;
    Navigation command{};
    command.target=static_cast<std::uint64_t>(dest);
    command.loop=region;
    command.quantized=quantized && grid.valid();
    command.grid=grid;
    // Relative navigation preserves the LIVE audible phase during handoff.
    // The existing 9 ms crossfade handles active playback without ALSA flush.
    command.relativeShift=true;
    command.loopMove=requireActiveLoop;
    command.shiftFrames=pendingShiftFrames_;
    queueNavigationLocked(command);
    return true;
}
void Player::beatJump(int direction,int beats,bool quantized,BeatNavigation::Grid grid) {
    if (!grid.valid() || beats<=0 || (direction!=-1 && direction!=1)) return;
    std::lock_guard<std::mutex> lock(mutex_);
    queueRelativeShiftLocked(BeatNavigation::beatOffset(direction*beats,grid),quantized,grid,false);
}
void Player::moveActiveLoop(int detents,bool quantized,BeatNavigation::Grid grid) {
    // SHIFT+LOOP moves by half a beat per detent. Q schedules the handoff
    // without rounding the relocation itself or changing the loop length.
    if(!detents || !grid.valid())return;
    std::lock_guard<std::mutex> lock(mutex_);
    const LoopRegion region=visualPreview_ ? previewLoop_ : loop_;
    if(!region.active || region.end<=region.start || region.end>track_->totalFrames)return;
    std::int64_t offset=0;
    if(!loopHalfBeatStep_.propose(detents,grid.framesPerBeat,offset))return;
    // Reject an entire detent request at either track boundary: don't clip,
    // resize, create, or silently relocate the loop by a smaller amount.
    std::uint64_t movedStart=0,movedEnd=0;
    if(!BeatNavigation::shiftLoop(region.start,region.end,track_->totalFrames,
                                  offset,movedStart,movedEnd))return;
    if(queueRelativeShiftLocked(offset,quantized,grid,true))
        loopHalfBeatStep_.commit(detents,offset);
}
bool Player::slideActiveLoop(int halfBeatSteps, BeatNavigation::Grid grid) {
    if(!halfBeatSteps || !grid.valid())return false;
    std::lock_guard<std::mutex> lock(mutex_);
    // Do not silently merge an active CUE/beatjump navigation with a touch
    // slide; the latter must have no preview, ghost or transport epoch.
    if(visualPreview_ || navigationPending_ || !track_ || !track_->totalFrames)return false;
    const auto previous=loop_;
    if(!previous.active || previous.end<=previous.start ||
       previous.end>track_->totalFrames)return false;
    std::int64_t delta=0;
    if(!loopDragHalfBeatStep_.propose(halfBeatSteps,grid.framesPerBeat,delta))return false;
    std::uint64_t first=0,end=0;
    if(!BeatNavigation::shiftLoop(previous.start,previous.end,track_->totalFrames,
                                  delta,first,end))return false;
    // Strong invariant: neither visual nor audible loop length may change.
    if(end-first!=previous.end-previous.start)return false;
    loop_.start=first;
    loop_.end=end;
    loop_.boundarySlide=true;
    ++loopRevision_;
    loopDragHalfBeatStep_.commit(halfBeatSteps,delta);
    // Audio worker receives bounds at the next PCM chunk. No seek, no
    // navigation queue, no transport restart, no playhead preview.
    wake_.notify_one();
    return true;
}
void Player::cancelLoopMoveLocked() {
    if(!visualPreview_ || !navigation_.loopMove)return;
    ++previewSerial_;
    navigationPending_=false;
    visualPreview_=false;
    pendingShiftActive_=false;
    pendingShiftFrames_=0;
    previewFramesRemaining_.store(0);
}
void Player::setLoop(std::uint64_t start,std::uint64_t end,bool armAhead) {
    if(end>track_->totalFrames || start>=end) return;
    { std::lock_guard<std::mutex> lock(mutex_);
      loop_={true,start,end,armAhead};
      loopHalfBeatStep_.reset();
      loopDragHalfBeatStep_.reset();
      ++loopRevision_;
      cancelLoopMoveLocked();
      if(navigationPending_) {navigation_.loop=loop_;navigation_.loopRevision=loopRevision_;}
      if(visualPreview_) previewLoop_=loop_;
    }
    wake_.notify_one();
}
void Player::clearLoopLocked() {
    loop_.active=false;
    loopHalfBeatStep_.reset();
    loopDragHalfBeatStep_.reset();
    ++loopRevision_;
    cancelLoopMoveLocked();
    if(navigationPending_) {navigation_.loop=loop_;navigation_.loopRevision=loopRevision_;}
    if(visualPreview_) previewLoop_.active=false;
}
void Player::clearLoop() {
    { std::lock_guard<std::mutex> lock(mutex_);clearLoopLocked(); }
    wake_.notify_one();
}
void Player::clearLoopAndBypassFx() {
    { std::lock_guard<std::mutex> lock(mutex_);
      clearLoopLocked();
      fxPacked_.fetch_or(kFxBypassBit,std::memory_order_relaxed);
    }
    wake_.notify_one();
}
LoopRegion Player::loop() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return visualPreview_ ? previewLoop_ : loop_;
}
std::string Player::error() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return lastError_;
}

// Unified real-time Player worker. One instance of LiveResidentSource renders
// every ordinary track; Seamless Load adds a *second instance of the same
// class* to the same mixer/output. No alternative transport/navigation loop.
// Non-44.1 kHz material keeps its native ALSA output rate; it can play
// normally but will not offer a seamless transition until matching-rate
// source support is explicitly enabled by the app's readiness policy.
void Player::worker() {
    try {
        const unsigned rate=static_cast<unsigned>(track_->sampleRate);
        std::unique_ptr<AudioAlsa> device;
        try {device=std::make_unique<AudioAlsa>(device_,rate,Settings::kAlsaLatencyMicroseconds);}
        catch(const std::exception& e) {
            if(device_=="default")throw;
            std::cerr<<"Optional ALSA device unavailable: "<<e.what()<<"; default fallback\n";
            device=std::make_unique<AudioAlsa>("default",rate,Settings::kAlsaLatencyMicroseconds);
        }
        const double initialBpm=targetBpm_.load();
        const auto first=std::min<std::uint64_t>(initialSourceFrame_,track_->totalFrames-1);
        DeckAudio::LiveSeamlessMixer mixer(
            DeckAudio::LiveResidentSource(track_,initialBpm,rate,false,first,fftBackend_,engine_),rate);
        std::array<float,Settings::kAudioChunkFrames*2> pcm{};
        std::array<std::int32_t,Settings::kAudioChunkFrames*2> output{};
        std::array<float,Settings::kAudioChunkFrames> vinylRates{};
        std::array<float,Settings::kAudioChunkFrames> networkRates{};
        // Hardware SHIFT nudge is a *pitched* ±10% motor adjustment. The
        // musical grid/selected BPM stay unchanged; per-sample nudge is
        // handled in the same per-track renderer used by seamless sources.
        PitchNudge pitchNudge;
        // Servo tick uses the audio worker's monotonic cadence (~50ms), NOT
        // the variable UI frame rate. Its output is a separate tempo factor.
        DeckLinkPhase::Servo linkServo;
        double linkedTrimSmooth=0.0;
        const double trimAlpha=1.0/(rate*0.080);
        DeckFx::Processor masterFx(rate); // bounded audio-worker allocation only, before playback
        DeckAudio::MasterPeakLimiter masterLimiter(rate);
        VinylScrub::Reader scrubReader(rate);
        bool scrubPcmQueued=false;
        std::uint64_t seenScrubRevision=0;
        std::array<double,Settings::kAudioChunkFrames> renderedCursors{};
        std::array<double,Settings::kAudioChunkFrames> renderedIncomingCursors{};
        std::array<float,Settings::kAudioChunkFrames> renderedMixGain{};
        std::array<float,Settings::kAudioPositionHistoryFrames> audibleMixGain{};
        std::array<double,Settings::kAudioPositionHistoryFrames> audibleFrames{};
        std::array<double,Settings::kAudioPositionHistoryFrames> audibleIncomingFrames{};
        std::array<double,Settings::kAudioPositionHistoryFrames> audibleIncomingSpeeds{};
        std::array<double,Settings::kAudioPositionHistoryFrames> audibleSpeeds{};
        std::uint64_t historyWritten=0;
        // B10: historyWritten is cumulative across snd_pcm_drain()/prepare().
        // After a completed CUE return, ALSA can briefly report queue depths
        // that reach into the previous playback session's position ring.
        // Only positions produced after this session's first output frame may
        // become authoritative visual samples. No PCM or ALSA timing changes.
        std::uint64_t playbackSessionFirstOutputFrame=0;
        // Separate local ALSA queue epoch from the monotonically advancing
        // source-travel clock. A seek, loop wrap or promoted track must NOT
        // re-use a stale preview baseline (B09/B12 parity).
        std::array<double,Settings::kAudioPositionHistoryFrames> audibleTravels{};
        double sourceTravel=0.0;
        std::uint64_t lastAudibleLocal=0;
        bool outputClockInitialized=false;
        Navigation scheduled{};
        bool hasScheduled=false;
        double framesUntilJump=0.0;
        std::uint64_t commitOutputFrame=0,commitSerial=0;
        // Capture the outgoing processed audio before resetting the source.
        // The buffer is allocated once, and reused for each short handoff.
        std::vector<std::array<float,2>> jumpTail(std::max(1u,rate*Settings::kJumpCrossfadeMs/1000));
        std::size_t jumpFade=jumpTail.size();
        const auto blendJump=[&](std::array<float,2> next,std::size_t index) {
            const auto& previous=jumpTail[index];
            const double mix=double(index+1)/jumpTail.size();
            return std::array<float,2>{
                float(AudioResample::blend(previous[0],next[0],mix)),
                float(AudioResample::blend(previous[1],next[1],mix))};
        };
        const auto captureJumpTail=[&](std::uint64_t outputOffset) {
            for(std::size_t i=0;i<jumpTail.size();++i) {
                const auto envelope=std::min<std::size_t>(outputOffset+i,vinylRates.size()-1);
                auto sample=mixer.active().render(vinylRates[envelope]);
                if(jumpFade+i<jumpTail.size())sample=blendJump(sample,jumpFade+i);
                jumpTail[i]=sample;
            }
            jumpFade=0;
        };
        // Audio promotion is a render-side event, but the UI must promote on
        // the *audible* output epoch. Otherwise the purple waveform disappears
        // while the last outgoing PCM is still sitting in the ALSA queue.
        bool promotionPending=false;
        std::uint64_t promotionAudibleOutputFrame=0;
        enum class StopType {None,Vinyl,Cue,TrackChange};
        StopType stopType=StopType::None;
        bool playing=false,stopping=false,pendingCueStop=false,starting=false;
        unsigned ramp=0;
        const unsigned startFrames=std::max(1u,rate*Settings::kStartRampMs/1000);
        const unsigned vinylFrames=std::max(1u,rate*Settings::kStopRampMs/1000);
        const unsigned cueFrames=std::max(1u,rate*12/1000);
        const unsigned trackChangeFrames=std::max(1u,rate*Settings::kTrackChangeFadeMs/1000);
        std::uint64_t cueStopSerial=0;
        LoopRegion appliedLoop{};
        while(true) {
            const bool outputWasPlaying=playing;
            bool want=false,hasNav=false,cueReturn=false,changeFade=false;
            bool scrubGesture=false,scrubCommitPending=false;
            double scrubTarget=0.0;
            std::uint64_t scrubTouchTimestampNs=0;
            std::uint64_t observedSerial=0;
            Navigation nav{};
            LoopRegion loop{};
            unsigned fxSnapshot=0;
            int keyShift=0;
            std::unique_ptr<DeckAudio::LiveResidentSource> incoming;
            {
                std::unique_lock<std::mutex> lock(mutex_);
                if(!playing && !stopping && !targetPlaying_ && !navigationPending_ &&
                   !cueReturnPending_ && !seamlessIncoming_ && !exiting_ &&
                   !scrubPcmQueued && !scrubReader.needsOutput() &&
                   seenScrubRevision==scrubRevision_)
                    wake_.wait(lock,[&]{return exiting_ || targetPlaying_ || navigationPending_ ||
                        cueReturnPending_ || seamlessIncoming_ || trackChangeFadeRequested_ ||
                        seenScrubRevision!=scrubRevision_;});
                if(exiting_)break;
                scrubGesture=scrubGesture_;
                scrubCommitPending=scrubPendingCommit_;
                scrubTarget=scrubTarget_;
                scrubTouchTimestampNs=scrubTouchTimestampNs_;
                seenScrubRevision=scrubRevision_;
                want=targetPlaying_;
                observedSerial=transportRequestSerial_;
                hasNav=navigationPending_;nav=navigation_;navigationPending_=false;
                if(hasScheduled && !hasNav && scheduled.serial!=previewSerial_)hasScheduled=false;
                cueReturn=cueReturnPending_;cueReturnPending_=false;
                changeFade=trackChangeFadeRequested_;trackChangeFadeRequested_=false;
                loop=loop_;
                fxSnapshot=fxPacked_.load(std::memory_order_relaxed);
                keyShift=keyShift_;
                incoming=std::move(seamlessIncoming_);
            }
            if(incoming) {
                const bool attached=playing && mixer.attachIncoming(incoming);
                const bool scheduled=attached && mixer.schedule(2,1);
                seamlessDecision_.store(static_cast<int>(mixer.lastDecision()),
                                        std::memory_order_release);
                if(!scheduled) {
                    std::lock_guard<std::mutex> lock(mutex_);
                    // offerSeamless() reserves the one-slot deferred-retirement
                    // channel before handing a new source to this worker.
                    // Never overwrite a pending source: overwriting would free
                    // its PCM/Keylock state on the audio thread.
                    auto failed=attached?mixer.cancelUnscheduled():std::move(incoming);
                    // At least one mailbox slot was reserved by offerSeamless.
                    // No overwritten unique_ptr and no audio-thread release.
                    for(auto& slot:seamlessRetired_)if(!slot) {
                        slot=std::move(failed);break;
                    }
                    if(failed)std::terminate(); // unreachable: admission reservation violated
                    seamlessError_="Transition cannot be scheduled: source ended or unavailable";
                    seamlessStatus_.store(4,std::memory_order_release);
                }else seamlessStatus_.store(2,std::memory_order_release);
            }
            if(hasNav && nav.transportCuePreview)cueReturn=false;
            if(cueReturn && !hasNav) {
                // The transport serial belongs to mutex_, not an atomic.
                // Keep check and suppression synchronized with UI requests.
                std::lock_guard<std::mutex> lock(mutex_);
                if(transportRequestSerial_!=observedSerial)cueReturn=false;
            }
            // A later STOP/CUE-return supersedes an unheard quantized jump.
            // In particular, do not let a stale ghost survive a vinyl brake.
            if((cueReturn || changeFade || (!want && !hasNav)) && hasScheduled) {
                hasScheduled=false;commitSerial=0;
                std::lock_guard<std::mutex> lock(mutex_);
                if(previewSerial_==scheduled.serial) {
                    visualPreview_=false;
                    pendingShiftActive_=false;pendingShiftFrames_=0;
                    if(scheduled.loopMove)loopHalfBeatStep_.reset();
                    previewFramesRemaining_.store(0);
                    visualEpoch_.fetch_add(1);
                }
            }
            if(cueReturn) {
                pendingCueStop=true;
                cueStopSerial=observedSerial;
            }
            if((cueReturn || changeFade) && playing) {
                want=false;
                std::lock_guard<std::mutex> lock(mutex_);
                if(transportRequestSerial_==observedSerial) {
                    targetPlaying_=false;requestedPlaying_.store(false);
                }else want=targetPlaying_;
            }
            // Normal Player and seamless-ready Player must obey the SAME
            // navigation contract: quantized jumps WAIT for the musical
            // boundary, then remain previewed until their PCM is audible.
            // Do not seek here simply because a UI request was received.
            auto commitNavigation=[&](const Navigation& command,std::uint64_t outputOffset,
                                      bool audibleLater) {
                const double live=mixer.active().cursor();
                double target=command.relativeShift ?
                    live+static_cast<double>(command.shiftFrames) :
                    static_cast<double>(command.target);
                {
                    std::lock_guard<std::mutex> lock(mutex_);
                    // A newer command still owns the accumulated shift if
                    // this one was superseded before its render boundary.
                    if(previewSerial_!=command.serial)return;
                    // Both performance CUES and relative navigation carry a
                    // pending loop. BEATJUMP / overview SEEK must shift an
                    // active loop together with the source (normal worker
                    // parity). Never overwrite a later manual loop edit.
                    if(loopRevision_==command.loopRevision) {
                        loop_=command.loop;
                        ++loopRevision_;
                    }
                    loop=loop_;
                    pendingShiftActive_=false;
                    pendingShiftFrames_=0;
                    if(!audibleLater) {
                        visualPreview_=false;
                        previewFramesRemaining_.store(0);
                    }
                }
                if(audibleLater && outputWasPlaying && command.relativeShift)captureJumpTail(outputOffset);
                else jumpFade=jumpTail.size();
                if(command.relativeShift && loop.active &&
                   (target>=loop.end || (!loop.armAhead && target<loop.start))) {
                    const double length=double(loop.end-loop.start);
                    double phase=std::fmod(target-loop.start,length);
                    if(phase<0)phase+=length;
                    target=loop.start+phase;
                }
                mixer.active().seek(target);
                if(loop.active)mixer.active().setLoop(loop.start,loop.end,loop.armAhead);
                else mixer.active().clearLoop();
                appliedLoop=loop;
                if(audibleLater) {
                    commitOutputFrame=historyWritten+outputOffset;
                    commitSerial=command.serial;
                } else {
                    commitSerial=0;
                    audiblePosition_.store(static_cast<std::uint64_t>(mixer.active().cursor()));
                    audiblePrecisePosition_.store(mixer.active().cursor());
                    audibleTimestampNs_.store(0);
                    audiblePlaybackSpeed_.store(0);
                }
                // A playing seek is not a visual discontinuity until its
                // replacement sample reaches the actual audible ALSA head.
                if(!audibleLater)visualEpoch_.fetch_add(1);
            };
            if(hasNav) {
                // A newer press supersedes any older scheduled navigation.
                // Repeated relative BEATJUMPs retain their original beat
                // deadline, while repeated absolute CUES re-evaluate phase.
                const bool keepDeadline=hasScheduled && scheduled.quantized && nav.quantized &&
                    !scheduled.matchCuePhase && !nav.matchCuePhase &&
                    scheduled.loopRevision==nav.loopRevision &&
                    scheduled.grid.quantizeBeats==nav.grid.quantizeBeats &&
                    scheduled.grid.framesPerBeat==nav.grid.framesPerBeat &&
                    scheduled.grid.firstBeatFrame==nav.grid.firstBeatFrame;
                commitSerial=0;
                scheduled=nav;
                hasScheduled=true;
                if(!keepDeadline) {
                    if(nav.quantized && want && nav.grid.valid()) {
                        const double source=mixer.active().cursor();
                        const double trigger=nav.matchCuePhase ?
                            BeatNavigation::nextMatchingCuePhase(source,double(nav.target),nav.grid) :
                            BeatNavigation::nextQuantizeBoundary(source,nav.grid);
                        framesUntilJump=std::max(0.0,trigger-source);
                    } else framesUntilJump=0.0;
                }
                if(nav.transportCuePreview) {
                    // Transport CUE alone deliberately flushes stale audible
                    // output. It is never quantized, unlike performance CUES.
                    device->flush();
                    historyWritten=0;
                    playbackSessionFirstOutputFrame=0;
                    lastAudibleLocal=0;outputClockInitialized=false;
                    audibleTimestampNs_.store(0);
                    audiblePlaybackSpeed_.store(0);
                    visualStartFrame_.store(double(nav.target));
                    visualStartPending_.store(true);
                    pendingCueStop=false;
                    stopping=false;stopType=StopType::None;
                    starting=true;ramp=0;
                    want=true;
                }
                if(!want && !playing) {
                    commitNavigation(nav,0,false);
                    hasScheduled=false;
                }
            }
            if(cueReturn && !playing && !hasNav) {
                const auto saved=transportCueFrame_.load();
                if(saved>=0) {
                    mixer.active().seek(double(saved));
                    audiblePrecisePosition_.store(double(saved));
                    audiblePosition_.store(std::uint64_t(saved));
                    audiblePlaybackSpeed_.store(0);
                    audibleTimestampNs_.store(0);
                    visualStartPending_.store(false);
                    visualEpoch_.fetch_add(1);
                }
                pendingCueStop=false;
            }
            mixer.setSessionBpm(targetBpm_.load(std::memory_order_relaxed));
            mixer.active().setKeylockMode(keylockMode_.load(std::memory_order_relaxed));
            mixer.active().setKeyShift(keyShift);
            if(!want && playing && !stopping) {
                stopping=true;starting=false;ramp=0;
                stopType=cueReturn?StopType::Cue:(changeFade?StopType::TrackChange:StopType::Vinyl);
            } else if(cueReturn && playing && stopping) {
                stopping=true;starting=false;ramp=0;stopType=StopType::Cue;
            }
            if(want && stopping) {
                // Fast PLAY or held CUE re-press preempts the old brake.
                stopping=false;stopType=StopType::None;starting=true;ramp=0;
                pendingCueStop=false;
            }
            // Stopped scrubbing must leave the normal transport at the exact
            // final finger target. The audio worker alone drains/flushes ALSA
            // and seeks its resident source; UI never invokes DSP or ALSA.
            // A very quick DOWN/MOVE/UP can arrive before the audio worker's
            // first wakeup. Commit that final target even if no scrub PCM was
            // rendered, so an immediate CUE always lands on the finger frame.
            if(!scrubReader.engaged() && !scrubGesture &&
               scrubCommitPending && !playing) {
                const double stopped=std::clamp(scrubTarget,0.0,
                    double(track_->totalFrames-1));
                mixer.active().seek(stopped);
                audiblePosition_.store(static_cast<std::uint64_t>(stopped));
                audiblePrecisePosition_.store(stopped);
                audiblePlaybackSpeed_.store(0.0);
                audibleTimestampNs_.store(0);
                {
                    std::lock_guard<std::mutex> lock(mutex_);
                    if(!scrubGesture_ && scrubRevision_==seenScrubRevision) {
                        scrubPendingCommit_=false;
                        scrubVisualActive_.store(false);
                    }
                }
                visualEpoch_.fetch_add(1);
            }
            if(scrubReader.engaged() && (!scrubGesture || want || hasNav || cueReturn || changeFade)) {
                if(scrubPcmQueued) {
                    // A single 128-frame tail (2.9 ms) plus an immediate ALSA
                    // drain caused clicks on finger-up. End the last scratch
                    // at an actual zero crossing in *gain* over two complete
                    // output periods, then queue a period of digital silence
                    // before draining. Do not alter touch velocity or Keylock.
                    constexpr unsigned kTailFrames=2*Settings::kAudioChunkFrames;
                    for(unsigned offset=0;offset<kTailFrames;
                        offset+=Settings::kAudioChunkFrames) {
                        scrubReader.releaseTail(pcm.data(),Settings::kAudioChunkFrames,
                            track_->pcmStereo.data(),track_->totalFrames,
                            offset,kTailFrames);
                        for(unsigned j=0;j<Settings::kAudioChunkFrames;++j) {
                            const auto safe=masterLimiter.process(
                                double(pcm[j*2])*Settings::kAudioOutputGain,
                                double(pcm[j*2+1])*Settings::kAudioOutputGain);
                            output[j*2]=AudioOutputSafety::convert24(safe[0]*32768.0,1.0).pcm;
                            output[j*2+1]=AudioOutputSafety::convert24(safe[1]*32768.0,1.0).pcm;
                        }
                        device->write(output.data(),Settings::kAudioChunkFrames);
                    }
                    for(unsigned j=0;j<Settings::kAudioChunkFrames;++j) {
                        const auto safe=masterLimiter.process(0.0,0.0);
                        output[2*j]=AudioOutputSafety::convert24(safe[0]*32768.0,1.0).pcm;
                        output[2*j+1]=AudioOutputSafety::convert24(safe[1]*32768.0,1.0).pcm;
                    }
                    device->write(output.data(),Settings::kAudioChunkFrames);
                    device->finish();
                    scrubPcmQueued=false;
                }
                const double finalPosition=std::clamp(scrubTarget,0.0,
                    double(track_->totalFrames-1));
                mixer.active().seek(finalPosition);
                audiblePosition_.store(static_cast<std::uint64_t>(finalPosition));
                audiblePrecisePosition_.store(finalPosition);
                audiblePlaybackSpeed_.store(0.0);
                audibleTimestampNs_.store(0);
                visualEpoch_.fetch_add(1);
                scrubReader.stop();
                {
                    std::lock_guard<std::mutex> lock(mutex_);
                    if(!scrubGesture_ && scrubRevision_==seenScrubRevision) {
                        scrubPendingCommit_=false;
                        scrubVisualActive_.store(false);
                    }
                }
            }
            if(want && !playing) {
                // This first frame belongs to the new PLAY epoch. The audio
                // output ring still contains the old PLAY/CUE-return history;
                // an early ALSA delay report must never publish those slots.
                playbackSessionFirstOutputFrame=historyWritten;
                playing=true;stopping=false;stopType=StopType::None;
                starting=true;ramp=0;
                audioMotion_.store(true);
            }
            if(!playing) {
                if(scrubGesture && !want && !hasNav && !cueReturn && !changeFade) {
                    if(!scrubReader.engaged())
                        scrubReader.begin(mixer.active().cursor(),track_->totalFrames);
                    const unsigned choices=scrubOptions_.load(std::memory_order_relaxed);
                    scrubReader.configure(VinylScrub::normalized(
                        static_cast<int>((choices>>16)&255),
                        static_cast<int>((choices>>8)&255),
                        static_cast<int>(choices&255)));
                    scrubReader.setTarget(scrubTarget,scrubTouchTimestampNs);
                    // Keep ALSA running throughout the held gesture, even
                    // during stillness. This prevents repeated drain/restart
                    // transients when touchscreen events arrive irregularly.
                    scrubReader.render(pcm.data(),Settings::kAudioChunkFrames,
                                       track_->pcmStereo.data(),track_->totalFrames);
                    for(unsigned j=0;j<Settings::kAudioChunkFrames;++j) {
                        const auto safe=masterLimiter.process(
                            double(pcm[j*2])*Settings::kAudioOutputGain,
                            double(pcm[j*2+1])*Settings::kAudioOutputGain);
                        output[j*2]=AudioOutputSafety::convert24(safe[0]*32768.0,1.0).pcm;
                        output[j*2+1]=AudioOutputSafety::convert24(safe[1]*32768.0,1.0).pcm;
                    }
                    device->write(output.data(),Settings::kAudioChunkFrames);
                    scrubPcmQueued=true;
                    continue;
                }
                {std::lock_guard<std::mutex> lock(mutex_);
                 if(!targetPlaying_)audioMotion_.store(false);
                }
                wake_.notify_all();
                continue;
            }
            const auto t0=std::chrono::steady_clock::now();
            const auto obsNs=linkedObservationNs_.load(std::memory_order_acquire);
            const auto nowNs=std::chrono::duration_cast<std::chrono::nanoseconds>(
                t0.time_since_epoch()).count();
            const bool beatSync=linkedBeatSyncActive_.load(std::memory_order_relaxed);
            const bool fresh=obsNs>0 && nowNs>=obsNs && nowNs-obsNs<300000000LL;
            const double phaseError=linkedPhaseErrorBeats_.load(std::memory_order_relaxed);
            const double targetPhaseTrim=linkServo.tick(beatSync,fresh,phaseError,
                linkedBeatLocked_.load(std::memory_order_relaxed),t0);
            linkAppliedTrim_.store(linkServo.applied(),std::memory_order_relaxed);
            linkFilteredError_.store(linkServo.filteredError(),std::memory_order_relaxed);
            const bool preserveSyncPitch=beatSync || std::abs(linkedTrimSmooth)>0.0000001 ||
                                         std::abs(targetPhaseTrim)>0.0000001;
            const auto desiredSpeed=mixer.active().selectedBpm()/mixer.active().baseBpm();
            // Keep the original vinyl velocity envelope (not a volume-only
            // fade). CUE return gets its own short constant-pitch cosine fade.
            std::array<double,Settings::kAudioChunkFrames> gains{};
            const unsigned endFrames=stopType==StopType::Cue?cueFrames:
                (stopType==StopType::TrackChange?trackChangeFrames:vinylFrames);
            for(unsigned j=0;j<Settings::kAudioChunkFrames;++j) {
                double speed=1.0,gain=1.0;
                if(stopping) {
                    const double progress=std::min(1.,double(ramp++)/endFrames);
                    if(stopType==StopType::Cue || stopType==StopType::TrackChange) {
                        gain=0.5*(1.+std::cos(AudioResample::kPi*progress));
                    }else {
                        speed=(1.-progress)*(1.-progress);
                        gain=AudioResample::stopGain(progress);
                    }
                }else if(starting) {
                    const double progress=std::min(1.,double(ramp++)/startFrames);
                    speed=Settings::kStartSpeed+(1.-Settings::kStartSpeed)*progress;
                    if(progress>=1.)starting=false;
                }
                pitchNudge.setDirection(nudgeDirection_.load(std::memory_order_relaxed), rate);
                linkedTrimSmooth+=(targetPhaseTrim-linkedTrimSmooth)*trimAlpha;
                const double manualMotor=std::clamp(speed*(1.0+pitchNudge.next()),0.0,1.20);
                const double phaseRate=std::clamp(1.0+linkedTrimSmooth,0.98,1.02);
                vinylRates[j]=float(manualMotor);
                networkRates[j]=float(phaseRate);
                gains[j]=gain;
                audibleSpeeds[(historyWritten+j)%audibleSpeeds.size()]=
                    desiredSpeed*manualMotor*phaseRate;
            }
            if(loop.active) {
                if(loop.boundarySlide)
                    mixer.active().slideLoop(loop.start,loop.end);
                else mixer.active().setLoop(loop.start,loop.end,loop.armAhead);
            } else if(appliedLoop.active) {
                auto& voice=mixer.active();
                if(outputWasPlaying && voice.hasProcessedAudio()) {
                    // The spectral input is already looking ahead inside the
                    // loop. Replace that lookahead at the same source frame
                    // and crossfade, so a drop can exit the loop immediately.
                    const double live=voice.cursor();
                    captureJumpTail(0);
                    voice.clearLoop();
                    voice.seek(live);
                }else voice.clearLoop();
            }
            appliedLoop=loop;
            // Honor quantization at a source-frame boundary *within* the
            // current 256-frame block. Splitting only the affected block keeps
            // the shared ALSA output continuous; no sleeps or DSP work in UI.
            unsigned rendered=0;
            while(rendered<Settings::kAudioChunkFrames) {
                if(hasScheduled && framesUntilJump<=0.0) {
                    commitNavigation(scheduled,rendered,true);
                    hasScheduled=false;
                }
                unsigned segment=Settings::kAudioChunkFrames-rendered;
                if(hasScheduled) {
                    double remaining=std::max(0.0,framesUntilJump);
                    unsigned before=0;
                    while(before<segment && remaining>0.0) {
                        remaining-=std::max(0.0,double(audibleSpeeds[(historyWritten+rendered+before)%audibleSpeeds.size()]));
                        ++before;
                    }
                    segment=std::max(1u,before);
                    framesUntilJump=remaining;
                }
                if(!mixer.render(pcm.data()+rendered*2,segment,
                                 vinylRates.data()+rendered,renderedCursors.data()+rendered,
                                 renderedMixGain.data()+rendered,
                                 networkRates.data()+rendered,preserveSyncPitch,
                                 renderedIncomingCursors.data()+rendered))
                    throw std::runtime_error("Seamless mixer frame render failed");
                for(unsigned j=rendered;j<rendered+segment && jumpFade<jumpTail.size();++j) {
                    const auto mixed=blendJump({pcm[j*2],pcm[j*2+1]},jumpFade++);
                    pcm[j*2]=mixed[0];pcm[j*2+1]=mixed[1];
                }
                rendered+=segment;
            }
            linkRouteChanges_.store(mixer.active().routeChanges(),std::memory_order_relaxed);
            // Process the already-mixed Float32 stereo block; master FX is
            // independent of visible menu, Keylock, and outgoing/incoming tracks.
            // Parameter snapshot has no locks, heap, I/O or waiting.
            const auto selectedFx=static_cast<DeckFx::Type>((fxSnapshot>>16)&3);
            const int signedFx=static_cast<int>(fxSnapshot&255)-100;
            const unsigned fxPeriod=(fxSnapshot>>8)&15u;
            const auto& beatGrid=mixer.active().song().beatGrid;
            masterFx.process(pcm.data(),Settings::kAudioChunkFrames,selectedFx,signedFx,
                mixer.active().selectedBpm(),renderedCursors.data(),
                mixer.active().song().sampleRate,
                beatGrid.firstBeatSeconds,beatGrid.estimated?beatGrid.bpm:0.0,fxPeriod,
                (fxSnapshot&kFxBypassBit)!=0);
            // The B source rate is constant for this completed render block.
            // Evaluate once, not 256 times inside the audio-worker loop.
            const auto& incomingForClock=mixer.incomingReady()?mixer.incoming():mixer.active();
            const double incomingSpeed=double(incomingForClock.song().sampleRate)*
                incomingForClock.selectedBpm()/std::max(0.001,incomingForClock.baseBpm());
            double blockPeakAfterGain=0.0;
            for(unsigned j=0;j<Settings::kAudioChunkFrames;++j) {
                const double l=double(pcm[j*2])*gains[j]*Settings::kAudioOutputGain;
                const double r=double(pcm[j*2+1])*gains[j]*Settings::kAudioOutputGain;
                for(int c=0;c<2;++c)
                    if(std::abs(pcm[j*2+c])>1.f)
                        resamplerPeakSamples_.fetch_add(1,std::memory_order_relaxed);
                // IMPORTANT: one final master limiter covers BOTH master FX
                // and Seamless Load summing; it cannot hide internal FX clipping.
                const auto safe=masterLimiter.process(l,r);
                for(int c=0;c<2;++c) {
                    const auto converted=AudioOutputSafety::convert24(safe[c]*32768.0,1.0);
                    output[j*2+c]=converted.pcm;
                    blockPeakAfterGain=std::max(blockPeakAfterGain,std::abs(safe[c]));
                    if(converted.clipped)outputClippedSamples_.fetch_add(1,std::memory_order_relaxed);
                }
                const auto ring=(historyWritten+j)%audibleFrames.size();
                audibleFrames[ring]=renderedCursors[j];
                audibleIncomingFrames[ring]=renderedIncomingCursors[j];
                // B's own source rate (not an approximation from A's visual
                // predictor). This is ONLY display history, not a servo.
                audibleIncomingSpeeds[ring]=incomingSpeed*
                    (renderedMixGain[j]>0.0f ? double(networkRates[j]) : 1.0);
                // The ALSA queue can still contain mixed A/B frames after
                // render-side promotion. Keep each frame's REAL mixer gain.
                audibleMixGain[(historyWritten+j)%audibleMixGain.size()]=
                    promotionPending?1.0f:renderedMixGain[j];
                audibleTravels[(historyWritten+j)%audibleTravels.size()]=sourceTravel;
                sourceTravel+=std::max(0.0, double(audibleSpeeds[(historyWritten+j)%audibleSpeeds.size()]));
            }
            auto prevPeak=worstPeakAfterGain_.load(std::memory_order_relaxed);
            while(prevPeak<blockPeakAfterGain &&
                  !worstPeakAfterGain_.compare_exchange_weak(prevPeak,blockPeakAfterGain)){}
            const auto renderUs=std::chrono::duration_cast<std::chrono::microseconds>(
                std::chrono::steady_clock::now()-t0).count();
            renderTotalUs_.fetch_add(renderUs,std::memory_order_relaxed);
            audioBlocks_.fetch_add(1,std::memory_order_relaxed);
            auto peak=renderWorstUs_.load();
            while(peak<std::uint64_t(renderUs) && !renderWorstUs_.compare_exchange_weak(
                   peak,std::uint64_t(renderUs))){}
            const auto beforeWrite=std::chrono::steady_clock::now();
            device->write(output.data(),Settings::kAudioChunkFrames);
            const auto writeUs=std::chrono::duration_cast<std::chrono::microseconds>(
                std::chrono::steady_clock::now()-beforeWrite).count();
            writeTotalUs_.fetch_add(writeUs,std::memory_order_relaxed);
            auto slowest=writeWorstUs_.load(std::memory_order_relaxed);
            while(slowest<std::uint64_t(writeUs) && !writeWorstUs_.compare_exchange_weak(
                    slowest,std::uint64_t(writeUs))){}
            historyWritten+=Settings::kAudioChunkFrames;
            alsaUnderruns_.store(device->underruns());
            alsaRecoveries_.store(device->recoveries());
            const long queue=device->queuedFrames();
            bool haveAudibleFrame=false;
            std::uint64_t lastAudibleOutputFrame=0;
            if(queue>=0 && std::uint64_t(queue)<historyWritten &&
               std::uint64_t(queue)<audibleFrames.size() &&
               historyWritten-std::uint64_t(queue)-1>=playbackSessionFirstOutputFrame &&
               (!outputClockInitialized ||
                historyWritten-std::uint64_t(queue)-1>=lastAudibleLocal)) {
                // Both the output epoch AND monotonic audible report must be
                // valid before we clear visualStartPending_. Rejecting an old
                // slot prevents the PLAY->CUE->PLAY one-frame waveform rewind.
                const auto audible=historyWritten-std::uint64_t(queue)-1;
                haveAudibleFrame=true;
                lastAudibleOutputFrame=audible;
                const auto slot=audible%audibleFrames.size();
                const auto seamlessState=seamlessStatus_.load(std::memory_order_acquire);
                if(seamlessState==2 || seamlessState==3 || promotionPending) {
                    if(seamlessState==2)
                        seamlessAudibleIncomingGain_.store(audibleMixGain[slot],
                            std::memory_order_release);
                    // Publish B history only after it actually contributes
                    // audible output. The source-frame pair shares this same
                    // ALSA queue slot and the timestamp published below.
                    if(audibleMixGain[slot]>0.0f || promotionPending || seamlessState==3) {
                        seamlessAudibleIncomingCursor_.store(audibleIncomingFrames[slot],
                            std::memory_order_relaxed);
                        seamlessAudibleIncomingSpeed_.store(audibleIncomingSpeeds[slot],
                            std::memory_order_relaxed);
                        seamlessAudibleIncomingValid_.store(true,std::memory_order_release);
                    }
                }
                const double cursor=std::clamp(audibleFrames[slot],0.,
                    double(mixer.active().song().totalFrames-1));
                audiblePrecisePosition_.store(cursor);
                audiblePosition_.store(std::uint64_t(cursor));
                audiblePlaybackSpeed_.store(audibleSpeeds[slot]);
                audibleSourceTravel_.store(audibleTravels[slot]);
                audibleTimestampNs_.store(std::chrono::duration_cast<std::chrono::nanoseconds>(
                    std::chrono::steady_clock::now().time_since_epoch()).count());
                if(!outputClockInitialized) {
                    audibleOutputClock_.fetch_add(audible+1);
                    outputClockInitialized=true;
                } else if(audible>=lastAudibleLocal) {
                    audibleOutputClock_.fetch_add(audible-lastAudibleLocal);
                }
                lastAudibleLocal=audible;
                if(visualStartPending_.exchange(false)) visualEpoch_.fetch_add(1);
                // Only this audio-queue report may retire a navigation preview.
                // The CPU may have rendered the new source earlier, while ALSA
                // is still playing the old source. Preserve the ghost until
                // the *first new sample* is genuinely audible.
                if(commitSerial && audible>=commitOutputFrame) {
                    std::lock_guard<std::mutex> lock(mutex_);
                    if(previewSerial_==commitSerial) {
                        visualPreview_=false;
                        previewFramesRemaining_.store(0);
                        visualEpoch_.fetch_add(1);
                    }
                    commitSerial=0;
                }
                if(hasScheduled || commitSerial) {
                    const auto activeSerial=hasScheduled ? scheduled.serial : commitSerial;
                    std::uint64_t left=0;
                    if(hasScheduled) {
                        const double rate=std::max(0.05,
                            mixer.active().selectedBpm()/mixer.active().baseBpm());
                        left=std::uint64_t(queue)+std::uint64_t(std::ceil(
                            std::max(0.0,framesUntilJump)/rate));
                    } else if(audible<commitOutputFrame) left=commitOutputFrame-audible;
                    std::lock_guard<std::mutex> lock(mutex_);
                    if(visualPreview_ && previewSerial_==activeSerial)
                        previewFramesRemaining_.store(left);
                }
            }else audibleTimestampNs_.store(0);
            if(mixer.transitioned()) {
                // The mixer can use B from its next render block NOW; do not
                // advertise the UI track swap until ALSA has played the final
                // already-written outgoing/mixed frame. No extra buffering.
                mixer.promote();
                promotionPending=true;
                promotionAudibleOutputFrame=historyWritten ? historyWritten-1 : 0;
                {
                    std::lock_guard<std::mutex> lock(mutex_);
                    auto old=mixer.takeRetired();
                    // Every accepted offer reserves a free retirement slot.
                    for(auto& slot:seamlessRetired_)if(!slot) {
                        slot=std::move(old);break;
                    }
                    if(old)std::terminate(); // unreachable: admission reservation violated
                    appliedLoop={};
                    keyShift_=0;
                    hasScheduled=false;commitSerial=0;
                    previewFramesRemaining_.store(0);
                }
            }
            // After render-side promotion, mixer.incomingReady() is false:
            // publish B's *active* cursor until the UI actually adopts B.
            // Otherwise the purple waveform suddenly jumps back to zero.
            seamlessIncomingCursor_.store(
                (promotionPending || seamlessStatus_.load(std::memory_order_acquire)==3) ?
                    mixer.active().cursor() :
                    (mixer.incomingReady()?mixer.incoming().cursor():0.),
                std::memory_order_relaxed);
            if(promotionPending && haveAudibleFrame &&
               lastAudibleOutputFrame>=promotionAudibleOutputFrame) {
                promotionPending=false;
                seamlessAudibleIncomingGain_.store(1.0f,std::memory_order_release);
                seamlessStatus_.store(3,std::memory_order_release);
                visualEpoch_.fetch_add(1);
            }
            const bool brakeComplete=stopping && ramp>=endFrames;
            if(brakeComplete || mixer.active().hasEnded()) {
                const bool naturalEnd=mixer.active().hasEnded() && !stopping;
                if(naturalEnd) {
                    std::lock_guard<std::mutex> lock(mutex_);
                    if(transportRequestSerial_==observedSerial) {
                        targetPlaying_=false;requestedPlaying_.store(false);
                    }
                }
                // Drain the completed silence/fade before parking at CUE.
                // Hardware PCM remains OPEN for the next PLAY or new LOAD.
                device->finish();
                jumpFade=jumpTail.size();
                playing=false;stopping=false;starting=false;stopType=StopType::None;
                {
                    std::lock_guard<std::mutex> lock(mutex_);
                    const bool finishCue=pendingCueStop &&
                        transportRequestSerial_==cueStopSerial && !targetPlaying_ && !navigationPending_;
                    if(finishCue) {
                        const auto saved=transportCueFrame_.load();
                        if(saved>=0)mixer.active().seek(double(saved));
                    }
                    pendingCueStop=false;
                    if(!targetPlaying_) {
                        const double stopped=mixer.active().cursor();
                        audioMotion_.store(false);requestedPlaying_.store(false);
                        audiblePosition_.store(std::uint64_t(stopped));
                        audiblePrecisePosition_.store(stopped);
                        audiblePlaybackSpeed_.store(0);
                        visualStartPending_.store(false);
                    }
                }
                wake_.notify_all();
                audibleTimestampNs_.store(0);
                visualEpoch_.fetch_add(1);
            }
        }
    }catch(const std::exception& e) {
        {
            std::lock_guard<std::mutex> lock(mutex_);
            lastError_=e.what();seamlessError_=e.what();
            seamlessStatus_.store(4,std::memory_order_release);
            targetPlaying_=false;requestedPlaying_.store(false);
            audioMotion_.store(false);
        }
        wake_.notify_all();
        std::cerr<<"DECK001 AUDIO ERROR: "<<e.what()<<'\n';
    }
}
