#include "beat_grid.h"
#include "mp3_waveform.h"
#include "settings.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <cstdio>
#include <cstdlib>
#include "musical_sync_audit.h"
#include "pulse_beat.h"
#include <mutex>
#include <string>
#include <vector>

// Constant-tempo 4/4 electronic-music analyzer. Completely original C++.
// No FFT or runtime dependencies; consumes precomputed 10-ms energy bins.
// IMPORTANT: An onset/beat is not necessarily the first beat of a bar.
namespace {
struct Envelope {
    std::vector<float> kick;
    double binSeconds = 0;
    double energy = 0;
    double fitFromSeconds = 0;
    double fitUntilSeconds = 90;
};

Envelope makeEnvelope(const Mp3Waveform& song) {
    Envelope e;
    e.binSeconds = double(song.framesPerBin)/song.sampleRate;
    e.kick.resize(song.bins.size(),0);
    const double bassRef=std::max(0.003,song.referenceBass);
    const double rmsRef=std::max(0.003,song.referenceRms);
    const double midRef=std::max(0.003,song.referenceMids);
    // Positive bass changes emphasize four-on-the-floor kick attacks over
    // persistent bass notes and off-beat hi-hats. Small mid/rms contribution
    // helps when the kick is filtered during a breakdown.
    for(std::size_t i=2;i<song.bins.size();++i) {
        const auto& a=song.bins[i];
        const auto& b=song.bins[i-1];
        const double bass=std::max(0.0,double(a.bass)-double(b.bass)*0.92)/bassRef;
        const double rms=std::max(0.0,double(a.rms)-double(b.rms)*0.93)/rmsRef;
        const double mids=std::max(0.0,double(a.mids)-double(b.mids)*0.92)/midRef;
        e.kick[i]=float(std::sqrt(std::min(2.0,0.78*bass+0.17*rms+0.05*mids)));
        e.energy+=e.kick[i];
    }
    // Prefer a high-activity, fixed-duration phase-fit window. A track can
    // have a one-minute drumless introduction; anchoring the phase only to
    // the first 90 seconds can select arbitrary phase on those songs.
    const std::size_t span=std::min(e.kick.size(),
        std::size_t(90.0/e.binSeconds));
    double window=0;
    for(std::size_t i=0;i<span;++i)window+=e.kick[i];
    double best=window;
    std::size_t first=0;
    for(std::size_t i=span;i<e.kick.size();++i) {
        window+=e.kick[i]-e.kick[i-span];
        if(window>best+1e-7){best=window;first=i-span+1;}
    }
    e.fitFromSeconds=first*e.binSeconds;
    e.fitUntilSeconds=(first+span)*e.binSeconds;
    return e;
}

float read(const Envelope& e,double pos) {
    if(pos<0 || pos+1>=double(e.kick.size())) return 0;
    const std::size_t i=std::size_t(pos);
    const double f=pos-i;
    return float((1.0-f)*e.kick[i]+f*e.kick[i+1]);
}

// Beat-position score; four surrounding bins approximate a smooth onset
// window. This prevents a small bin-boundary shift from changing the result
// suddenly. Search uses the ENTIRE recording (not only its introduction).
double evaluate(const Envelope& e,double bpm,double phaseBins,
                double fromSeconds,double untilSeconds) {
    const double period=60.0/(bpm*e.binSeconds);
    const double first=std::max(0.0,fromSeconds/e.binSeconds);
    const double last=std::min(double(e.kick.size()-2),untilSeconds/e.binSeconds);
    const double firstBeat=std::ceil((first-phaseBins)/period);
    double sum=0;
    int beats=0;
    for(double n=firstBeat;;++n) {
        const double x=phaseBins+n*period;
        if(x>=last) break;
        // A relatively narrow 10-ms kernel discriminates between near-128
        // candidates across long tracks, while tolerating bin quantization.
        sum+=0.52*read(e,x)+0.24*(read(e,x-0.8)+read(e,x+0.8));
        ++beats;
    }
    return beats>0?sum/beats:0;
}

struct Fit { double bpm=0,phase=0,score=-1; };
Fit fitTempo(const Envelope& e,double bpm,double phaseStepBins) {
    const double period=60.0/(bpm*e.binSeconds);
    Fit fit{bpm,0,-1};
    // Find phase in the most informative 90-second segment, then assess
    // the same phase across the WHOLE track (long-range drift is penalized).
    for(double phase=0;phase<period;phase+=phaseStepBins) {
        const double score=evaluate(e,bpm,phase,e.fitFromSeconds,e.fitUntilSeconds);
        if(score>fit.score) {fit.phase=phase;fit.score=score;}
    }
    fit.score=evaluate(e,bpm,fit.phase,0,e.kick.size()*e.binSeconds);
    return fit;
}

// A bounded coarse phase fit across beginning, middle, and end. The old
// autocorrelation-only ranking can put a mathematically consistent but WRONG
// harmonic in the candidate shortlist; it also misses 160 BPM on narrow
// 10-ms envelopes. Do not trust the introduction alone (DJ tracks have
// long kickless intros). All coarse windows are 24 s, regardless of track
// length, so searching a long track does not scale with duration.
double coarseTempoScore(const Envelope& e,double bpm) {
    const double duration=e.kick.size()*e.binSeconds;
    const double segment=std::min(24.0,duration/3.0);
    const double middle=std::max(0.0,(duration-segment)*0.5);
    const double last=std::max(0.0,duration-segment);
    const double periodBins=60.0/(bpm*e.binSeconds);
    double best=0;
    for(double phase=0;phase<periodBins;phase+=2.0) {
        const double score=0.40*evaluate(e,bpm,phase,0,segment)
            +0.35*evaluate(e,bpm,phase,middle,middle+segment)
            +0.25*evaluate(e,bpm,phase,last,duration);
        best=std::max(best,score);
    }
    // Prefer the tempo that explains more actual attacks per second, but
    // sublinearly: the faster harmonic must show extra evidence rather than
    // simply inserting unoccupied beat positions.
    return best*std::pow(bpm/120.0,0.70);
}

Fit refine(const Envelope& e,double centre,double radius,double step) {
    Fit best;
    const double lo=std::max(Settings::kBpmMin,centre-radius);
    const double hi=std::min(Settings::kBpmMax,centre+radius);
    for(double bpm=lo;bpm<=hi+step*0.3;bpm+=step) {
        const Fit f=fitTempo(e,bpm,0.75);
        if(f.score>best.score) best=f;
    }
    // Sub-bin phase localization for a stable first-beat reference.
    const double p=60.0/(best.bpm*e.binSeconds);
    const double phaseLo=best.phase-0.9;
    const double phaseHi=best.phase+0.9;
    double bestScore=-1;
    for(double phase=phaseLo;phase<=phaseHi;phase+=0.125) {
        const double wrapped=std::fmod(std::fmod(phase,p)+p,p);
        const double score=evaluate(e,best.bpm,wrapped,0,e.kick.size()*e.binSeconds);
        if(score>bestScore){bestScore=score;best.phase=wrapped;best.score=score;}
    }
    return best;
}
} // namespace

static void estimateBeatGridLegacy(Mp3Waveform& song) {
    song.beatGrid={};
    if(song.sampleRate<=0 || song.framesPerBin==0 ||
       song.bins.size()<std::size_t(25.0*song.sampleRate/song.framesPerBin)) return;
    const Envelope e=makeEnvelope(song);
    if(e.energy/e.kick.size()<0.003) return; // silence / insufficient attacks

    // Fixed-tempo, electronic-music-first: coarse tempo class, followed by
    // a fine fit over the entire decoded track. This is deliberately NOT a
    // variable-tempo / acoustic beat tracker.
    struct Candidate {double bpm=0, score=0;};
    std::vector<Candidate> candidateList;
    for(double bpm=Settings::kBpmMin;bpm<=Settings::kBpmMax+0.01;bpm+=0.5)
        candidateList.push_back({bpm,coarseTempoScore(e,bpm)});
    std::sort(candidateList.begin(),candidateList.end(),
              [](const Candidate& a,const Candidate& b){return a.score>b.score;});
    Fit raw;
    std::vector<Fit> refined;
    int tried=0;
    // Try multiple tempo classes in case a snare/hihat pattern creates an
    // autocorrelation harmonic. Separate candidates by at least 1.5 BPM.
    std::vector<double> attempted;
    for(const auto& candidate:candidateList) {
        if(std::any_of(attempted.begin(),attempted.end(),[&](double bpm){
            return std::abs(bpm-candidate.bpm)<1.5; }))continue;
        attempted.push_back(candidate.bpm);
        const Fit f=refine(e,candidate.bpm,0.65,0.01);
        refined.push_back(f);
        const auto evidence=[](const Fit& fit){
            return fit.score*std::pow(fit.bpm/120.0,0.70);
        };
        if(raw.bpm<=0 || evidence(f)>evidence(raw))raw=f;
        if(++tried==5)break;
    }
    if(raw.score<0.005) return;
    // Fine tempo fit (<0.01 BPM) limits grid drift over a six-minute track.
    const Fit precise=refine(e,raw.bpm,0.012,0.002);
    Fit chosen=precise;
    bool preferredInteger=false;
    const double nearest=std::round(precise.bpm);
    if(Settings::kPreferIntegerTempo &&
       std::abs(nearest-precise.bpm)<=Settings::kIntegerBpmTolerance &&
       nearest>=Settings::kBpmMin && nearest<=Settings::kBpmMax) {
        const Fit integerFit=refine(e,nearest,0,0.01);
        // Prefer a plausible DAW tempo only if a whole-track fit supports it.
        if(integerFit.score>=precise.score*Settings::kIntegerMinScoreRatio) {
            chosen=integerFit;
            chosen.bpm=nearest;
            preferredInteger=true;
        }
    }
    // Verify beat correspondence near start, middle and end. A nonuniform
    // drift or an inactive last section reduces confidence; low confidence
    // is diagnostic rather than silently asserting a verified musical grid.
    const double duration=e.kick.size()*e.binSeconds;
    const double phaseSeconds=chosen.phase*e.binSeconds;
    const double early=evaluate(e,chosen.bpm,chosen.phase,0,duration/3);
    const double middle=evaluate(e,chosen.bpm,chosen.phase,duration/3,2*duration/3);
    const double late=evaluate(e,chosen.bpm,chosen.phase,2*duration/3,duration);
    const double bestPart=std::max({early,middle,late,1e-6});
    const double consistency=std::clamp(std::min({early,middle,late})/bestPart,0.0,1.0);
    song.beatGrid.bpm=chosen.bpm;
    song.beatGrid.rawBpm=precise.bpm;
    song.beatGrid.firstBeatSeconds=phaseSeconds;
    // Independent quality factors: (a) three-section consistency, (b)
    // onset concentration above the background energy, (c) competition
    // between distinct BPM classes. None proves a 4/4 musical downbeat.
    const double baseline=e.energy/e.kick.size();
    const double onsetLift=chosen.score/(baseline+1e-9);
    const double onsetEvidence=std::clamp((onsetLift-1.25)/2.5,0.0,1.0);
    const double chosenEvidence=chosen.score*std::pow(chosen.bpm/120.0,0.70);
    double runnerRatio=0.0;
    for(const auto& f:refined){
        // Nearby alternative refinements belong to the SAME tempo class.
        if(f.bpm>0 && std::abs(std::log(f.bpm/chosen.bpm))>0.03){
            const double score=f.score*std::pow(f.bpm/120.0,0.70);
            runnerRatio=std::max(runnerRatio,score/(chosenEvidence+1e-9));
        }
    }
    const double separation=std::clamp((1.0-runnerRatio)/0.14,0.0,1.0);
    const double tempoEvidence=0.45+0.55*separation;
    song.beatGrid.confidence=std::clamp(consistency*onsetEvidence*tempoEvidence,0.0,1.0);
    song.beatGrid.integerTempoSelected=preferredInteger;
    song.beatGrid.estimated=true;
    song.beatGrid.fromCache=false;
    song.beatGrid.manual=false;
    // Diagnostic-only ranked hypotheses; unchanged production selection.
    // The 124->186 case is a 3:2 interpretation, NOT a 0.02-BPM rounding error.
    static const bool trace=[]{const char* s=std::getenv("DECK001_MUSICAL_DIAG");
        return s && s[0]=='1' && s[1]=='\0';}();
    if(trace){
        std::fprintf(stderr,
            "BEAT ANALYSIS select=%.3f raw=%.3f phase=%.5fs confidence=%.3f score=%.5f runner=%.3f candidates=",
            chosen.bpm,precise.bpm,phaseSeconds,song.beatGrid.confidence,
            chosen.score,runnerRatio);
        for(std::size_t i=0;i<std::min<std::size_t>(refined.size(),5);++i){
            const auto& f=refined[i];
            std::fprintf(stderr," %.3f/%.4f(%s)",f.bpm,f.score,
                MusicalSyncAudit::tempoRelation(f.bpm,chosen.bpm));
        }
        // Trace the 3:2 family independently of the weighted top-five.
        // These extra fits happen only with developer diagnostics enabled,
        // on the track-analysis thread, NEVER on an audio callback.
        const double relation2to3=chosen.bpm*2.0/3.0;
        const double relation3to2=chosen.bpm*1.5;
        if(relation2to3>=Settings::kBpmMin) {
            const auto alternative=fitTempo(e,relation2to3,0.75);
            std::fprintf(stderr," [2:3=%.2f score=%.4f]",relation2to3,alternative.score);
        }
        if(relation3to2<=Settings::kBpmMax) {
            const auto alternative=fitTempo(e,relation3to2,0.75);
            std::fprintf(stderr," [3:2=%.2f score=%.4f]",relation3to2,alternative.score);
        }
        std::fprintf(stderr,"\n");
    }
}

// v2.2.118h2: Pulse (neural beat / downbeat tracker, pulse_beat.cpp) first; the legacy onset analyser
// above only when Pulse finds no steady tempo or DECK001_BEAT_ANALYZER=legacy. Runs on the
// track-preparation / analysis thread like before, NEVER on an audio callback.
namespace {
// GRID RESET runs estimateBeatGrid on the UI thread. Pulse takes seconds on a Pi, so the last few Pulse
// results are remembered per decoded track (PCM size, rate and a sample fingerprint): a reset after a
// manual edit returns instantly. A track whose grid came from the cache is analysed once, on reset.
struct PulseMemo { std::size_t samples=0; int rate=0; double fingerprint=0; BeatGrid grid; };
std::mutex pulseMemoMutex;
std::vector<PulseMemo> pulseMemo;
double pcmFingerprint(const std::vector<float>& pcm) {
    double f=0;
    const std::size_t step=std::max<std::size_t>(1,pcm.size()/4099);
    for(std::size_t i=0;i<pcm.size();i+=step)f+=pcm[i]*double((i/step)%97+1);
    return f;
}
}

void estimateBeatGrid(Mp3Waveform& song) {
    const double fingerprint=pcmFingerprint(song.pcmStereo);
    {
        std::lock_guard<std::mutex> lock(pulseMemoMutex);
        for(const auto& m:pulseMemo)
            if(m.samples==song.pcmStereo.size() && m.rate==song.sampleRate && m.fingerprint==fingerprint && m.samples){
                song.beatGrid=m.grid;
                return;
            }
    }
    static const bool legacyOnly=[]{const char* s=std::getenv("DECK001_BEAT_ANALYZER");
        return s && std::string(s)=="legacy";}();
    static const bool trace=[]{const char* s=std::getenv("DECK001_MUSICAL_DIAG");
        return s && s[0]=='1' && s[1]=='\0';}();
    if(!legacyOnly && song.sampleRate>0 && song.pcmStereo.size()>=std::size_t(25.0*song.sampleRate)*2) {
        PulseBeat::Result r;
        try {
            r=PulseBeat::analyze(song.pcmStereo.data(),song.pcmStereo.size()/2,2,song.sampleRate,
                                 Settings::kPreferIntegerTempo?0.02:0.0);
        } catch(...) { r=PulseBeat::Result{}; }
        if(r.ok && r.steady && std::isfinite(r.bpm) && r.bpm>0) {
            double bpm=r.bpm, raw=r.rawBpm, first=r.firstBeatSeconds;
            // The deck's tempo range: fold double / half time into it (a beat stays a beat, a bar line a bar line).
            while(bpm>Settings::kBpmMax){bpm*=0.5;raw*=0.5;}
            while(bpm<Settings::kBpmMin){bpm*=2.0;raw*=2.0;}
            const double bar=4.0*60.0/bpm;
            first-=std::floor(first/bar)*bar;           // the first bar line at or after 0 s ...
            if(first>3.0)first-=bar;                     // ... within the grid cache's +-3 s
            song.beatGrid={};
            song.beatGrid.bpm=bpm;
            song.beatGrid.rawBpm=raw;
            song.beatGrid.firstBeatSeconds=first;
            // >= 0.50 (DECK LINK's "reliable") whenever the grid is steady; higher as more beats sit on it.
            song.beatGrid.confidence=std::clamp(0.5+0.5*(r.onGridShare-0.6)/0.3,0.5,1.0);
            song.beatGrid.integerTempoSelected=r.integerTempo;
            song.beatGrid.estimated=true;
            song.beatGrid.fromCache=false;
            song.beatGrid.manual=false;
            if(trace)std::fprintf(stderr,
                "BEAT ANALYSIS pulse bpm=%.4f raw=%.4f first=%.5fs (bar line) confidence=%.3f onGrid=%.2f "
                "barShare=%.2f peaks=%d integer=%d\n",bpm,raw,first,song.beatGrid.confidence,r.onGridShare,
                r.barPhaseShare,r.beatPeaks,int(r.integerTempo));
            {
                std::lock_guard<std::mutex> lock(pulseMemoMutex);
                if(pulseMemo.size()>=8)pulseMemo.erase(pulseMemo.begin());
                pulseMemo.push_back({song.pcmStereo.size(),song.sampleRate,fingerprint,song.beatGrid});
            }
            return;
        }
        if(trace)std::fprintf(stderr,"BEAT ANALYSIS pulse: no steady grid (ok=%d onGrid=%.2f peaks=%d), legacy analyser\n",
                              int(r.ok),r.onGridShare,r.beatPeaks);
    }
    estimateBeatGridLegacy(song);
}
