# Patch 2.2.134h: Pulse beat grid + prepared grids from the stick + Pulse phase switch, on v2.2.134

Based on: DECK001 v2.2.134 source ZIP. This is patch 2.2.131h (Pulse, stick grids, exact linked tempo) moved
onto v2.2.134, plus a **phase switch** for Pulse that is **off by default**. Apply it alone (it replaces
2.2.131h). New dependencies: none. Pulse weights are unchanged from 2.2.131h (the shipped `p4` model).

## What it does
- Everything in 2.2.131h, unchanged: **Pulse** (`pulse_beat.*`, `pulse_weights.h`) runs first in
  `estimateBeatGrid()`, your multi-section analyser (`estimateBeatGridLegacy`) is the fallback;
  `firstBeatSeconds` is the bar line; **grids from a prepared stick** (`stick_beat_grid.*`, rekordbox / DKPRP
  exports); grid priority manual > stick > automatic cache > analysis; cache format 6; grid origin >= 0;
  **exact linked tempo** in `Player::setLinkedTempoBpm`. Details: 2.2.131h's PATCH_NOTE (repeated below where it
  matters).
- **New: phase refinement, off unless `DECK001_PULSE_PHASE=1`** (set where the deck is started; no rebuild).
  After Pulse's grid fit, the grid is moved by a few ms onto the drum onsets in the audio (three bands: below
  150 Hz, 150-2000 Hz, above 2 kHz). Tracks over 150 BPM, tracks whose onsets scatter more than 6 ms around the
  grid, and grids with fewer than 8 beats are left alone. It only moves the grid (same tempo, same bar line
  beat). Grids already in the cache stay as they are. With the switch on there is one more log line:
  `BEAT GRID pulse phase moved=+x.x ms measured=+x.x ms spread=x.x ms beats=N`.
  Cost: about +5-8 % Pulse analysis time (PC), no extra peak memory (filters run in 6-s chunks).

## Measured (PC, the same C++ as in this patch, 13 Nov)
Share of tracks whose grid is within 3 / 5 / 10 ms of the reference, switch off -> on:

| Tracks, reference | off | on |
|---|---|---|
| 192 DJ tracks (Raveform test, never trained on), hand-labelled beats | 47 / 63 / 81 % | **66 / 73 / 80 %** (median error 3.2 -> 1.6 ms) |
| 98 more hand-labelled DJ tracks (used to tune the stage) | 58 / 69 / 90 % | 70 / 74 / 88 % |
| 47 house / techno tracks, line through the separated drum stem's kicks | 15 / 32 / 57 % | 23 / 68 / 89 % |
| 108 Jamendo tracks, same drum-stem reference | 40 / 62 / 82 % | 44 / 65 / 88 % |

Against the kick's own low-frequency onset in the full mix it moves the other way (19 / 36 / 65 % ->
15 / 31 / 59 % on the 192): the hand labels sit a few ms after that onset. So "better" depends on what you hear
as the beat. That is why it is a switch: **please listen** (step 3 below) before it becomes the default.

## What changed against 2.2.131h, for v2.2.134
1. **The 2.2.131h diff applies to v2.2.134 without conflicts** (one offset in `deck_application.cpp`).
   v2.2.132-134 changed sync and GROUP NUDGE, not beat analysis.
2. **GROUP NUDGE and the exact linked tempo.** v2.2.134 bends the MASTER through `Player::setLinkedTempoBpm`,
   and `SessionGroupNudge::withNativeHeadroom` keeps one 0.1-BPM step of room for the old rounded check. With
   the exact check every bend it allows is still accepted and is applied unrounded. New test
   `tests/test_group_nudge_linked_v22134h.cpp`: 2,268 bends (6 native tempos incl. 124.37, nominal 0.81-1.19x,
   the whole +-5 % envelope) all applied exactly. Side effect: the MASTER now follows the bend in the steps your
   0.049-BPM re-apply threshold gives, instead of 0.1-BPM steps. `withNativeHeadroom` itself is unchanged
   (it is now slightly more conservative than needed; your call).
3. **Phase switch**: `pulse_beat.cpp/.h` replaced by the newer drop-in files (identical grids with the switch
   off; tested), and in `beat_grid.cpp` the function `pulsePhaseRefinement()` plus three lines in
   `estimateBeatGrid()`.
4. Test scripts: `tests/run_fast_v22134h.sh` (phase test without and with `DECK001_PULSE_PHASE=1`, the GROUP
   NUDGE test, 2.2.131h's FAST tests and the v2.2.120 chain, then your `run_fast_v22134.sh`),
   `tests/run_integration_v22134h.sh` (changed units compile, version check `2.2.134`, then your
   `run_integration_v22134.sh`). 2.2.131h's integration script is not included (it checks for 2.2.131).
   `build_release.py` leaves the new `run_*` scripts out of a release ZIP, as before.

## What was verified (Linux x86-64, g++ 13.3, dependencies from `prepare_dependencies.sh`, SQLite 3.54.1)
- Clean v2.2.134 + `2.2.134h.diff` (+ the two binary fixtures in `src/tests/fixtures/pulse/`) = the files in `src/`.
- `sh tests/run_fast_v22134h.sh`: everything passes (phase test off and on, GROUP NUDGE test, Pulse, stick,
  grid sources, DECK LINK + Pulse, cache, v2.2.113-120 chain, v2.2.128-134 chain) up to v2.2.131's VT-guard
  test, which does not compile with g++ 13 (`-Werror`, unused `write()` result in
  `tools/deck_vt_guard_v22131.c:53`). **Clean v2.2.134 stops at the same place.** With only that warning
  downgraded (`cc -Wno-error=unused-result`), the VT-guard test passes and the whole script ends
  `PASS 2.2.134h FAST`.
- `sh tests/run_integration_v22134h.sh`: PASS (same VT-guard note).
- `make all`: `deck001`, `deck001-scanner`, `deck001-metadata` build.
- `python3 tools/build_release.py build` / `verify` on the patched tree: PASS (manifest SHA256, 1,022 files).
- The phase stage in C++ matches its Python reference to 0.13 microseconds on a test signal (g++, MinGW, clang
  arm64); on 40 real tracks the same move / leave decision on all 40.

## Not verified
- Not built or run on a Pi; no Pi timing with the phase stage (Pulse alone: estimate about 1 s per new track on
  a Pi 4 with 3 threads).
- Not tested with a real USB stick or two physical decks; GROUP NUDGE with Pulse grids only by the host test.
- Not listened to, with the switch off or on.

## How to try it
1. On the Mac (Pi offline): copy `src/` over a clean v2.2.134 tree (or `patch -p1 < 2.2.134h.diff`, then copy
   `src/tests/fixtures/pulse/*.f32`). Run the two `v22134h` scripts. Build, install on **both** decks.
2. As for 2.2.131h: familiar tracks, BPM, grid on the kicks, bar line on beat 1; compare with
   `DECK001_BEAT_ANALYZER=legacy`; slow tracks (85-100 BPM) should not be doubled; DECK LINK GRID SYNC with
   non-integer tempos; GROUP NUDGE as in your v2.2.134 test plan.
3. **Phase switch**: start the deck with `DECK001_PULSE_PHASE=1` (and `DECK001_STICK_GRID=off` if the tracks
   are on a prepared stick, since a stick grid wins over Pulse) and load tracks you know well that this deck has
   **not analysed before**: grids already in the cache, and the grid GRID RESET remembers, are not re-analysed.
   Listen to the beat-grid click / waveform against the kick: better or worse than the same tracks on the other
   deck with the switch off? Tell Harry which.
4. Send the `BEAT GRID pulse ... in N ms`, `BEAT GRID pulse phase moved=...` and `BEAT GRID stick ok ...` lines.
