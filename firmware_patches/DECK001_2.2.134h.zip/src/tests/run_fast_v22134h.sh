#!/bin/sh
# 2.2.134h (= 2.2.131h on v2.2.134 + the Pulse phase switch): Pulse phase refinement behind DECK001_PULSE_PHASE
# (run without and with the variable), GROUP NUDGE with the exact linked tempo, then every 2.2.131h test
# (Pulse, stick grid, grid sources, DECK LINK + Pulse, cache, the v2.2.120 chain) and v2.2.134's own FAST chain.
set -eu
cd "$(dirname "$0")/.."
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT HUP INT TERM
cxx=${CXX:-g++}
"$cxx" -std=c++17 -O3 -ffast-math -pthread -I. -c pulse_beat.cpp -o "$tmp/pulse_beat.o"
"$cxx" -std=c++17 -O2 -Wall -Wextra -Wpedantic -pthread -I. \
    tests/test_pulse_phase_v22134h.cpp mp3_waveform.cpp beat_grid.cpp stick_beat_grid.cpp beat_grid_cache.cpp \
    waveform_cache.cpp "$tmp/pulse_beat.o" -o "$tmp/phase" -ldl
env -u DECK001_PULSE_PHASE "$tmp/phase"
DECK001_PULSE_PHASE=1 "$tmp/phase"
"$cxx" -std=c++17 -O1 -pthread -Wall -Wextra -Wpedantic -I. \
    tests/test_group_nudge_linked_v22134h.cpp player.cpp beat_navigation.cpp -o "$tmp/nudge-linked"
"$tmp/nudge-linked"
# 2.2.131h's FAST chain without its last line (run_fast_v22131.sh); v2.2.134's chain below includes it.
sed '/run_fast_v22131\.sh/d; /PASS v2.2.131h FAST/d' tests/run_fast_v22131h.sh > tests/.run_fast_v22131h_part.sh
sh tests/.run_fast_v22131h_part.sh; rm -f tests/.run_fast_v22131h_part.sh
printf 'PASS v2.2.131h FAST part (Pulse, stick grid, grid sources, DECK LINK + Pulse, cache, v2.2.120 chain)\n'
sh tests/run_fast_v22134.sh
printf 'PASS 2.2.134h FAST (Pulse phase switch, GROUP NUDGE + exact linked tempo, 2.2.131h and v2.2.134 chains)\n'
