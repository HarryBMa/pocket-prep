#include "../beat_grid_cache.h"
#include "../mp3_waveform.h"
#include <cassert>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <string>
namespace fs=std::filesystem;
// v2.2.131h: the current format is 6; an older cache file is made by rewriting the leading version field.
static int legacyVersion=2;
static void setLegacyVersion(const fs::path& p) {
    std::ifstream f(p);
    std::string value((std::istreambuf_iterator<char>(f)),std::istreambuf_iterator<char>());
    assert(!value.empty() && value[0]=='6' && value[1]==' ');
    value[0]=char('0'+legacyVersion);
    std::ofstream out(p,std::ios::trunc);
    out<<value;
    assert(bool(out));
}
int main() {
  for(legacyVersion=2;legacyVersion<=5;++legacyVersion) {   // v2-v5 (pre-Pulse) caches alike
    const auto root=fs::temp_directory_path()/"deck001-v22113-grid-migration";
    fs::remove_all(root); fs::create_directories(root);
    setenv("DECK001_CACHE_ROOT",root.c_str(),1);
    const std::string track=(root/"song.wav").string();
    {std::ofstream f(track);f<<"unchanged audio";}
    BeatGrid original;
    original.bpm=128;original.rawBpm=128;original.firstBeatSeconds=.171;
    original.confidence=.95;original.estimated=true;
    assert(saveBeatGridCache(track,original));
    setLegacyVersion(legacyBeatGridFilePath(track));
    BeatGrid loaded;
    assert(!loadBeatGridCache(track,loaded) && "old automatic confidence must be regenerated");
    original.manual=true; original.firstBeatSeconds=.217;
    assert(saveBeatGridCache(track,original));
    setLegacyVersion(legacyBeatGridFilePath(track));
    assert(loadBeatGridCache(track,loaded) && loaded.manual);
    assert(loaded.bpm==128 && loaded.firstBeatSeconds==.217);
    assert(saveBeatGridCache(track,loaded));
    assert(loadBeatGridCache(track,loaded) && loaded.manual);
    fs::remove_all(root);
  }
    std::cout<<"PASS v2-v5 auto cache invalidation and v2-v5 manual grid retention\n";
}
