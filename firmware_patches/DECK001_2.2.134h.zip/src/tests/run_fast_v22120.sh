#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
tmp=$(mktemp -d);trap 'rm -rf "$tmp"' EXIT HUP INT TERM
${CXX:-g++} -std=c++17 -O2 -pthread -Wall -Wextra -Wpedantic -I. tests/test_bpm_truth_v22113.cpp beat_grid.cpp pulse_beat.cpp -o "$tmp/bpm"
"$tmp/bpm"
${CXX:-g++} -std=c++17 -O2 -I. tests/test_grid_editor.cpp grid_editor.cpp -o "$tmp/editor"
"$tmp/editor"
sh tests/run_fast_v22119.sh
printf 'PASS v2.2.120 half-time octave + grid editor + inherited regressions\n'
