#!/bin/sh
# Fast portable regression suite: compile common objects only once.
# No audio hardware, MP3 decoder or Raspberry Pi display required.
set -eu
cd "$(dirname "$0")/.."
mkdir -p build-tests
cxx=${CXX:-g++}
flags='-std=c++17 -O1 -Wall -Wextra -Wpedantic -pthread -DDECK001_TEST_BITMAP_FONT'
sources='interface.cpp icon_renderer.cpp graphics.cpp wave_tiles.cpp contour_waveform.cpp playhead_marker.cpp track_metadata.cpp audio_library.cpp grid_editor.cpp player.cpp beat_navigation.cpp beat_grid.cpp pulse_beat.cpp stick_beat_grid.cpp beat_grid_cache.cpp waveform_cache.cpp'
objects=''
for source in $sources; do
    object="build-tests/${source%.cpp}.o"
    "$cxx" $flags -I. -c "$source" -o "$object"
    objects="$objects $object"
done
# shellcheck disable=SC2086
ar rcs build-tests/libdecktest.a $objects
passed=0
for source in tests/test_*.cpp; do
    case "$source" in
        tests/test_scanner_ipc.cpp|tests/test_scanner_runtime_v212.cpp)
            # Runs via the separate-process integration harness below.
            continue;;
        tests/test_ui_v190.cpp|tests/test_ui_v186.cpp|tests/test_ui_v189.cpp|        tests/test_ui_v195.cpp|tests/test_ui_v196.cpp|tests/test_ui_v197.cpp|        tests/test_ui_v198.cpp)
            # These historic screenshot contracts hardcode the superseded
            # blue Q/SYNC/BPM header. v2.1.1 tests the new shared geometry
            # with test_ui_v211.cpp. Historical source is retained for audit.
            continue;;
    esac
    name=$(basename "$source" .cpp)
    "$cxx" -std=c++17 -O0 -pthread -I. "$source" build-tests/libdecktest.a -o "build-tests/$name"
    "build-tests/$name"
    passed=$((passed+1))
done
sh ./tests/run_scanner_tests.sh
sh ./tests/run_browser_v212.sh
printf 'PASS: %s current portable tests (v2.1.5 visual timing/touch contract and legacy DSP regression)\n' "$passed"
