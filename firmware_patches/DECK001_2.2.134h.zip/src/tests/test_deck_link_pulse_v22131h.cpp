// v2.2.131h: Pulse grids between DECK LINK units.
//  1. Two units that analyse the same file get the same grid: Pulse is deterministic across thread counts
//     (bit-identical), and 44.1 vs 48 kHz decodes agree within 0.005 BPM and 2 ms.
//  2. A linked follower applies the session BPM exactly (124.37, not 124.4), within the same +-20 % window.
#include "../player.h"
#include "../mp3_waveform.h"
#include "../audio_alsa.h"
#include "../pulse_beat.h"
#include <cassert>
#include <cmath>
#include <cstdio>
#include <memory>
#include <thread>
#include <vector>
AudioAlsa::AudioAlsa(const std::string&,unsigned,unsigned){}
AudioAlsa::~AudioAlsa(){}
void AudioAlsa::write(const std::int32_t*,unsigned){std::this_thread::sleep_for(std::chrono::microseconds(800));}
long AudioAlsa::queuedFrames() const{return 64;}
void AudioAlsa::flush(){}
void AudioAlsa::finish(){}

// 90 s of house-like audio at a non-integer tempo: kick on every beat (louder on beat 1), off-beat hat,
// a bass note per bar. Interleaved stereo.
static std::vector<float> track(int sr, double bpm) {
    const double pi=3.14159265358979323846, beat=60.0/bpm;
    std::vector<float> x(std::size_t(90.0*sr)*2);
    for(std::size_t n=0;n<x.size()/2;++n) {
        const double t=double(n)/sr, tb=std::fmod(t,beat), off=std::fmod(t+beat/2,beat);
        const bool one=(long long)std::floor(t/beat)%4==0;
        const long long bar=(long long)std::floor(t/(4*beat));
        const double v=std::sin(2*pi*55.0*tb)*std::exp(-tb/0.12)*(one?0.8:0.55)
            +0.15*std::sin(2*pi*8000.0*off)*std::exp(-off/0.015)
            +0.2*std::sin(2*pi*55.0*std::pow(2.0,(bar%4)*3/12.0)*t);
        x[2*n]=x[2*n+1]=float(v);
    }
    return x;
}

int main() {
    const double bpm=124.37;
    auto a=track(44100,bpm), b=track(48000,bpm);
    PulseBeat::Options one; one.threads=1;
    PulseBeat::Options three; three.threads=3;
    const auto r1=PulseBeat::analyze(a.data(),a.size()/2,2,44100,0.02,one);
    const auto r3=PulseBeat::analyze(a.data(),a.size()/2,2,44100,0.02,three);
    const auto r48=PulseBeat::analyze(b.data(),b.size()/2,2,48000,0.02,three);
    std::printf("44.1k 1 thread: ok=%d bpm=%.5f first=%.5f | 3 threads: bpm=%.5f first=%.5f | 48k: bpm=%.5f first=%.5f\n",
                r1.ok,r1.bpm,r1.firstBeatSeconds,r3.bpm,r3.firstBeatSeconds,r48.bpm,r48.firstBeatSeconds);
    assert(r1.ok && r3.ok && r48.ok);
    assert(r1.bpm==r3.bpm && r1.firstBeatSeconds==r3.firstBeatSeconds);          // bit-identical
    assert(std::abs(r1.bpm-bpm)<0.01 && std::abs(r48.bpm-r1.bpm)<0.005);
    assert(std::abs(std::remainder(r48.firstBeatSeconds-r1.firstBeatSeconds,60.0/bpm))<0.002);
    assert(std::abs(std::remainder(r1.firstBeatSeconds,4*60.0/bpm))<0.01);           // bar line on beat 1 (t=0)

    auto s=std::make_shared<Mp3Waveform>();
    s->sampleRate=44100;s->channels=2;s->totalFrames=44100ULL*4;
    s->pcmStereo.resize(s->totalFrames*2,0.0f);
    s->beatGrid.estimated=true;s->beatGrid.confidence=0.95;s->beatGrid.bpm=128.0;s->beatGrid.firstBeatSeconds=0;
    Player p(s,"fake",0,false);
    assert(p.setLinkedTempoBpm(bpm) && p.tempoBpm()==bpm);                          // exact, not 124.4
    assert(p.setLinkedTempoBpm(128.0*0.8) && p.setLinkedTempoBpm(128.0*1.2));
    assert(!p.setLinkedTempoBpm(128.0*0.79) && !p.setLinkedTempoBpm(128.0*1.21));
    assert(!p.setLinkedTempoBpm(std::nan("")) && !p.setLinkedTempoBpm(0));
    std::puts("PASS v2.2.131h DECK LINK + Pulse: same grid on every unit (threads, 44.1/48 kHz), exact linked tempo");
}
