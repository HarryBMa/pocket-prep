// 2.2.134h: GROUP NUDGE (v2.2.134) with the exact linked tempo of 2.2.131h.
// v2.2.134 bends the MASTER through Player::setLinkedTempoBpm and bounds the bend with
// SessionGroupNudge::withNativeHeadroom, which keeps one 0.1-BPM step of room for the old rounded check.
// With the exact check every bend that headroom allows must still be accepted, and applied unrounded
// (non-integer Pulse / stick tempos such as 124.37 included).
//   sh tests/run_fast_v22134h.sh   (from the source root)
#include "../player.h"
#include "../audio_alsa.h"
#include "../mp3_waveform.h"
#include "../session_group_nudge.h"
#include <cassert>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <memory>
#include <thread>

AudioAlsa::AudioAlsa(const std::string&,unsigned,unsigned){}
AudioAlsa::~AudioAlsa(){}
void AudioAlsa::write(const std::int32_t*,unsigned){std::this_thread::sleep_for(std::chrono::microseconds(800));}
long AudioAlsa::queuedFrames() const{return 64;}
void AudioAlsa::flush(){}
void AudioAlsa::finish(){}

int main() {
    const double natives[] = {85.3, 100.0, 124.37, 128.0, 140.004, 174.6};
    int checked = 0;
    for (double native : natives) {
        auto s = std::make_shared<Mp3Waveform>();
        s->sampleRate = 44100; s->channels = 2; s->totalFrames = 44100ULL * 4;
        s->pcmStereo.resize(s->totalFrames * 2, 0.0f);
        s->beatGrid.estimated = true; s->beatGrid.confidence = 0.95; s->beatGrid.bpm = native;
        s->beatGrid.firstBeatSeconds = 0;
        Player p(s, "fake", 0, false);
        for (double rel : {0.81, 0.85, 0.95, 1.0, 1.0371, 1.15, 1.19}) {
            const double nominal = native * rel;
            for (double amount = -0.05; amount <= 0.05 + 1e-12; amount += 0.0025) {
                const double bend = SessionGroupNudge::withNativeHeadroom(nominal, native, amount);
                const double bpm = nominal * (1.0 + bend);
                if (!p.setLinkedTempoBpm(bpm) || p.tempoBpm() != bpm) {
                    std::printf("FAIL native %.3f nominal %.4f amount %+.4f -> %.6f BPM not applied exactly\n",
                                native, nominal, amount, bpm);
                    return 1;
                }
                ++checked;
            }
        }
        // The envelope itself, sampled through a full press and release, also stays applicable.
        SessionGroupNudge::Envelope e;
        const auto t0 = std::chrono::steady_clock::now();
        e.command(1, t0);
        for (int ms = 0; ms <= 900; ms += 10) {
            const double bpm = native * (1.0 + SessionGroupNudge::withNativeHeadroom(native, native,
                                         e.amount(t0 + std::chrono::milliseconds(ms))));
            assert(p.setLinkedTempoBpm(bpm) && p.tempoBpm() == bpm);
            ++checked;
        }
    }
    std::printf("PASS 2.2.134h GROUP NUDGE + exact linked tempo: %d bends applied exactly\n", checked);
    return 0;
}
