#!/bin/sh
# 2.2.134h: every changed translation unit compiles (Pulse, stick grid, cache, loader, UI, player, DECK LINK),
# the version string, then v2.2.134's integration gates (which run its FAST chain first).
set -eu
cd "$(dirname "$0")/.."
${CXX:-g++} -std=c++17 -O0 -pthread -Wall -Wextra -Wpedantic -DDECK001_ENABLE_DECKSTRETCH -I. -fsyntax-only \
 beat_grid.cpp pulse_beat.cpp stick_beat_grid.cpp beat_grid_cache.cpp mp3_waveform.cpp metadata_store.cpp \
 ui_frame_renderer.cpp ui_scene_composer.cpp ui_wave_scene.cpp interface.cpp \
 ui_settings_controller.cpp user_preferences.cpp deck_application.cpp \
 track_session.cpp track_preparation.cpp player.cpp deck_link.cpp
python3 tools/build_release.py version | grep -Fx '2.2.134'
sh tests/run_integration_v22134.sh
printf 'PASS 2.2.134h INTEGRATION (changed units + v2.2.134 integration gates)\n'
