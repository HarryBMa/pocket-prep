#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
tmp=$(mktemp -d);trap 'rm -rf "$tmp"' EXIT HUP INT TERM
${CXX:-g++} -std=c++17 -O2 -pthread -Wall -Wextra -Wpedantic -I. \
 tests/test_bpm_multisection_v22119.cpp beat_grid.cpp pulse_beat.cpp -o "$tmp/bpm-multisection"
"$tmp/bpm-multisection"
sh tests/run_fast_v22118.sh
printf 'PASS v2.2.119 FAST (rhythmic sections, cache migration + inherited 118 tests)\n'
