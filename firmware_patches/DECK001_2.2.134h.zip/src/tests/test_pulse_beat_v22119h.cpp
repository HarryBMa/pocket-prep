// Pulse C++ vs the PyTorch reference (fixtures written by tools pulse_cexport.py), plus a grid check.
//   sh tests/run_fast_v22119h.sh   (from the source root)
#include "pulse_beat.h"

#include <algorithm>
#include <chrono>
#include <cstring>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <string>
#include <vector>

static std::vector<float> testSignal(double seconds = 20.0) {   // same formula as pulse_cexport.test_signal
    const int sr = 22050;
    const double pi = 3.14159265358979323846, beat = 60.0 / 128.0;
    std::vector<float> x(std::size_t(seconds * sr));
    for (std::size_t n = 0; n < x.size(); ++n) {
        const double t = double(n) / sr, tb = std::fmod(t, beat);
        const bool one = (long long)std::floor(t / beat) % 4 == 0;
        const double kick = std::sin(2 * pi * 55.0 * tb) * std::exp(-tb / 0.12) * (one ? 0.8 : 0.55);
        const double off = std::fmod(t + beat / 2, beat);
        const double hat = 0.15 * std::sin(2 * pi * 8000.0 * off) * std::exp(-off / 0.015);
        const long long bar = (long long)std::floor(t / (4 * beat));
        const double bass = 0.25 * std::sin(2 * pi * 55.0 * std::pow(2.0, (bar % 4) * 3 / 12.0) * t);
        x[n] = float(kick + hat + bass);
    }
    return x;
}

static std::vector<float> readF32(const std::string& p) {
    std::ifstream f(p, std::ios::binary);
    std::vector<char> b((std::istreambuf_iterator<char>(f)), {});
    std::vector<float> v(b.size() / 4);
    std::memcpy(v.data(), b.data(), v.size() * 4);
    return v;
}

int main(int argc, char** argv) {
    const std::string dir = argc > 1 ? argv[1] : "tests/fixtures/pulse";
    int fails = 0;
    const auto x = testSignal();
    int T = 0;
    const auto mel = PulseBeat::logMel(x, T);
    const auto refMel = readF32(dir + "/fixture_mel.f32");
    double melErr = 0;
    if (refMel.size() != mel.size()) { std::printf("FAIL mel size %zu vs %zu\n", mel.size(), refMel.size()); return 1; }
    for (std::size_t i = 0; i < mel.size(); ++i) melErr = std::max(melErr, double(std::abs(mel[i] - refMel[i])));
    std::printf("log-mel: %d frames, max |C++ - torch| = %.2e\n", T, melErr);
    if (melErr > 2e-3) { std::printf("FAIL mel\n"); ++fails; }

    std::vector<float> b, d;
    PulseBeat::network(refMel, T, b, d);                       // the reference mel: isolates the network
    const auto refY = readF32(dir + "/fixture_logits.f32");
    double yErr = 0;
    for (int t = 0; t < T; ++t)
        yErr = std::max({yErr, double(std::abs(b[t] - refY[t])), double(std::abs(d[t] - refY[T + t]))});
    std::printf("network: max |C++ - torch| logit = %.2e\n", yErr);
    if (yErr > 1e-2) { std::printf("FAIL logits\n"); ++fails; }

    // the same signal at 44.1 kHz stereo, through the resampler (as the deck feeds it)
    std::vector<float> up(x.size() * 2 * 2);
    for (std::size_t i = 0; i + 1 < x.size(); ++i)
        for (int k = 0; k < 2; ++k) {
            const float v = k == 0 ? x[i] : 0.5f * (x[i] + x[i + 1]);
            up[(2 * i + k) * 2] = up[(2 * i + k) * 2 + 1] = v;
        }
    const auto t0 = std::chrono::steady_clock::now();
    const auto r = PulseBeat::analyze(up.data(), up.size() / 2, 2, 44100);
    const double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    std::printf("analyze (20 s, 44.1 kHz stereo): ok=%d steady=%d bpm=%.4f firstBeat=%.4f s barShare=%.2f "
                "onGrid=%.2f peaks=%d, %.0f ms\n", r.ok, r.steady, r.bpm, r.firstBeatSeconds, r.barPhaseShare,
                r.onGridShare, r.beatPeaks, ms);
    {   // stage timings on the same 20 s
        using clk = std::chrono::steady_clock;
        std::vector<float> mono(up.size() / 2);
        for (std::size_t i = 0; i < mono.size(); ++i) mono[i] = up[2 * i];
        auto a0 = clk::now();
        const auto rs = PulseBeat::resampleTo22050(mono, 44100);
        auto a1 = clk::now();
        int TT = 0;
        const auto mm = PulseBeat::logMel(rs, TT);
        auto a2 = clk::now();
        std::vector<float> bb, dd;
        PulseBeat::network(mm, TT, bb, dd);
        auto a3 = clk::now();
        auto ms_ = [](auto u, auto v) { return std::chrono::duration<double, std::milli>(v - u).count(); };
        std::printf("stages (20 s of audio): resample %.0f ms, log-mel %.0f ms, network %.0f ms\n",
                    ms_(a0, a1), ms_(a1, a2), ms_(a2, a3));
    }
    {   // 2.2.119h: double time. Beats every 0.25 s (240 BPM), every other one weak: the grid is 120 BPM on
        // the strong ones. All equally strong: 240 BPM stays (a fast track is not halved).
        auto logits = [](float weak) {
            PulseBeat::Result g;
            g.beatLogit.assign(6000, -8.f);                                  // 120 s at 50 frames/s
            g.downLogit.assign(6000, -8.f);
            for (int k = 0; 25 + k * 12.5 < 5990; ++k) {
                const int f = int(std::lround(25 + k * 12.5));               // first beat at 0.5 s
                g.beatLogit[f] = k % 2 ? weak : 4.f;
                if (k % 8 == 0) g.downLogit[f] = 4.f;
            }
            PulseBeat::fitGrid(g);
            return g;
        };
        const auto slow = logits(0.5f), fast = logits(4.f);
        std::printf("double time: weak off-beats -> bpm=%.2f parity=%.2f halved=%d first=%.3f | equal beats -> bpm=%.2f parity=%.2f\n",
                    slow.bpm, slow.beatParity, slow.halved, slow.firstBeatSeconds, fast.bpm, fast.beatParity);
        if (!slow.ok || !slow.halved || std::abs(slow.bpm - 120.0) > 0.2 ||
            std::abs(std::remainder(slow.firstBeatSeconds - 0.5, 2.0)) > 0.03) { std::printf("FAIL double time\n"); ++fails; }
        if (!fast.ok || fast.halved || std::abs(fast.bpm - 240.0) > 0.4) { std::printf("FAIL fast track halved\n"); ++fails; }
    }
    {   // 48 kHz goes through the 320/147 resampler: same grid
        std::vector<float> x48(std::size_t(x.size() * 48000.0 / 22050.0) * 2);
        for (std::size_t i = 0; i < x48.size() / 2; ++i) {
            const double pos = double(i) * 22050.0 / 48000.0;
            const std::size_t i0 = std::min(std::size_t(pos), x.size() - 2);
            const float v = float(x[i0] + (pos - double(i0)) * (x[i0 + 1] - x[i0]));
            x48[2 * i] = x48[2 * i + 1] = v;
        }
        const auto r48 = PulseBeat::analyze(x48.data(), x48.size() / 2, 2, 48000);
        std::printf("analyze (48 kHz): ok=%d bpm=%.4f firstBeat=%.4f s\n", r48.ok, r48.bpm, r48.firstBeatSeconds);
        if (!r48.ok || std::abs(r48.bpm - r.bpm) > 0.05 ||
            std::abs(std::remainder(r48.firstBeatSeconds - r.firstBeatSeconds, 60.0 / 128.0)) > 0.01) { std::printf("FAIL 48 kHz\n"); ++fails; }
        if (PulseBeat::resampleTo22050({}, 48000).size() != 0) { std::printf("FAIL empty resample\n"); ++fails; }
        int none = -1;
        if (!PulseBeat::logMel({}, none).empty() || none != 0) { std::printf("FAIL empty log-mel\n"); ++fails; }
    }
    const double beat = 60.0 / 128.0;
    const double phaseErr = std::abs(std::remainder(r.firstBeatSeconds, beat));
    if (!r.ok || std::abs(r.bpm - 128.0) > 0.05 || phaseErr > 0.02) { std::printf("FAIL grid\n"); ++fails; }
    std::printf(fails ? "%d FAILED\n" : "ALL PASSED\n", fails);
    return fails ? 1 : 0;
}
