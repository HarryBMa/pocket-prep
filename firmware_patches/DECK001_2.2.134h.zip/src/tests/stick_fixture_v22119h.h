#pragma once
// 2.2.119h: a small prepared stick for tests (PIONEER/rekordbox/export.pdb + ANLZ0000.DAT with a PQTZ beat
// grid), written with its own minimal writer in the layout rekordbox and DKPRP exports use.
#include "../stick_beat_grid.h"
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <string>
#include <vector>
namespace fs = std::filesystem;
using Bytes = std::vector<unsigned char>;

inline void le16(Bytes& d, std::size_t o, unsigned v) { d[o] = v & 0xFF; d[o + 1] = (v >> 8) & 0xFF; }
inline void le32(Bytes& d, std::size_t o, std::uint32_t v) { for (int i = 0; i < 4; ++i) d[o + i] = (v >> (8 * i)) & 0xFF; }
inline void be16(Bytes& d, unsigned v) { d.push_back((v >> 8) & 0xFF); d.push_back(v & 0xFF); }
inline void be32(Bytes& d, std::uint32_t v) { for (int i = 3; i >= 0; --i) d.push_back((v >> (8 * i)) & 0xFF); }

inline Bytes shortAscii(const std::string& s) { Bytes b{(unsigned char)(((s.size() + 1) << 1) | 1)}; b.insert(b.end(), s.begin(), s.end()); return b; }
inline Bytes utf16(const std::u16string& s) {
    Bytes b{0x90, 0, 0, 0};
    for (char16_t c : s) { b.push_back(c & 0xFF); b.push_back(c >> 8); }
    le16(b, 1, unsigned(b.size()));
    return b;
}

inline Bytes trackRow(const Bytes& anlz, const Bytes& file) {
    Bytes r(0x5E + 42, 0);
    le16(r, 0, 0x24);
    const Bytes empty = shortAscii("");
    std::vector<std::size_t> at(21);
    for (int i = 0; i < 21; ++i) {
        at[i] = r.size();
        const Bytes& s = i == 14 ? anlz : i == 20 ? file : empty;
        r.insert(r.end(), s.begin(), s.end());
        le16(r, 0x5E + 2 * i, unsigned(at[i]));
    }
    return r;
}

inline void writePdb(const fs::path& p, const std::vector<Bytes>& rows) {
    const std::size_t ps = 4096;
    Bytes d(3 * ps, 0);
    le32(d, 4, ps); le32(d, 8, 1); le32(d, 12, 3); le32(d, 20, 1);
    le32(d, 0x1C, 0); le32(d, 0x20, 0); le32(d, 0x24, 1); le32(d, 0x28, 2);              // tracks: pages 1..2
    le32(d, ps + 4, 1); le32(d, ps + 12, 2); d[ps + 0x1B] = 0x64;                       // index page
    const std::size_t b = 2 * ps;
    le32(d, b + 4, 2); le32(d, b + 12, 3);
    const std::uint32_t counts = std::uint32_t(rows.size()) | std::uint32_t(rows.size()) << 13;
    d[b + 0x18] = counts & 0xFF; d[b + 0x19] = (counts >> 8) & 0xFF; d[b + 0x1A] = (counts >> 16) & 0xFF;
    d[b + 0x1B] = 0x34;
    std::size_t heap = 0;
    unsigned present = 0;
    for (std::size_t r = 0; r < rows.size(); ++r) {
        std::copy(rows[r].begin(), rows[r].end(), d.begin() + std::ptrdiff_t(b + 0x28 + heap));
        le16(d, b + ps - 0x24 + 2 * (15 - r), unsigned(heap));                         // row r -> offsets[15 - r]
        present |= 1u << r;
        heap += (rows[r].size() + 3) & ~std::size_t(3);
    }
    le16(d, b + ps - 4, present);
    fs::create_directories(p.parent_path());
    std::ofstream(p, std::ios::binary).write(reinterpret_cast<const char*>(d.data()), std::streamsize(d.size()));
}

inline void writeAnlz(const fs::path& p, const std::vector<StickBeatGrid::Beat>& beats) {
    Bytes s;
    s.insert(s.end(), {'P', 'Q', 'T', 'Z'});
    be32(s, 24); be32(s, std::uint32_t(24 + 8 * beats.size())); be32(s, 0); be32(s, 0x80000); be32(s, std::uint32_t(beats.size()));
    for (const auto& x : beats) { be16(s, unsigned(x.number)); be16(s, unsigned(std::lround((x.tempo > 0 ? x.tempo : 126.0) * 100))); be32(s, std::uint32_t(std::lround(x.ms))); }
    Bytes f{'P', 'M', 'A', 'I'};
    be32(f, 28); be32(f, std::uint32_t(28 + s.size()));
    f.resize(28, 0);
    f.insert(f.end(), s.begin(), s.end());
    fs::create_directories(p.parent_path());
    std::ofstream(p, std::ios::binary).write(reinterpret_cast<const char*>(f.data()), std::streamsize(f.size()));
}

inline std::vector<StickBeatGrid::Beat> beatsAt(double bpm, double t0, int n, int downIndex) {
    std::vector<StickBeatGrid::Beat> b;
    for (int i = 0; i < n; ++i) b.push_back({((i - downIndex) % 4 + 4) % 4 + 1, std::round((t0 + i * 60.0 / bpm) * 1000.0)});
    return b;
}

