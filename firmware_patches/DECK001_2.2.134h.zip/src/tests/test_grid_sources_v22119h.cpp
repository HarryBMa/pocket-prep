// 2.2.119h: where a loaded track's beat grid comes from, end to end through loadAudio():
// manual grid in the cache > grid on a prepared stick > automatic grid in the cache > analysis (Pulse);
// the cache keeps the automatic grid beside a manual one; GRID RESET's way back needs no analysis.
//   sh tests/run_fast_v22119h.sh   (from the source root)
#include "../beat_grid.h"
#include "../beat_grid_cache.h"
#include "../mp3_waveform.h"
#include "stick_fixture_v22119h.h"
#include <cassert>
#include <chrono>
#include <cstdio>
#include <cstdlib>

static void writeWav(const fs::path& p, double seconds, double bpm) {   // 44.1 kHz stereo PCM16: kick, hat, bass
    const int sr = 44100;
    const double pi = 3.14159265358979323846, beat = 60.0 / bpm;
    const std::uint32_t frames = std::uint32_t(seconds * sr), bytes = frames * 4;
    Bytes d(44 + bytes, 0);
    const char* tags[] = {"RIFF", "WAVE", "fmt ", "data"};
    for (int i = 0; i < 4; ++i) { d[0 + i] = tags[0][i]; d[8 + i] = tags[1][i]; d[12 + i] = tags[2][i]; d[36 + i] = tags[3][i]; }
    le32(d, 4, 36 + bytes); le32(d, 16, 16); le16(d, 20, 1); le16(d, 22, 2); le32(d, 24, sr); le32(d, 28, sr * 4);
    le16(d, 32, 4); le16(d, 34, 16); le32(d, 40, bytes);
    for (std::uint32_t n = 0; n < frames; ++n) {
        const double t = double(n) / sr, tb = std::fmod(t, beat), off = std::fmod(t + beat / 2, beat);
        const bool one = (long long)std::floor(t / beat) % 4 == 0;
        const double v = std::sin(2 * pi * 55.0 * tb) * std::exp(-tb / 0.12) * (one ? 0.8 : 0.55) +
                         0.15 * std::sin(2 * pi * 8000.0 * off) * std::exp(-off / 0.015);
        const int s = int(std::lround(std::max(-1.0, std::min(1.0, v * 0.8)) * 32767.0));
        le16(d, 44 + n * 4, unsigned(s) & 0xFFFF); le16(d, 46 + n * 4, unsigned(s) & 0xFFFF);
    }
    fs::create_directories(p.parent_path());
    std::ofstream(p, std::ios::binary).write(reinterpret_cast<const char*>(d.data()), std::streamsize(d.size()));
}

template <class F> static double millis(F&& f) {
    const auto t0 = std::chrono::steady_clock::now();
    f();
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
}

int main() {
    const fs::path root = fs::temp_directory_path() / "deck001-v22119h-grid-sources";
    fs::remove_all(root);
    setenv("DECK001_CACHE_ROOT", (root / "cache").c_str(), 1);
    const fs::path stick = root / "stick";
    const std::string track = (stick / "Contents" / "Artist" / "Kick.wav").string();
    writeWav(track, 40.0, 128.0);
    const std::size_t budget = 512u << 20;

    // 1. no prepared grid: analysed (Pulse), then cached
    Mp3Waveform a = loadAudio(track, budget);
    std::printf("analysed: bpm=%.3f first=%.4f confidence=%.2f\n", a.beatGrid.bpm, a.beatGrid.firstBeatSeconds, a.beatGrid.confidence);
    assert(a.beatGrid.estimated && !a.beatGrid.fromCache && !a.beatGrid.manual && std::abs(a.beatGrid.bpm - 128.0) < 0.05);
    Mp3Waveform b = loadAudio(track, budget);
    assert(b.beatGrid.fromCache && b.beatGrid.bpm == a.beatGrid.bpm);

    // 1b. GRID RESET's analysis call returns the grid the track was loaded with, at once (no Pulse run)
    Mp3Waveform edited = b;
    edited.beatGrid.bpm = 131.0;
    edited.beatGrid.manual = true;
    const double resetMs = millis([&] { estimateBeatGrid(edited); });
    std::printf("reset after an edit: %.2f ms -> bpm=%.3f\n", resetMs, edited.beatGrid.bpm);
    assert(edited.beatGrid.bpm == a.beatGrid.bpm && edited.beatGrid.firstBeatSeconds == a.beatGrid.firstBeatSeconds &&
           !edited.beatGrid.manual && resetMs < 20.0);

    // 2. the stick gets a prepared grid (127.5 BPM, so it can be told from the analysed one): it replaces the
    //    cached automatic grid on the next load, and is a cache hit after that
    writePdb(stick / "PIONEER" / "rekordbox" / "export.pdb",
             {trackRow(shortAscii("/PIONEER/USBANLZ/P001/00000001/ANLZ0000.DAT"), shortAscii("/Contents/Artist/Kick.wav"))});
    auto prepared = beatsAt(127.5, 0.040, 80, 0);
    for (auto& x : prepared) x.tempo = 127.5;
    writeAnlz(stick / "PIONEER/USBANLZ/P001/00000001/ANLZ0000.DAT", prepared);
    Mp3Waveform c = loadAudio(track, budget);
    assert(c.beatGrid.bpm == 127.5 && !c.beatGrid.fromCache && std::abs(c.beatGrid.firstBeatSeconds - 0.040) < 0.002);
    Mp3Waveform c2 = loadAudio(track, budget);
    assert(c2.beatGrid.bpm == 127.5 && c2.beatGrid.fromCache);

    // 3. a manual grid (what the metadata process mirrors after an edit) wins over the stick, and the cache
    //    keeps the automatic grid beside it
    BeatGrid manual = c.beatGrid;
    manual.bpm = 127.6;
    manual.firstBeatSeconds = 0.055;
    manual.manual = true;
    assert(saveBeatGridCache(track, manual));
    Mp3Waveform d = loadAudio(track, budget);
    assert(d.beatGrid.manual && d.beatGrid.bpm == 127.6 && d.beatGrid.firstBeatSeconds == 0.055);
    BeatGrid automatic;
    assert(loadAutomaticBeatGridCache(track, automatic) && automatic.bpm == 127.5 && !automatic.manual);
    manual.bpm = 127.7;                                         // a second edit keeps the same automatic grid
    assert(saveBeatGridCache(track, manual));
    assert(loadAutomaticBeatGridCache(track, automatic) && automatic.bpm == 127.5);
    BeatGrid loaded;
    assert(loadBeatGridCache(track, loaded) && loaded.manual && loaded.bpm == 127.7);

    // 4. dropping the manual grid (GRID RESET in the metadata process) puts the automatic one back
    clearBeatGridCache(track);
    assert(loadBeatGridCache(track, loaded) && !loaded.manual && loaded.bpm == 127.5);
    clearBeatGridCache(track);                                  // no manual grid: the entry is removed
    assert(!loadBeatGridCache(track, loaded) && !loadAutomaticBeatGridCache(track, loaded));

    // 5. the same file outside a stick, cache empty, manual grid only: nothing automatic to go back to
    const std::string plain = (root / "plain" / "Kick.wav").string();
    fs::create_directories(root / "plain");
    fs::copy_file(track, plain);
    manual.bpm = 128.0;
    assert(saveBeatGridCache(plain, manual));
    assert(!loadAutomaticBeatGridCache(plain, automatic));
    Mp3Waveform e = loadAudio(plain, budget);
    assert(e.beatGrid.manual && e.beatGrid.bpm == 128.0);

    // 6. a stick whose grid has no straight tempo: the deck's own analysis is used and cached
    fs::remove_all(root / "cache");
    auto bent = beatsAt(120.0, 0.040, 40, 0);
    for (const auto& x : beatsAt(131.0, bent.back().ms / 1000.0 + 60.0 / 131.0, 40, 0)) bent.push_back(x);
    writeAnlz(stick / "PIONEER/USBANLZ/P001/00000001/ANLZ0000.DAT", bent);
    Mp3Waveform f = loadAudio(track, budget);
    assert(f.beatGrid.estimated && std::abs(f.beatGrid.bpm - 128.0) < 0.05);

    fs::remove_all(root);
    std::printf("PASS 2.2.119h grid sources (manual > stick > cache > analysis; automatic grid kept; instant reset)\n");
}
