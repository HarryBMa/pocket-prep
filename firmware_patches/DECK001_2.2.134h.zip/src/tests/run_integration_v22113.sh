#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
${CXX:-g++} -std=c++17 -O0 -pthread -Wall -Wextra -Wpedantic -fsyntax-only \
  beat_grid.cpp pulse_beat.cpp beat_grid_cache.cpp \
  player.cpp deck_link.cpp deck_controller.cpp \
  ui_wave_scene.cpp ui_scene_composer.cpp deck_application.cpp
python3 tools/build_release.py version | grep -Fx '2.2.113'
printf 'PASS v2.2.113 INTEGRATION (analyzer/cache and playback/link/UI compile)\n'
