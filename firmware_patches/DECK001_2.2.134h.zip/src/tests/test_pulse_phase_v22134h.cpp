// 2.2.134h: Pulse phase refinement (PulseBeat::Options::refinePhase, switched on with DECK001_PULSE_PHASE=1).
//   1. the phase stage against its Python reference (tools/needle pulse_phase.py) on the same samples
//   2. the switch: analyze() with it moves the grid it finds without it by what phaseFit measures; without it
//      nothing is measured and nothing moves
//   3. the guards: over 150 BPM, onsets scattered more than 6 ms, fewer than 8 beats -> the grid stays
//   4. three windows (Options::maxSeconds) measure the same offset as the whole track
//   5. estimateBeatGrid(): the unrefined grid without DECK001_PULSE_PHASE, the refined one with =1
//   sh tests/run_fast_v22134h.sh   (from the source root; it runs this twice, without and with the variable)
#include "../beat_grid.h"
#include "../mp3_waveform.h"
#include "../pulse_beat.h"
#include "../settings.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

static std::vector<float> testSignal(double seconds) {   // same formula as tools/needle pulse_cexport.test_signal
    const int sr = 22050;
    const double pi = 3.14159265358979323846, beat = 60.0 / 128.0;
    std::vector<float> x(std::size_t(seconds * sr));
    for (std::size_t n = 0; n < x.size(); ++n) {
        const double t = double(n) / sr, tb = std::fmod(t, beat);
        const bool one = (long long)std::floor(t / beat) % 4 == 0;
        const double kick = std::sin(2 * pi * 55.0 * tb) * std::exp(-tb / 0.12) * (one ? 0.8 : 0.55);
        const double off = std::fmod(t + beat / 2, beat);
        const double hat = 0.15 * std::sin(2 * pi * 8000.0 * off) * std::exp(-off / 0.015);
        const long long bar = (long long)std::floor(t / (4 * beat));
        const double bass = 0.25 * std::sin(2 * pi * 55.0 * std::pow(2.0, (bar % 4) * 3 / 12.0) * t);
        x[n] = float(kick + hat + bass);
    }
    return x;
}

static std::vector<float> stereo441(const std::vector<float>& x) {   // 2x by linear interpolation, both channels
    std::vector<float> up(x.size() * 2 * 2);
    for (std::size_t i = 0; i + 1 < x.size(); ++i)
        for (int k = 0; k < 2; ++k) {
            const float v = k == 0 ? x[i] : 0.5f * (x[i] + x[i + 1]);
            up[(2 * i + k) * 2] = up[(2 * i + k) * 2 + 1] = v;
        }
    return up;
}

// Grid tempo, a grid beat (s), and pulse_phase.py's refine() for that grid on testSignal(20): offset (before
// the guards, s), spread (s), beats that counted. `pulse_phase.py fixture` prints these rows.
struct PhaseRow { double bpm, first, offset, spread; int beats; };
static const PhaseRow kPhaseFixture[] = {
    {128.0, 0.0, -0.002278940305538737, 0.00017586754622200829, 42},
    {128.0, 0.011, -0.01327894030553797, 0.00017586754622200829, 42},
    {128.0, 0.45505, 0.011421059694461309, 0.00017586754622200829, 42},
    {128.0, 0.238375, -0.004188075593100273, 0.0004496978239019178, 43},
    {64.0, 0.006, -0.008278940305538964, 0.0002947240035964249, 21},
    {127.9, 0.002, -0.011919007324891564, 0.0034845295716667835, 42},
};

int main() {
    int fails = 0;
    const auto x = testSignal(20.0);

    {   // 1. C++ against Python
        double worst = 0;
        bool counts = true;
        for (const PhaseRow& w : kPhaseFixture) {
            const auto f = PulseBeat::phaseFit(x, w.bpm, w.first);
            worst = std::max({worst, std::abs(f.offset - w.offset), std::abs(f.spread - w.spread)});
            counts = counts && f.beats == w.beats;
        }
        std::printf("phase stage: max |C++ - python| = %.3f us over %zu grids, beat counts %s\n", worst * 1e6,
                    sizeof(kPhaseFixture) / sizeof(kPhaseFixture[0]), counts ? "equal" : "DIFFERENT");
        if (worst > 5e-6 || !counts) { std::printf("FAIL phase stage\n"); ++fails; }
        if (PulseBeat::phaseFit({}, 128.0, 0.0).beats != 0 || PulseBeat::phaseFit(x, 0.0, 0.0).beats != 0) {
            std::printf("FAIL phase stage on no audio / no tempo\n");
            ++fails;
        }
    }

    const auto up = stereo441(x);
    PulseBeat::Options on;
    on.refinePhase = true;
    const auto plain = PulseBeat::analyze(up.data(), up.size() / 2, 2, 44100);
    const auto moved = PulseBeat::analyze(up.data(), up.size() / 2, 2, 44100, 0.0, on);
    {   // 2. the switch
        const auto fit = PulseBeat::phaseFit(x, plain.bpm, plain.firstBeatSeconds);   // x: before the 2x upsampling
        const double bar = 4 * 60.0 / plain.bpm;
        const double step = std::remainder(moved.firstBeatSeconds - plain.firstBeatSeconds, bar);
        std::printf("switch: off first=%.5f s; on first=%.5f s, moved %+.3f ms (measured %+.3f ms, spread %.3f ms, "
                    "%d beats); phaseFit on the 22.05 kHz signal %+.3f ms\n", plain.firstBeatSeconds, moved.firstBeatSeconds,
                    step * 1e3, moved.phaseOffset * 1e3, moved.phaseSpread * 1e3, moved.phaseBeats, fit.offset * 1e3);
        if (!plain.ok || !plain.steady || plain.phaseShift != 0 || plain.phaseOffset != 0 || plain.phaseBeats != 0) {
            std::printf("FAIL switch off\n");
            ++fails;
        }
        if (!moved.ok || moved.bpm != plain.bpm || moved.phaseBeats < 8 || moved.phaseShift != moved.phaseOffset ||
            std::abs(step - moved.phaseShift) > 1e-9 || std::abs(moved.phaseOffset - fit.offset) > 0.0005 ||
            std::abs(moved.phaseShift) < 0.0002 || moved.firstBeatSeconds < 0 || moved.firstBeatSeconds >= bar) {
            std::printf("FAIL switch on\n");
            ++fails;
        }
    }
    {   // 3. the guards
        auto grid = [](double bpm, double first) {
            PulseBeat::Result g;
            g.ok = g.steady = true;
            g.bpm = bpm;
            g.firstBeatSeconds = first;
            return g;
        };
        auto fast = grid(174.0, 0.5), loose = grid(128.0, 0.5), few = grid(128.0, 0.5), good = grid(128.0, 0.001);
        const bool f = PulseBeat::applyPhase(fast, {0.004, 0.001, 200}), l = PulseBeat::applyPhase(loose, {0.004, 0.0061, 200});
        const bool w = PulseBeat::applyPhase(few, {0.004, 0.001, 7}), g = PulseBeat::applyPhase(good, {-0.004, 0.001, 200});
        const double bar = 4 * 60.0 / 128.0;
        std::printf("guards: 174 BPM moved=%d, spread 6.1 ms moved=%d, 7 beats moved=%d; 128 BPM, -4 ms from 0.001 s "
                    "-> %.4f s (moved=%d)\n", f, l, w, good.firstBeatSeconds, g);
        if (f || l || w || fast.firstBeatSeconds != 0.5 || fast.phaseShift != 0 || fast.phaseOffset != 0.004 ||
            loose.firstBeatSeconds != 0.5 || few.firstBeatSeconds != 0.5 || !g ||
            std::abs(good.firstBeatSeconds - (bar - 0.003)) > 1e-12 || good.phaseShift != -0.004) {
            std::printf("FAIL guards\n");
            ++fails;
        }
    }
    {   // 4. windows: 3 x 30 s of a 150-s track against the whole track
        const auto longUp = stereo441(testSignal(150.0));
        PulseBeat::Options whole = on, windows = on;
        windows.maxSeconds = 90;
        const auto a = PulseBeat::analyze(longUp.data(), longUp.size() / 2, 2, 44100, 0.0, whole);
        const auto b = PulseBeat::analyze(longUp.data(), longUp.size() / 2, 2, 44100, 0.0, windows);
        std::printf("windows: whole track %.0f s measured %+.3f ms on %d beats; 3 x 30 s (%.0f s) %+.3f ms on %d beats\n",
                    a.analysedSeconds, a.phaseOffset * 1e3, a.phaseBeats, b.analysedSeconds, b.phaseOffset * 1e3, b.phaseBeats);
        if (!a.ok || !b.ok || b.analysedSeconds > 95 || a.phaseBeats < 250 || b.phaseBeats < 120 || b.phaseBeats >= a.phaseBeats ||
            std::abs(a.phaseOffset - b.phaseOffset) > 0.0005) {
            std::printf("FAIL windows\n");
            ++fails;
        }
    }
    {   // 5. the deck's switch, through estimateBeatGrid()
        const char* env = std::getenv("DECK001_PULSE_PHASE");
        const bool expectOn = env && std::string(env) == "1";
        const auto up30 = stereo441(testSignal(30.0));
        const double snap = Settings::kPreferIntegerTempo ? 0.02 : 0.0;
        const auto off30 = PulseBeat::analyze(up30.data(), up30.size() / 2, 2, 44100, snap);
        const auto on30 = PulseBeat::analyze(up30.data(), up30.size() / 2, 2, 44100, snap, on);
        Mp3Waveform song;
        song.sampleRate = 44100;
        song.pcmStereo = up30;
        estimateBeatGrid(song);
        const double bar = 4 * 60.0 / on30.bpm;
        const double toOff = std::abs(std::remainder(song.beatGrid.firstBeatSeconds - off30.firstBeatSeconds, bar));
        const double toOn = std::abs(std::remainder(song.beatGrid.firstBeatSeconds - on30.firstBeatSeconds, bar));
        std::printf("estimateBeatGrid with DECK001_PULSE_PHASE %s: bpm=%.3f first=%.5f s, %.3f ms from the unrefined "
                    "grid, %.3f ms from the refined one\n", expectOn ? "= 1" : "not 1", song.beatGrid.bpm,
                    song.beatGrid.firstBeatSeconds, toOff * 1e3, toOn * 1e3);
        if (!song.beatGrid.estimated || std::abs(song.beatGrid.bpm - on30.bpm) > 1e-9 || std::abs(on30.phaseShift) < 0.0002 ||
            (expectOn ? toOn : toOff) > 1e-9 || (expectOn ? toOff : toOn) < 0.0002) {
            std::printf("FAIL estimateBeatGrid\n");
            ++fails;
        }
    }
    std::printf(fails ? "%d FAILED\n" : "ALL PASSED\n", fails);
    return fails ? 1 : 0;
}
