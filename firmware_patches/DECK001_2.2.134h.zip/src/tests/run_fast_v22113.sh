#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
tmp=$(mktemp -d);trap 'rm -rf "$tmp"' EXIT HUP INT TERM
cxx=${CXX:-g++}
"$cxx" -std=c++17 -O2 -pthread -Wall -Wextra -Wpedantic -I. \
    tests/test_bpm_truth_v22113.cpp beat_grid.cpp pulse_beat.cpp -o "$tmp/bpm-truth"
"$tmp/bpm-truth"
"$cxx" -std=c++17 -O1 -pthread -Wall -Wextra -Wpedantic -I. \
    tests/test_bpm_cache_migration_v22113.cpp beat_grid_cache.cpp -o "$tmp/bpm-cache"
"$tmp/bpm-cache"
"$cxx" -std=c++17 -O1 -pthread -Wall -Wextra -Wpedantic -I. \
    tests/test_seamless_quality_v22113.cpp -o "$tmp/seamless-quality"
"$tmp/seamless-quality"
"$cxx" -std=c++17 -O2 -pthread -Wall -Wextra -Wpedantic -I. \
    tests/test_electronic_grid.cpp beat_grid.cpp pulse_beat.cpp -o "$tmp/existing-bpm"
"$tmp/existing-bpm"
sh tests/run_fast_v22112.sh
printf 'PASS v2.2.113 FAST (known BPM, phase, tempo classes, manual grid, Seamless gate + inherited tests)\n'
