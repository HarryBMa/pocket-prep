#!/bin/sh
# v2.2.131h (= 2.2.119h on v2.2.131): Pulse (C++ vs the PyTorch reference, grid, double time, 48 kHz), the grid of a prepared stick,
# where a loaded track's grid comes from (manual > stick > cache > analysis), then every inherited FAST test.
set -eu
cd "$(dirname "$0")/.."
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT HUP INT TERM
cxx=${CXX:-g++}
"$cxx" -std=c++17 -O3 -ffast-math -pthread -I. -c pulse_beat.cpp -o "$tmp/pulse_beat.o"
"$cxx" -std=c++17 -O2 -Wall -Wextra -Wpedantic -pthread -I. \
    tests/test_pulse_beat_v22119h.cpp "$tmp/pulse_beat.o" -o "$tmp/pulse"
"$tmp/pulse" tests/fixtures/pulse
"$cxx" -std=c++17 -O2 -Wall -Wextra -Wpedantic -I. \
    tests/test_stick_grid_v22119h.cpp stick_beat_grid.cpp -o "$tmp/stick"
"$tmp/stick"
"$cxx" -std=c++17 -O2 -Wall -Wextra -Wpedantic -pthread -I. \
    tests/test_grid_sources_v22119h.cpp mp3_waveform.cpp beat_grid.cpp stick_beat_grid.cpp beat_grid_cache.cpp \
    waveform_cache.cpp "$tmp/pulse_beat.o" -o "$tmp/grid-sources" -ldl
"$tmp/grid-sources"
"$cxx" -std=c++17 -O1 -pthread -Wall -Wextra -Wpedantic -I. \
    tests/test_deck_link_pulse_v22131h.cpp player.cpp beat_navigation.cpp "$tmp/pulse_beat.o" -o "$tmp/link-pulse"
"$tmp/link-pulse"
"$cxx" -std=c++17 -O1 -pthread -Wall -Wextra -Wpedantic -I. \
    tests/test_grid_cache.cpp beat_grid_cache.cpp -o "$tmp/grid-cache"
"$tmp/grid-cache"
sh tests/run_fast_v22120.sh
sh tests/run_fast_v22131.sh
printf 'PASS v2.2.131h FAST (Pulse, stick grid, grid sources + inherited regression tests)\n'
