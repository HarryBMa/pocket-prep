#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
${CXX:-g++} -std=c++17 -O0 -pthread -Wall -Wextra -Wpedantic -fsyntax-only \
  player.cpp deck_link.cpp beat_grid.cpp pulse_beat.cpp deck_controller.cpp \
  ui_wave_scene.cpp ui_scene_composer.cpp deck_application.cpp
python3 tools/build_release.py version | grep -Fx '2.2.112'
printf 'PASS v2.2.112 INTEGRATION (player/link/analyzer/UI source compilation)\n'
