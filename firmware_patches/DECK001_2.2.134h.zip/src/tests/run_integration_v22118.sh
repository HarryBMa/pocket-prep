#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
${CXX:-g++} -std=c++17 -O0 -pthread -Wall -Wextra -Wpedantic -DDECK001_ENABLE_DECKSTRETCH -I. -fsyntax-only \
 beat_grid.cpp pulse_beat.cpp ui_frame_renderer.cpp ui_scene_composer.cpp ui_wave_scene.cpp interface.cpp \
 ui_settings_controller.cpp user_preferences.cpp deck_application.cpp \
 track_session.cpp player.cpp deck_link.cpp
python3 tools/build_release.py version | grep -Fx '2.2.118'
printf 'PASS v2.2.118 INTEGRATION (local shared clock, timestamped network phase and UI compatibility)\n'
