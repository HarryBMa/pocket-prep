// 2.2.119h: beat grid read from a prepared stick (export.pdb + ANLZ PQTZ). Builds a small stick in a temp
// folder (tests/stick_fixture_v22119h.h) and checks the reader.
#include "../mp3_waveform.h"
#include "stick_fixture_v22119h.h"
#include <cassert>
#include <cstdio>
int main() {
    const fs::path root = fs::temp_directory_path() / "deck001-v22119h-stick";
    fs::remove_all(root);
    const fs::path pdb = root / "PIONEER" / "rekordbox" / "export.pdb";
    writePdb(pdb, {trackRow(shortAscii("/PIONEER/USBANLZ/P001/00000001/ANLZ0000.DAT"), shortAscii("/Contents/Artist/Track One.mp3")),
                   trackRow(shortAscii("/PIONEER/USBANLZ/P001/00000002/ANLZ0000.DAT"), utf16(u"/Contents/Ångest/Spår Två.flac")),
                   trackRow(shortAscii("/PIONEER/USBANLZ/P001/00000003/ANLZ0000.DAT"), shortAscii("/Contents/Artist/Drift.mp3")),
                   trackRow(shortAscii("/PIONEER/USBANLZ/P001/00000004/ANLZ0000.DAT"), shortAscii("/Contents/Artist/Fast.mp3")),
                   // as a Mac writes it: accents decomposed (A + combining ring, a + combining diaeresis)
                   trackRow(shortAscii("/PIONEER/USBANLZ/P001/00000005/ANLZ0000.DAT"), utf16(u"/Contents/A\u030Angest/Tra\u0308d \u1112\u1161\u11AB.mp3")),
                   trackRow(shortAscii("/PIONEER/USBANLZ/P001/00000006/ANLZ0000.DAT"), utf16(u"/Contents/\u041C\u0423\u0417\u042B\u041A\u0410/\u00C9t\u00E9.mp3"))});
    writeAnlz(root / "PIONEER/USBANLZ/P001/00000001/ANLZ0000.DAT", beatsAt(126.0, 0.123, 600, 2));   // beat 1 = beat #2
    writeAnlz(root / "PIONEER/USBANLZ/P001/00000002/ANLZ0000.DAT", beatsAt(123.456, 0.400, 500, 0));
    auto drift = beatsAt(120.0, 0.05, 200, 0);                                                     // tempo change
    for (const auto& b : beatsAt(124.0, drift.back().ms / 1000.0 + 60.0 / 124.0, 200, 0)) drift.push_back(b);
    writeAnlz(root / "PIONEER/USBANLZ/P001/00000003/ANLZ0000.DAT", drift);
    writeAnlz(root / "PIONEER/USBANLZ/P001/00000004/ANLZ0000.DAT", beatsAt(250.0, 0.010, 800, 1));
    writeAnlz(root / "PIONEER/USBANLZ/P001/00000005/ANLZ0000.DAT", beatsAt(126.0, 0.200, 400, 0));
    writeAnlz(root / "PIONEER/USBANLZ/P001/00000006/ANLZ0000.DAT", beatsAt(126.0, 0.300, 400, 0));

    BeatGrid g;
    // 1. straight 126 BPM grid; bar line on the beat numbered 1; path case-insensitive (FAT / exFAT)
    assert(loadStickBeatGrid((root / "contents/ARTIST/track one.MP3").string(), g));
    const double p126 = 60.0 / 126.0, bar126 = 4 * p126;
    const double expect = std::fmod(0.123 + 2 * p126, bar126);
    std::printf("126: bpm=%.4f raw=%.4f first=%.4f (expect %.4f) snapped=%d\n", g.bpm, g.rawBpm, g.firstBeatSeconds, expect, g.integerTempoSelected);
    assert(g.bpm == 126.0 && g.integerTempoSelected && std::abs(g.firstBeatSeconds - expect) < 0.002);
    assert(g.estimated && !g.manual && !g.fromCache && g.confidence >= 0.5);
    // 2. UTF-16 path, decimal tempo kept
    assert(loadStickBeatGrid((root / u8"Contents/Ångest/Spår Två.flac").string(), g));
    std::printf("123.456: bpm=%.4f first=%.4f\n", g.bpm, g.firstBeatSeconds);
    assert(std::abs(g.bpm - 123.456) < 0.002 && !g.integerTempoSelected && std::abs(g.firstBeatSeconds - 0.400) < 0.002);
    // 3. tempo change: not a straight grid -> false (the deck analyses the track)
    assert(!loadStickBeatGrid((root / "Contents/Artist/Drift.mp3").string(), g));
    // 4. 250 BPM folds into the deck's range; the bar line stays on a beat numbered 1
    assert(loadStickBeatGrid((root / "Contents/Artist/Fast.mp3").string(), g));
    std::printf("250 -> bpm=%.3f first=%.4f\n", g.bpm, g.firstBeatSeconds);
    assert(g.bpm == 125.0 && std::abs(std::remainder(g.firstBeatSeconds - (0.010 + 60.0 / 250.0), 60.0 / 250.0)) < 0.002);
    // 4b. paths as FAT / exFAT compare them: composed vs decomposed accents (also Hangul), case in any script
    assert(loadStickBeatGrid((root / u8"Contents/\u00C5NGEST/tr\u00E4d \uD55C.MP3").string(), g) && g.bpm == 126.0);
    assert(std::abs(g.firstBeatSeconds - 0.200) < 0.002);
    assert(loadStickBeatGrid((root / u8"contents/\u043C\u0443\u0437\u044B\u043A\u0430/E\u0301TE\u0301.mp3").string(), g));
    assert(std::abs(g.firstBeatSeconds - 0.300) < 0.002);
    assert(!loadStickBeatGrid((root / u8"Contents/Angest/Trad \uD55C.mp3").string(), g));   // an accent is not optional

    // 4c. tempo: the stored times decide. (All times are whole ms, as in a real PQTZ.)
    using StickBeatGrid::gridFromBeats;
    auto withTempo = [](std::vector<StickBeatGrid::Beat> b, double tempo) { for (auto& x : b) x.tempo = tempo; return b; };
    assert(gridFromBeats(withTempo(beatsAt(126.02, 0.050, 600, 0), 126.02), g));           // rekordbox, 0.01 steps
    std::printf("126.02: bpm=%.5f snapped=%d\n", g.bpm, g.integerTempoSelected);
    assert(g.bpm == 126.02 && !g.integerTempoSelected);                                   // not rounded to 126
    assert(gridFromBeats(withTempo(beatsAt(126.02, 0.050, 600, 0), 0), g));               // no tempo stored: fitted
    assert(std::abs(g.bpm - 126.02) < 0.001 && !g.integerTempoSelected);
    assert(gridFromBeats(withTempo(beatsAt(128.0, 0.050, 600, 0), 128.0), g) && g.bpm == 128.0 && g.integerTempoSelected);
    assert(gridFromBeats(withTempo(beatsAt(124.369, 0.050, 600, 0), 124.37), g));         // a prep app's 124.369
    std::printf("124.369 (stored as 124.37): bpm=%.5f\n", g.bpm);
    assert(std::abs(g.bpm - 124.369) < 0.0005);                                           // the times win
    assert(gridFromBeats(withTempo(beatsAt(127.9996, 0.050, 600, 0), 0), g) && g.bpm == 128.0 && g.integerTempoSelected);

    // 4d. tempo changes: the longest straight section when it holds >= 60 % of the beats
    auto joined = [](std::vector<StickBeatGrid::Beat> a, double bpmB, int nB, double jumpMs) {
        const double t0 = a.back().ms / 1000.0 + 60.0 / bpmB + jumpMs / 1000.0;
        for (const auto& b : beatsAt(bpmB, t0, nB, int((4 - a.size() % 4) % 4))) a.push_back(b);
        return a;
    };
    assert(gridFromBeats(joined(beatsAt(100.0, 0.100, 60, 0), 126.0, 540, 0), g));         // slow intro, then 126
    std::printf("intro 100 -> 126: bpm=%.4f confidence=%.3f first=%.4f\n", g.bpm, g.confidence, g.firstBeatSeconds);
    assert(g.bpm == 126.0 && std::abs(g.confidence - 0.95 * 0.9) < 1e-9);
    {   // the bar line is the 126 section's: its first beat is a beat 1
        const double start = (std::round(0.100 * 1000) + 59 * 600.0) / 1000.0 + 60.0 / 126.0, bar = 4 * 60.0 / 126.0;
        assert(std::abs(std::remainder(g.firstBeatSeconds - start, bar)) < 0.002);
    }
    assert(gridFromBeats(joined(beatsAt(126.0, 0.050, 400, 0), 126.0, 200, 30.0), g));     // grid re-anchored 30 ms later
    assert(g.bpm == 126.0 && std::abs(g.confidence - 0.95 * 400 / 600.0) < 1e-9 && std::abs(g.firstBeatSeconds - 0.050) < 0.002);
    assert(gridFromBeats(joined(beatsAt(126.0, 0.050, 420, 0), 126.5, 180, 0), g));        // a bend too small for one beat to show
    std::printf("126 -> 126.5 at 70 %%: bpm=%.4f confidence=%.3f\n", g.bpm, g.confidence);
    assert(std::abs(g.bpm - 126.0) < 0.01 && g.confidence > 0.6 && g.confidence < 0.7);
    assert(!gridFromBeats(joined(beatsAt(126.0, 0.050, 300, 0), 126.5, 300, 0), g));       // half and half: no grid
    {   // live drummer: the tempo wanders all the time
        std::vector<StickBeatGrid::Beat> wander;
        double t = 50;
        for (int i = 0; i < 600; ++i) { wander.push_back({i % 4 + 1, std::round(t), 0}); t += 500.0 + 12.0 * std::sin(i / 9.0); }
        assert(!gridFromBeats(wander, g));
    }

    // 5. not in the export, outside any stick, missing ANLZ, damaged ANLZ
    assert(!loadStickBeatGrid((root / "Contents/Artist/Other.mp3").string(), g));
    assert(!loadStickBeatGrid("/nonexistent/deck001/x.mp3", g));
    fs::remove(root / "PIONEER/USBANLZ/P001/00000002/ANLZ0000.DAT");
    assert(!loadStickBeatGrid((root / u8"Contents/Ångest/Spår Två.flac").string(), g));
    std::ofstream(root / "PIONEER/USBANLZ/P001/00000001/ANLZ0000.DAT", std::ios::binary | std::ios::trunc) << "PMAI garbage";
    assert(!loadStickBeatGrid((root / "Contents/Artist/Track One.mp3").string(), g));
    // 6. damaged export.pdb: no crash, no grid
    std::ofstream(pdb, std::ios::binary | std::ios::trunc) << std::string(5000, '\xff');
    assert(!loadStickBeatGrid((root / "Contents/Artist/Fast.mp3").string(), g));
    fs::remove_all(root);
    std::printf("PASS 2.2.119h stick beat grid (export.pdb + PQTZ, FAT-style paths, UTF-16, exact tempo, tempo changes, fold, damaged files)\n");
}
