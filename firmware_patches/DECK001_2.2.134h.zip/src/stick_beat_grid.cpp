// v2.2.118h4: beat grid from a prepared stick. See stick_beat_grid.h.
// Formats (rekordbox USB export, as documented by Deep Symmetry's crate-digger and rekordcrate):
//  export.pdb  little-endian. File header: u32 0, u32 page size, u32 table count, ..., table pointers from
//              0x1C (16 bytes each: u32 type, u32 -, u32 first page, u32 last page). Table type 0 = tracks.
//              Page: 0x28-byte header (u32 next page at 0x0C; 24-bit row counts at 0x18: 13 bits row
//              slots, 11 bits valid rows; flags at 0x1B, bit 0x40 = index page), rows on the heap from 0x28,
//              row groups of 16 from the page end backwards: [16 x u16 offsets][u16 present bits][u16];
//              row r of a group is offsets[15 - r] and present bit r.
//              Track row: u16 subtype, ..., 21 u16 string offsets at 0x5E (relative to the row);
//              string 14 = ANLZ path, 20 = file path. DeviceSQL strings: short ASCII ((len+1)<<1 | 1, bytes),
//              long ASCII (0x40, u16 total length, pad), UTF-16LE (0x90, u16 total length, pad).
//  ANLZ0000.DAT big-endian. "PMAI", u32 header length, u32 file length, then sections: 4-char tag,
//              u32 header length, u32 section length. PQTZ: header 24 bytes ending in u32 beat count;
//              beats of 8 bytes: u16 bar position (1-4), u16 tempo x 100, u32 time in ms.
#include "stick_beat_grid.h"
#include "beat_grid.h"
#include "mp3_waveform.h"
#include "settings.h"
#include "stick_path_fold.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <map>
#include <mutex>
#include <utility>

namespace {
namespace fs = std::filesystem;

std::vector<unsigned char> readFile(const fs::path& p, std::size_t maxBytes) {
    std::error_code ec;
    const auto size = fs::file_size(p, ec);
    if (ec || size == 0 || size > maxBytes) return {};
    std::ifstream f(p, std::ios::binary);
    std::vector<unsigned char> d(size);
    if (!f.read(reinterpret_cast<char*>(d.data()), std::streamsize(size))) return {};
    return d;
}

std::uint32_t le32(const std::vector<unsigned char>& d, std::size_t o) {
    return o + 4 <= d.size() ? std::uint32_t(d[o]) | std::uint32_t(d[o + 1]) << 8 | std::uint32_t(d[o + 2]) << 16 |
                                   std::uint32_t(d[o + 3]) << 24 : 0;
}
std::uint16_t le16(const std::vector<unsigned char>& d, std::size_t o) {
    return o + 2 <= d.size() ? std::uint16_t(d[o] | d[o + 1] << 8) : 0;
}
std::uint32_t be32(const std::vector<unsigned char>& d, std::size_t o) {
    return o + 4 <= d.size() ? std::uint32_t(d[o]) << 24 | std::uint32_t(d[o + 1]) << 16 | std::uint32_t(d[o + 2]) << 8 |
                                   std::uint32_t(d[o + 3]) : 0;
}
std::uint16_t be16(const std::vector<unsigned char>& d, std::size_t o) {
    return o + 2 <= d.size() ? std::uint16_t(d[o] << 8 | d[o + 1]) : 0;
}

void putUtf8(std::string& s, std::uint32_t c) {
    if (c < 0x80) s += char(c);
    else if (c < 0x800) { s += char(0xC0 | c >> 6); s += char(0x80 | (c & 0x3F)); }
    else if (c < 0x10000) { s += char(0xE0 | c >> 12); s += char(0x80 | ((c >> 6) & 0x3F)); s += char(0x80 | (c & 0x3F)); }
    else { s += char(0xF0 | c >> 18); s += char(0x80 | ((c >> 12) & 0x3F)); s += char(0x80 | ((c >> 6) & 0x3F)); s += char(0x80 | (c & 0x3F)); }
}

// DeviceSQL string at absolute offset o (bounded by end); "" if malformed
std::string deviceSqlString(const std::vector<unsigned char>& d, std::size_t o, std::size_t end) {
    if (o >= end) return {};
    const unsigned kind = d[o];
    std::string s;
    if (kind & 1) {                                                  // short ASCII
        const std::size_t n = (kind >> 1) ? (kind >> 1) - 1 : 0;
        if (o + 1 + n > end) return {};
        s.assign(d.begin() + std::ptrdiff_t(o + 1), d.begin() + std::ptrdiff_t(o + 1 + n));
    } else if (kind == 0x40 || kind == 0x90) {
        const std::size_t total = le16(d, o + 1);
        if (total < 4 || o + total > end) return {};
        if (kind == 0x40) {
            s.assign(d.begin() + std::ptrdiff_t(o + 4), d.begin() + std::ptrdiff_t(o + total));
        } else {                                                     // UTF-16LE -> UTF-8
            for (std::size_t i = o + 4; i + 1 < o + total; i += 2) {
                std::uint32_t c = le16(d, i);
                if (c >= 0xD800 && c < 0xDC00 && i + 3 < o + total) {
                    const std::uint32_t lo = le16(d, i + 2);
                    if (lo >= 0xDC00 && lo < 0xE000) { c = 0x10000 + ((c - 0xD800) << 10) + (lo - 0xDC00); i += 2; }
                }
                putUtf8(s, c);
            }
        }
    }
    return s;
}

// One key for every spelling of a path that FAT / exFAT (and a Mac that wrote the stick) treat as the same
// file: '/' separators, lower case in every script, accents decomposed (NFD), so "Ångest" matches "ångest"
// whether the Å is one character or A + a combining ring. Bytes that are not UTF-8 are kept as they are.
template <class Row, std::size_t N>
const Row* findRow(const Row (&table)[N], std::uint32_t c) {
    const Row* it = std::lower_bound(table, table + N, c, [](const Row& r, std::uint32_t v) { return r.from < v; });
    return it != table + N && it->from == c ? it : nullptr;
}
void putFolded(std::string& out, std::uint32_t c) {
    const auto lower = [](std::uint32_t v) {
        if (v < 0x80) return v >= 'A' && v <= 'Z' ? v + 32 : v;
        const auto* row = findRow(StickPathFold::kLower, v);
        return row ? row->to : v;
    };
    if (c >= 0xAC00 && c <= 0xD7A3) {                               // Hangul syllable -> jamo
        const std::uint32_t i = c - 0xAC00;
        putUtf8(out, 0x1100 + i / 588);
        putUtf8(out, 0x1161 + i % 588 / 28);
        if (i % 28) putUtf8(out, 0x11A7 + i % 28);
    } else if (const auto* d = c >= 0xC0 ? findRow(StickPathFold::kDecompositions, c) : nullptr) {
        for (unsigned k = 0; k < d->count; ++k) putUtf8(out, lower(StickPathFold::kDecompositionPool[d->offset + k]));
    } else {
        putUtf8(out, lower(c == '\\' ? std::uint32_t('/') : c));
    }
}
std::string normalise(const std::string& p) {
    std::string out;
    out.reserve(p.size() + 1);
    if (p.empty() || (p[0] != '/' && p[0] != '\\')) out += '/';
    for (std::size_t i = 0; i < p.size();) {
        const unsigned char b = static_cast<unsigned char>(p[i]);
        const int extra = b < 0x80 ? 0 : (b & 0xE0) == 0xC0 ? 1 : (b & 0xF0) == 0xE0 ? 2 : (b & 0xF8) == 0xF0 ? 3 : -1;
        std::uint32_t c = extra > 0 ? b & (0x3Fu >> extra) : b;
        bool valid = extra >= 0 && i + std::size_t(extra) < p.size();
        for (int k = 1; valid && k <= extra; ++k) {
            const unsigned char t = static_cast<unsigned char>(p[i + std::size_t(k)]);
            valid = (t & 0xC0) == 0x80;
            c = c << 6 | (t & 0x3Fu);
        }
        if (!valid) { out += p[i++]; continue; }                    // not UTF-8: the byte itself
        putFolded(out, c);
        i += std::size_t(extra) + 1;
    }
    return out;
}

// track path -> ANLZ path, for one export.pdb
std::map<std::string, std::string> parseTracks(const std::vector<unsigned char>& d) {
    std::map<std::string, std::string> out;
    const std::uint32_t pageSize = le32(d, 4), tables = le32(d, 8);
    if (pageSize < 512 || pageSize > 65536 || tables == 0 || tables > 64) return out;
    for (std::uint32_t t = 0; t < tables; ++t) {
        const std::size_t tp = 0x1C + std::size_t(t) * 16;
        if (le32(d, tp) != 0) continue;                              // 0 = tracks
        std::uint32_t page = le32(d, tp + 8);
        const std::uint32_t last = le32(d, tp + 12);
        for (int guard = 0; guard < 100000; ++guard) {
            const std::size_t base = std::size_t(page) * pageSize;
            if (base + pageSize > d.size()) break;
            const std::uint32_t counts = std::uint32_t(d[base + 0x18]) | std::uint32_t(d[base + 0x19]) << 8 |
                                         std::uint32_t(d[base + 0x1A]) << 16;
            const unsigned slots = counts & 0x1FFF;
            const bool indexPage = d[base + 0x1B] & 0x40;
            if (!indexPage && slots) {
                const std::size_t heapEnd = base + pageSize;
                for (unsigned g = 0; g < (slots + 15) / 16; ++g) {
                    const std::size_t end = base + pageSize - std::size_t(g) * 0x24;
                    if (end < base + 0x28 + 0x24) break;
                    const std::uint16_t present = le16(d, end - 4);
                    for (unsigned r = 0; r < 16; ++r) {
                        if (!(present >> r & 1)) continue;
                        const std::size_t row = base + 0x28 + le16(d, end - 0x24 + 2 * (15 - r));
                        if (row + 0x5E + 42 > heapEnd) continue;
                        const std::uint16_t subtype = le16(d, row);
                        if (!(subtype & 0x04)) continue;             // track rows use 16-bit string offsets
                        const std::string anlz = deviceSqlString(d, row + le16(d, row + 0x5E + 2 * 14), heapEnd);
                        const std::string file = deviceSqlString(d, row + le16(d, row + 0x5E + 2 * 20), heapEnd);
                        if (!anlz.empty() && !file.empty()) out[normalise(file)] = anlz;
                    }
                }
            }
            if (page == last) break;
            const std::uint32_t next = le32(d, base + 0x0C);
            if (next == page || next == 0) break;
            page = next;
        }
    }
    return out;
}

struct PdbIndex { std::uintmax_t size = 0; fs::file_time_type time{}; std::map<std::string, std::string> tracks; };
std::mutex indexMutex;
std::map<std::string, PdbIndex> indexes;                             // per export.pdb path

}  // namespace

namespace StickBeatGrid {

std::string anlzPathFor(const std::string& pdbFile, const std::string& trackPath) {
    std::error_code ec;
    const auto size = fs::file_size(pdbFile, ec);
    if (ec) return {};
    const auto time = fs::last_write_time(pdbFile, ec);
    if (ec) return {};
    std::lock_guard<std::mutex> lock(indexMutex);
    auto& ix = indexes[pdbFile];
    if (ix.size != size || ix.time != time) {                         // parse once per stick (and on change)
        ix.tracks = parseTracks(readFile(pdbFile, 256u << 20));
        ix.size = size;
        ix.time = time;
    }
    const auto it = ix.tracks.find(normalise(trackPath));
    return it == ix.tracks.end() ? std::string() : it->second;
}

bool readPqtz(const std::string& anlzFile, std::vector<Beat>& beats) {
    beats.clear();
    const auto d = readFile(anlzFile, 64u << 20);
    if (d.size() < 12 || d[0] != 'P' || d[1] != 'M' || d[2] != 'A' || d[3] != 'I') return false;
    std::size_t p = be32(d, 4);
    while (p + 12 <= d.size()) {
        const std::uint32_t headerLen = be32(d, p + 4), sectionLen = be32(d, p + 8);
        if (sectionLen < 12 || p + sectionLen > d.size()) return false;
        if (d[p] == 'P' && d[p + 1] == 'Q' && d[p + 2] == 'T' && d[p + 3] == 'Z' && headerLen >= 24) {
            const std::uint32_t n = be32(d, p + 20);
            if (headerLen + std::size_t(n) * 8 > sectionLen) return false;
            beats.reserve(n);
            for (std::uint32_t i = 0; i < n; ++i) {
                const std::size_t b = p + headerLen + std::size_t(i) * 8;
                beats.push_back({be16(d, b), double(be32(d, b + 4)), be16(d, b + 2) / 100.0});
            }
            return !beats.empty();
        }
        p += sectionLen;
    }
    return false;
}

namespace {
// Least-squares line t_ms = icpt + period * (i - from) through beats [from, to); returns the worst deviation.
double fitLine(const std::vector<Beat>& beats, std::size_t from, std::size_t to, double& period, double& icpt) {
    const double n = double(to - from);
    double mi = 0, mt = 0;
    for (std::size_t i = from; i < to; ++i) { mi += double(i - from); mt += beats[i].ms; }
    mi /= n;
    mt /= n;
    double sxy = 0, sxx = 0;
    for (std::size_t i = from; i < to; ++i) {
        sxy += (double(i - from) - mi) * (beats[i].ms - mt);
        sxx += (double(i - from) - mi) * (double(i - from) - mi);
    }
    period = sxx > 0 ? sxy / sxx : 0;
    icpt = mt - period * mi;
    double worst = 0;
    for (std::size_t i = from; i < to; ++i) worst = std::max(worst, std::abs(beats[i].ms - (icpt + period * double(i - from))));
    return worst;
}
// The same beats on a grid of exactly `bpm`: phase refitted, worst deviation returned.
double fitPhase(const std::vector<Beat>& beats, std::size_t from, std::size_t to, double bpm, double& icpt) {
    const double period = 60000.0 / bpm;
    icpt = 0;
    for (std::size_t i = from; i < to; ++i) icpt += beats[i].ms - period * double(i - from);
    icpt /= double(to - from);
    double worst = 0;
    for (std::size_t i = from; i < to; ++i) worst = std::max(worst, std::abs(beats[i].ms - (icpt + period * double(i - from))));
    return worst;
}
}  // namespace

bool gridFromBeats(const std::vector<Beat>& beats, BeatGrid& grid) {
    const std::size_t n = beats.size();
    if (n < 16) return false;
    // The deck plays one straight tempo per track. A grid with tempo changes or re-anchored sections is cut
    // into straight sections: first where a beat is more than 3 ms from where the section so far puts it (a
    // jump or a clear tempo change), then, while a section still bends more than 5 ms off its own line, at
    // the beat furthest from the straight line between its ends. The longest straight section is the grid
    // when it holds at least 60 % of the beats (Pulse's own rule for a steady tempo).
    std::vector<std::pair<std::size_t, std::size_t>> todo;            // [from, to)
    for (std::size_t from = 0; from < n;) {
        std::size_t to = std::min(n, from + 2);
        while (to < n) {
            const double step = (beats[to - 1].ms - beats[from].ms) / double(to - 1 - from);
            if (std::abs(beats[to].ms - (beats[to - 1].ms + step)) > 3.0) break;
            ++to;
        }
        todo.push_back({from, to});
        from = to;
    }
    std::size_t bestFrom = 0, bestTo = 0;
    double period = 0, icpt = 0;
    while (!todo.empty()) {
        const auto [from, to] = todo.back();
        todo.pop_back();
        if (to - from < 16 || to - from <= bestTo - bestFrom) continue;   // too short, or cannot beat the best
        double p = 0, a = 0;
        if (fitLine(beats, from, to, p, a) <= 5.0) { bestFrom = from; bestTo = to; period = p; icpt = a; continue; }
        const double chord = (beats[to - 1].ms - beats[from].ms) / double(to - 1 - from);
        std::size_t bend = from + 1;
        double worst = -1;
        for (std::size_t i = from + 1; i + 1 < to; ++i) {
            const double off = std::abs(beats[i].ms - (beats[from].ms + chord * double(i - from)));
            if (off > worst) { worst = off; bend = i; }
        }
        todo.push_back({from, bend});
        todo.push_back({bend, to});
    }
    const std::size_t count = bestTo - bestFrom;
    const double share = double(count) / double(n);
    if (count < 16 || share < 0.6) return false;                      // no dominant straight section: analyse
    if (!(period > 100.0 && period < 2000.0)) return false;           // 30-600 BPM
    const double raw0 = 60000.0 / period;
    // The stored times are whole milliseconds, so a grid that really is at a rounder tempo fits every beat
    // within 1 ms: the whole BPM first, then the tempo stored with the beats (rekordbox: 0.01 BPM steps).
    // Anything else keeps the fitted tempo: 600 beats pin it to about 0.0001 BPM, and rounding 126.02 to
    // 126 would put the grid 20 ms off at both ends of a 5-minute track.
    double bpm = raw0;
    bool snapped = false;
    bool sameTempo = beats[bestFrom].tempo > 0;
    for (std::size_t i = bestFrom; i < bestTo && sameTempo; ++i) sameTempo = beats[i].tempo == beats[bestFrom].tempo;
    const double candidates[2] = {std::round(raw0), sameTempo ? beats[bestFrom].tempo : 0.0};
    for (int c = 0; c < 2; ++c) {
        double a = 0;
        if (candidates[c] > 0 && std::abs(candidates[c] - raw0) < 0.5 &&
            fitPhase(beats, bestFrom, bestTo, candidates[c], a) <= 1.0) {
            bpm = candidates[c];
            period = 60000.0 / bpm;
            icpt = a;
            snapped = c == 0;
            break;
        }
    }
    // bar line: the bar position the beats numbered 1 vote for
    int votes[4] = {0, 0, 0, 0};
    for (std::size_t i = bestFrom; i < bestTo; ++i) if (beats[i].number == 1) ++votes[(i - bestFrom) % 4];
    const int pos = int(std::max_element(votes, votes + 4) - votes);
    double raw = raw0;
    while (bpm > Settings::kBpmMax) { bpm *= 0.5; raw *= 0.5; }       // into the deck's tempo range
    while (bpm < Settings::kBpmMin) { bpm *= 2.0; raw *= 2.0; }
    const double bar = 4.0 * 60.0 / bpm;                              // seconds, at the deck's (folded) tempo
    double first = (icpt + period * pos) / 1000.0;                    // a downbeat
    first -= std::floor((first + kBarLineBeforeStart) / bar) * bar;   // the track's first bar line (beat_grid.h)
    // v2.2.131h: the origin stays >= 0 (BeatGridQuality::phaseCandidateUsable); the cache allows up to 8 s.
    grid = BeatGrid{};
    grid.bpm = bpm;
    grid.rawBpm = raw;
    grid.firstBeatSeconds = first;
    // A prepared grid is reliable (0.95) over the part of the track it covers: a section holding 68 % of the
    // beats is the lowest that passes the Seamless / AUTO PILOT gate (0.65), 60 % still syncs over DECK LINK.
    grid.confidence = 0.95 * share;
    grid.integerTempoSelected = snapped;
    grid.estimated = true;
    grid.fromCache = false;
    grid.manual = false;
    return true;
}

}  // namespace StickBeatGrid

bool loadStickBeatGrid(const std::string& audioPath, BeatGrid& grid) {
    // DECK001_STICK_GRID=off: ignore prepared grids (always analyse on the deck)
    static const bool disabled = [] { const char* v = std::getenv("DECK001_STICK_GRID"); return v && std::string(v) == "off"; }();
    if (disabled) return false;
    try {
        std::error_code ec;
        const fs::path audio = fs::absolute(fs::path(audioPath), ec).lexically_normal();
        if (ec) return false;
        fs::path root;
        for (fs::path dir = audio.parent_path(); !dir.empty(); dir = dir.parent_path()) {
            if (fs::exists(dir / "PIONEER" / "rekordbox" / "export.pdb", ec)) { root = dir; break; }
            if (dir == dir.parent_path()) break;
        }
        if (root.empty()) return false;
        const std::string rel = "/" + audio.lexically_relative(root).generic_string();
        const std::string anlz = StickBeatGrid::anlzPathFor((root / "PIONEER" / "rekordbox" / "export.pdb").string(), rel);
        if (anlz.empty()) return false;
        std::vector<StickBeatGrid::Beat> beats;
        const fs::path anlzFile = root / fs::path(anlz).relative_path();
        if (!StickBeatGrid::readPqtz(anlzFile.string(), beats)) return false;
        BeatGrid g;
        if (!StickBeatGrid::gridFromBeats(beats, g)) {
            std::fprintf(stderr, "BEAT GRID stick: %s has no straight grid over 60 %% of its beats, not used\n", anlz.c_str());
            return false;
        }
        grid = g;
        std::fprintf(stderr, "BEAT GRID stick ok bpm=%.3f confidence=%.2f (%zu beats from %s)\n", grid.bpm, grid.confidence,
                     beats.size(), anlz.c_str());
        return true;
    } catch (...) {
        return false;
    }
}
