#include "beat_grid_cache.h"
#include "mp3_waveform.h"
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <chrono>
#include <limits>
#include <string>
#include <system_error>

namespace {
namespace fs=std::filesystem;
constexpr int kCacheFormat=6;   // 6: v2.2.131h Pulse / stick grids (bar-line anchor); v2-v5 automatic grids re-analysed
std::uint64_t hashPath(const std::string& s) {
    std::uint64_t h=14695981039346656037ULL;
    for(unsigned char c:s){ h^=c;h*=1099511628211ULL; }
    return h;
}
fs::path cachePath(const std::string& filename) {
    const fs::path source=fs::absolute(filename).lexically_normal();
    std::ostringstream name;
    name<<std::hex<<std::setfill('0')<<std::setw(16)<<hashPath(source.string())<<".grid";
    return fs::path(std::getenv("DECK001_CACHE_ROOT")?std::getenv("DECK001_CACHE_ROOT"):
                    "/home/toomom/DECK001/cache")/name.str();
}
bool attributes(const std::string& path,std::uintmax_t& size,std::int64_t& stamp) {
    std::error_code ec;
    size=fs::file_size(path,ec);if(ec)return false;
    const auto time=fs::last_write_time(path,ec);if(ec)return false;
    stamp=std::chrono::duration_cast<std::chrono::nanoseconds>(time.time_since_epoch()).count();
    return true;
}
}
// File: "<format> <size> <mtime> <bpm> <raw> <first> <confidence> <estimated> <manual> <snapped>", then,
// only beside a MANUAL grid, a second line "auto <bpm> <raw> <first> <confidence> <snapped>": the automatic
// grid the manual one replaced (2.2.119h), so going back to it needs no new analysis. Readers that know
// only the first line (2.2.118h2-h5) ignore the second.
namespace {
struct CacheFile { int version=0; BeatGrid grid; bool hasAutomatic=false; BeatGrid automatic; };
bool plausible(const BeatGrid& g) {
    return std::isfinite(g.bpm)&&g.bpm>=60&&g.bpm<=220&&std::isfinite(g.rawBpm)&&
           std::isfinite(g.firstBeatSeconds)&&g.firstBeatSeconds>=-3.0&&g.firstBeatSeconds<=8.0&&
           std::isfinite(g.confidence)&&g.confidence>=0&&g.confidence<=1;
}
// The cache entry for the file as it is now on disk (same size and modification time), any format.
bool readCacheFile(const std::string& filename,CacheFile& file) {
    std::uintmax_t size=0;std::int64_t timestamp=0;
    if(!attributes(filename,size,timestamp))return false;
    std::ifstream in(cachePath(filename));
    std::uintmax_t oldSize=0;std::int64_t oldTime=0;
    BeatGrid tmp;
    int estimated=0,manual=0,snapped=0;
    if(!(in>>file.version>>oldSize>>oldTime>>tmp.bpm>>tmp.rawBpm>>tmp.firstBeatSeconds
          >>tmp.confidence>>estimated>>manual>>snapped))return false;
    if(size!=oldSize || timestamp!=oldTime || !plausible(tmp) || estimated!=1)return false;
    tmp.estimated=true;tmp.fromCache=true;tmp.manual=(manual!=0);tmp.integerTempoSelected=(snapped!=0);
    file.grid=tmp;
    std::string tag;BeatGrid automatic;int autoSnapped=0;
    if(tmp.manual && in>>tag && tag=="auto" && in>>automatic.bpm>>automatic.rawBpm
          >>automatic.firstBeatSeconds>>automatic.confidence>>autoSnapped && plausible(automatic)) {
        automatic.estimated=true;automatic.fromCache=true;automatic.integerTempoSelected=(autoSnapped!=0);
        file.automatic=automatic;file.hasAutomatic=true;
    }
    return true;
}
bool writeCacheFile(const std::string& filename,const BeatGrid& grid,const BeatGrid* automatic) {
    std::uintmax_t size=0;std::int64_t timestamp=0;
    if(!attributes(filename,size,timestamp))return false;
    const auto target=cachePath(filename);
    std::error_code ec;fs::create_directories(target.parent_path(),ec);if(ec)return false;
    const auto temporary=target.string()+".tmp";
    {
        std::ofstream out(temporary,std::ios::trunc);
        if(!out)return false;
        out<<std::setprecision(17)<<kCacheFormat<<' '<<size<<' '<<timestamp<<' '
           <<grid.bpm<<' '<<grid.rawBpm<<' '<<grid.firstBeatSeconds<<' '
           <<grid.confidence<<' '<<int(grid.estimated)<<' '<<int(grid.manual)
           <<' '<<int(grid.integerTempoSelected)<<'\n';
        if(automatic)
            out<<"auto "<<automatic->bpm<<' '<<automatic->rawBpm<<' '<<automatic->firstBeatSeconds<<' '
               <<automatic->confidence<<' '<<int(automatic->integerTempoSelected)<<'\n';
        out.flush();if(!out)return false;
    }
    fs::rename(temporary,target,ec);
    if(ec){fs::remove(temporary);return false;}
    return true;
}
// The automatic grid in a current-format entry: the grid itself, or the one kept beside a manual grid.
bool automaticOf(const CacheFile& file,BeatGrid& grid) {
    if(file.version!=kCacheFormat)return false;
    if(!file.grid.manual){grid=file.grid;return true;}
    if(file.hasAutomatic){grid=file.automatic;return true;}
    return false;
}
}
bool loadBeatGridCache(const std::string& filename,BeatGrid& grid) {
    CacheFile file;
    if(!readCacheFile(filename,file))return false;
    // Reanalyze AUTOMATIC grids from older formats (v2: confidence without tempo
    // competition / onset evidence; v3: pre-Pulse, v2.2.118h2). Keep v2/v3 MANUAL
    // grids valid so user corrections are never lost during a firmware update.
    if(file.version!=kCacheFormat && !(file.version>=2 && file.version<kCacheFormat && file.grid.manual))return false;
    grid=file.grid;
    return true;
}
bool loadAutomaticBeatGridCache(const std::string& filename,BeatGrid& grid) {
    CacheFile file;
    return readCacheFile(filename,file) && automaticOf(file,grid);
}
bool saveBeatGridCache(const std::string& filename,const BeatGrid& grid) {
    if(!grid.estimated || !std::isfinite(grid.bpm)||!std::isfinite(grid.firstBeatSeconds))return false;
    CacheFile old;BeatGrid automatic;
    const bool keep=grid.manual && readCacheFile(filename,old) && automaticOf(old,automatic);
    return writeCacheFile(filename,grid,keep?&automatic:nullptr);
}
void clearBeatGridCache(const std::string& filename) {
    // Dropping a manual grid goes back to the automatic one it replaced, when that is known.
    CacheFile old;BeatGrid automatic;
    if(readCacheFile(filename,old) && old.grid.manual && automaticOf(old,automatic) &&
       writeCacheFile(filename,automatic,nullptr))return;
    std::error_code ec;fs::remove(cachePath(filename),ec);
}

std::string legacyBeatGridFilePath(const std::string& path){return cachePath(path).string();}
