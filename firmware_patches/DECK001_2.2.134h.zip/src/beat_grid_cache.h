#pragma once
#include <string>
struct BeatGrid;
// On-disk constant-grid cache. File size and modification timestamp are
// checked before loading; analyzer-version changes invalidate the cache.
// A manually edited grid is preserved until explicitly reanalyzed.
bool loadBeatGridCache(const std::string& mp3Path,BeatGrid& grid);
bool saveBeatGridCache(const std::string& mp3Path,const BeatGrid& grid);
void clearBeatGridCache(const std::string& mp3Path);
// 2.2.119h: the AUTOMATIC grid for the file (analysed, or read from a prepared stick): the cached grid
// itself, or the one kept beside a manual grid. saveBeatGridCache keeps it when a manual grid replaces an
// automatic one, and clearBeatGridCache puts it back instead of deleting the entry.
bool loadAutomaticBeatGridCache(const std::string& mp3Path,BeatGrid& grid);

// Legacy migration/rollback helper. Call only inside the metadata process.
std::string legacyBeatGridFilePath(const std::string& path);
