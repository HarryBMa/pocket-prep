#pragma once
struct Mp3Waveform;
// v2.2.131h: Pulse (pulse_beat.h) gives tempo, phase and the bar line (firstBeatSeconds = a downbeat when the
// track has clear bars). The v2.2.119/120 constant-tempo multi-section onset analysis is the fallback for tracks
// without a steady tempo, or for every track with DECK001_BEAT_ANALYZER=legacy.
void estimateBeatGrid(Mp3Waveform& song);
// firstBeatSeconds of an automatic grid is the track's first bar line at or after 0 s. (2.2.119h allowed one up
// to 50 ms before 0; v2.2.131's provisional-sync check, BeatGridQuality::phaseCandidateUsable, needs >= 0.)
constexpr double kBarLineBeforeStart=0.0;
// 2.2.119h: tells the analyser the grid it gave this decoded track on an earlier load (read back from the
// cache), so a later estimateBeatGrid() on the same audio (GRID RESET, on the UI thread) returns it at once
// instead of analysing for seconds. Ignores manual grids.
void rememberAutomaticBeatGrid(const Mp3Waveform& song);
