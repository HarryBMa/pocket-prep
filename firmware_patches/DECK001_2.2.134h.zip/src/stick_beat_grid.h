#pragma once
// v2.2.118h4: the beat grid a prep app (DKPRP, or rekordbox itself) wrote to the USB stick, so a prepared
// track needs no analysis on the deck. Read-only, no library: PIONEER/rekordbox/export.pdb maps the audio
// file to its ANLZ0000.DAT, whose PQTZ section lists every beat (bar position 1-4, time in ms).
// Any problem (no export, track not in it, missing / damaged file, a grid with no straight tempo over most
// of the track) returns false and the deck analyses the track as before. Never call it on an audio callback.
// DECK001_STICK_GRID=off turns it off.
#include <string>
#include <vector>

struct BeatGrid;

bool loadStickBeatGrid(const std::string& audioPath, BeatGrid& grid);

namespace StickBeatGrid {
struct Beat { int number = 0; double ms = 0; double tempo = 0; };  // number: 1-4 position in the bar; tempo: BPM
// "/PIONEER/USBANLZ/.../ANLZ0000.DAT" for a track's "/Contents/..." path, "" if none. Paths match the way
// FAT / exFAT compare them: any case, in any script, accents composed or decomposed.
std::string anlzPathFor(const std::string& pdbFile, const std::string& trackPath);
bool readPqtz(const std::string& anlzFile, std::vector<Beat>& beats);
// The grid of the longest straight section of the beats (max deviation 5 ms; at least 60 % of them), bar line
// from the beats numbered 1. confidence = 0.95 x the share of the beats in that section.
bool gridFromBeats(const std::vector<Beat>& beats, BeatGrid& grid);
}  // namespace StickBeatGrid
