#include "beat_grid.h"
#include "mp3_waveform.h"
#include "settings.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <cstdio>
#include <cstdlib>
#include "musical_sync_audit.h"
#include "pulse_beat.h"
#include <chrono>
#include <mutex>
#include <string>
#include <vector>

// Constant-tempo 4/4 electronic-music analyzer. Completely original C++.
// No FFT or runtime dependencies; consumes precomputed 10-ms energy bins.
// IMPORTANT: An onset/beat is not necessarily the first beat of a bar.
namespace {
struct Envelope {
    std::vector<float> kick;
    double binSeconds = 0;
    double energy = 0;
    double fitFromSeconds = 0;
    double fitUntilSeconds = 90;
    struct Window { double from=0, until=0, activity=0, mean=0; };
    std::vector<Window> active;
};

Envelope makeEnvelope(const Mp3Waveform& song) {
    Envelope e;
    e.binSeconds = double(song.framesPerBin)/song.sampleRate;
    e.kick.resize(song.bins.size(),0);
    const double bassRef=std::max(0.003,song.referenceBass);
    const double rmsRef=std::max(0.003,song.referenceRms);
    const double midRef=std::max(0.003,song.referenceMids);
    // Positive bass changes emphasize four-on-the-floor kick attacks over
    // persistent bass notes and off-beat hi-hats. Small mid/rms contribution
    // helps when the kick is filtered during a breakdown.
    for(std::size_t i=2;i<song.bins.size();++i) {
        const auto& a=song.bins[i];
        const auto& b=song.bins[i-1];
        const double bass=std::max(0.0,double(a.bass)-double(b.bass)*0.92)/bassRef;
        const double rms=std::max(0.0,double(a.rms)-double(b.rms)*0.93)/rmsRef;
        const double mids=std::max(0.0,double(a.mids)-double(b.mids)*0.92)/midRef;
        e.kick[i]=float(std::sqrt(std::min(2.0,0.78*bass+0.17*rms+0.05*mids)));
        e.energy+=e.kick[i];
    }
    // Prefer a high-activity, fixed-duration phase-fit window. A track can
    // have a one-minute drumless introduction; anchoring the phase only to
    // the first 90 seconds can select arbitrary phase on those songs.
    const std::size_t span=std::min(e.kick.size(),
        std::size_t(90.0/e.binSeconds));
    double window=0;
    for(std::size_t i=0;i<span;++i)window+=e.kick[i];
    double best=window;
    std::size_t first=0;
    for(std::size_t i=span;i<e.kick.size();++i) {
        window+=e.kick[i]-e.kick[i-span];
        if(window>best+1e-7){best=window;first=i-span+1;}
    }
    e.fitFromSeconds=first*e.binSeconds;
    e.fitUntilSeconds=(first+span)*e.binSeconds;
    // v2.2.119: collect several independent rhythmically INFORMATIVE
    // passages. No-drums sections are missing observations, not failed beats.
    // The 24-second windows are chosen across the entire source timeline;
    // selecting only the loudest section would hide slow tempo drift.
    const double duration=e.kick.size()*e.binSeconds;
    const int regions=std::clamp(int(std::ceil(duration/32.0)),3,12);
    const std::size_t width=std::min<std::size_t>(e.kick.size(),
        std::max<std::size_t>(1,std::size_t(24.0/e.binSeconds)));
    std::vector<double> prefix(e.kick.size()+1,0),prefixSq(e.kick.size()+1,0);
    for(std::size_t i=0;i<e.kick.size();++i){
        prefix[i+1]=prefix[i]+e.kick[i];
        prefixSq[i+1]=prefixSq[i]+double(e.kick[i])*e.kick[i];
    }
    // Absolute RMS/low-frequency background is NOT beat evidence. A sustained
    // pad or long break may be loud but have no rhythmic onsets: score windows
    // by the VARIATION of the onset envelope, not their average energy.
    const auto windowStrength=[&](std::size_t start){
        const double mean=(prefix[start+width]-prefix[start])/double(width);
        const double second=(prefixSq[start+width]-prefixSq[start])/double(width);
        return std::sqrt(std::max(0.0,second-mean*mean));
    };
    double maximum=0;
    for(int region=0;region<regions;++region){
        const std::size_t lo=std::size_t(double(region)*e.kick.size()/regions);
        const std::size_t hi=std::size_t(double(region+1)*e.kick.size()/regions);
        // Keep the window centered in its region as much as possible.
        const std::size_t fromMin=std::min(e.kick.size()-width,
            (lo>width/2)?lo-width/2:0);
        const std::size_t fromMax=std::max(fromMin,std::min(e.kick.size()-width,
            hi>width/2?hi-width/2:0));
        double bestActivity=-1;
        std::size_t bestStart=fromMin;
        for(std::size_t j=fromMin;j<=fromMax;j+=std::max<std::size_t>(1,std::size_t(1.0/e.binSeconds))){
            const double activity=windowStrength(j);
            if(activity>bestActivity){bestActivity=activity;bestStart=j;}
        }
        // The last partial step may be the best one.
        if(windowStrength(fromMax)>bestActivity){
            bestActivity=windowStrength(fromMax);bestStart=fromMax;
        }
        const double mean=(prefix[bestStart+width]-prefix[bestStart])/double(width);
        e.active.push_back({bestStart*e.binSeconds,(bestStart+width)*e.binSeconds,bestActivity,mean});
        maximum=std::max(maximum,bestActivity);
    }
    // Do not allow a silent breakdown to down-weight an otherwise stable grid.
    e.active.erase(std::remove_if(e.active.begin(),e.active.end(),[&](const Envelope::Window& w){
        return w.activity<std::max(0.004,0.32*maximum);
    }),e.active.end());
    if(e.active.empty()) e.active.push_back({e.fitFromSeconds,e.fitUntilSeconds,maximum,maximum});
    return e;
}

float read(const Envelope& e,double pos) {
    if(pos<0 || pos+1>=double(e.kick.size())) return 0;
    const std::size_t i=std::size_t(pos);
    const double f=pos-i;
    return float((1.0-f)*e.kick[i]+f*e.kick[i+1]);
}

// Beat-position score; four surrounding bins approximate a smooth onset
// window. This prevents a small bin-boundary shift from changing the result
// suddenly. Search uses the ENTIRE recording (not only its introduction).
double evaluate(const Envelope& e,double bpm,double phaseBins,
                double fromSeconds,double untilSeconds) {
    const double period=60.0/(bpm*e.binSeconds);
    const double first=std::max(0.0,fromSeconds/e.binSeconds);
    const double last=std::min(double(e.kick.size()-2),untilSeconds/e.binSeconds);
    const double firstBeat=std::ceil((first-phaseBins)/period);
    double sum=0;
    int beats=0;
    for(double n=firstBeat;;++n) {
        const double x=phaseBins+n*period;
        if(x>=last) break;
        // A relatively narrow 10-ms kernel discriminates between near-128
        // candidates across long tracks, while tolerating bin quantization.
        sum+=0.52*read(e,x)+0.24*(read(e,x-0.8)+read(e,x+0.8));
        ++beats;
    }
    return beats>0?sum/beats:0;
}

// Candidate quality is measured in active sections only. A constant-tempo
// grid must explain a single phase across all of them, including a drum break
// between sections. The waveform stays in original source-time coordinates.
double activeScore(const Envelope& e,double bpm,double phaseBins) {
    double sum=0,weight=0;
    for(const auto& w:e.active){
        const double score=evaluate(e,bpm,phaseBins,w.from,w.until);
        const double factor=std::sqrt(std::max(0.0,w.activity));
        sum+=score*factor;
        weight+=factor;
    }
    return weight>0?sum/weight:0;
}

// How much rhythmic onset energy is near predicted beats? Unlike an average
// per beat, this distinguishes the actual tempo from a half-time grid that
// lines up with only every second kick. NO automatic faster-BPM bonus.
double onsetCoverage(const Envelope& e,double bpm,double phaseBins) {
    const double period=60.0/(bpm*e.binSeconds);
    double aligned=0,total=0;
    for(const auto& w:e.active){
        const double first=w.from/e.binSeconds;
        const double end=w.until/e.binSeconds;
        for(std::size_t i=std::size_t(first);i<std::size_t(end);++i)total+=e.kick[i];
        double beatIndex=std::ceil((first-phaseBins)/period);
        for(double x=phaseBins+beatIndex*period;x<end;x+=period){
            // A 3-bin allowance for the finite 10ms onset envelope.
            aligned+=std::max({double(read(e,x-0.8)),double(read(e,x)),double(read(e,x+0.8))});
        }
    }
    return total>1e-9?std::clamp(aligned/(total*0.50),0.0,1.0):0;
}

// True 2:1 ambiguity must be decided from onsets BETWEEN the slower beats,
// not solely the kick peaks on its own beats. True slow recordings can contain
// subdivisions too; this is additional evidence, not an unconditional x2 bias.
double halfBeatPulseRatio(const Envelope& e,double bpm,double phaseBins) {
    const double p=60.0/(bpm*e.binSeconds);
    if(!(p>0))return 0;
    double on=0,between=0;
    for(const auto& w:e.active){
        const double lo=w.from/e.binSeconds, hi=w.until/e.binSeconds;
        const auto peak=[&](double at){
            return std::max({double(read(e,at-0.8)),double(read(e,at)),double(read(e,at+0.8))});
        };
        for(double x=phaseBins+std::ceil((lo-phaseBins)/p)*p;x+0.5*p<hi;x+=p){
            const double wt=std::sqrt(std::max(0.0,w.activity));
            on+=wt*peak(x);between+=wt*peak(x+0.5*p);
        }
    }
    return on>1e-9?between/on:0.0;
}

struct Fit { double bpm=0,phase=0,score=-1; };
Fit fitTempo(const Envelope& e,double bpm,double phaseStepBins) {
    const double period=60.0/(bpm*e.binSeconds);
    Fit fit{bpm,0,-1};
    // Find phase in the most informative 90-second segment, then assess
    // the same phase across the WHOLE track (long-range drift is penalized).
    for(double phase=0;phase<period;phase+=phaseStepBins) {
        const double score=activeScore(e,bpm,phase);
        if(score>fit.score) {fit.phase=phase;fit.score=score;}
    }
    fit.score=activeScore(e,bpm,fit.phase);
    return fit;
}

// Coarse fit across several rhythmically active regions, keeping one global
// phase. Inactive intervals do not dilute confidence or tempo ranking.
double coarseTempoScore(const Envelope& e,double bpm) {
    const double periodBins=60.0/(bpm*e.binSeconds);
    double best=0;
    for(double phase=0;phase<periodBins;phase+=2.0)
        best=std::max(best,activeScore(e,bpm,phase));
    return best; // Historical faster-BPM exponent removed in v2.2.119.
}

Fit refine(const Envelope& e,double centre,double radius,double step) {
    Fit best;
    const double lo=std::max(Settings::kBpmMin,centre-radius);
    const double hi=std::min(Settings::kBpmMax,centre+radius);
    for(double bpm=lo;bpm<=hi+step*0.3;bpm+=step) {
        const Fit f=fitTempo(e,bpm,0.75);
        if(f.score>best.score) best=f;
    }
    // Sub-bin phase localization for a stable first-beat reference.
    const double p=60.0/(best.bpm*e.binSeconds);
    const double phaseLo=best.phase-0.9;
    const double phaseHi=best.phase+0.9;
    double bestScore=-1;
    for(double phase=phaseLo;phase<=phaseHi;phase+=0.125) {
        const double wrapped=std::fmod(std::fmod(phase,p)+p,p);
        const double score=activeScore(e,best.bpm,wrapped);
        if(score>bestScore){bestScore=score;best.phase=wrapped;best.score=score;}
    }
    return best;
}
} // namespace

static void estimateBeatGridLegacy(Mp3Waveform& song) {
    song.beatGrid={};
    if(song.sampleRate<=0 || song.framesPerBin==0 ||
       song.bins.size()<std::size_t(25.0*song.sampleRate/song.framesPerBin)) return;
    const Envelope e=makeEnvelope(song);
    if(e.energy/e.kick.size()<0.003) return; // silence / insufficient attacks

    // Fixed-tempo, electronic-music-first: coarse tempo class, followed by
    // a fine fit over the entire decoded track. This is deliberately NOT a
    // variable-tempo / acoustic beat tracker.
    struct Candidate {double bpm=0, score=0;};
    std::vector<Candidate> candidateList;
    for(double bpm=Settings::kBpmMin;bpm<=Settings::kBpmMax+0.01;bpm+=0.5)
        candidateList.push_back({bpm,coarseTempoScore(e,bpm)});
    std::sort(candidateList.begin(),candidateList.end(),
              [](const Candidate& a,const Candidate& b){return a.score>b.score;});
    Fit raw;
    std::vector<Fit> refined;
    // Try multiple tempo classes in case a snare/hihat pattern creates an
    // autocorrelation harmonic. Separate candidates by at least 1.5 BPM.
    std::vector<double> attempted;
    // Rank multiple tempo classes, explicitly adding 1:2, 2:1, 2:3 and
    // 3:2 relatives. This catches both octave and 124->186 style ambiguity
    // even when a harmonic initially dominates the shortlist.
    std::vector<double> shortlist;
    for(const auto& candidate:candidateList) {
        if(std::none_of(shortlist.begin(),shortlist.end(),[&](double bpm){
            return std::abs(bpm-candidate.bpm)<1.5; }))shortlist.push_back(candidate.bpm);
        if(shortlist.size()==7)break;
    }
    const std::size_t seeds=std::min<std::size_t>(3,shortlist.size());
    for(std::size_t i=0;i<seeds;++i){
        const double b=shortlist[i];
        for(const double factor:{0.5,2.0,2.0/3.0,1.5}) {
            const double alternative=b*factor;
            if(alternative<Settings::kBpmMin || alternative>Settings::kBpmMax)continue;
            if(std::none_of(shortlist.begin(),shortlist.end(),[&](double bpm){
                return std::abs(bpm-alternative)<1.5; }))shortlist.push_back(alternative);
        }
    }
    double bestEvidence=-1;
    for(const double bpm:shortlist){
        const Fit f=refine(e,bpm,0.65,0.01);
        refined.push_back(f);
        const double evidence=f.score*(0.40+0.60*onsetCoverage(e,f.bpm,f.phase));
        if(raw.bpm<=0 || evidence>bestEvidence){raw=f;bestEvidence=evidence;}
    }
    bool octaveResolved=false;
    // v120: A strong kick on beats 1 and 3 with lighter snare/perc on 2 and 4
    // is often analysed as half time (e.g. real 126 -> 63). Inspect the
    // between-beat onsets AND require a credible doubled-tempo fit. Merely
    // having a faster harmonic in range is not evidence to double a true 64.
    if(raw.bpm>0 && raw.bpm<100.0 && raw.bpm*2.0>=105.0 &&
       raw.bpm*2.0<=std::min(160.0,Settings::kBpmMax)) {
        const double between=halfBeatPulseRatio(e,raw.bpm,raw.phase);
        const Fit doubled=refine(e,raw.bpm*2.0,0.035,0.005);
        if(std::getenv("DECK001_MUSICAL_DIAG"))
            std::fprintf(stderr,"GRID_OCTAVE slow=%.3f double=%.3f slower_score=%.4f double_score=%.4f subdivision=%.3f\n",
                raw.bpm,doubled.bpm,raw.score,doubled.score,between);
        if(between>=0.19 && doubled.score>=raw.score*0.57){
            raw=doubled;
            octaveResolved=true;
        }
    }
    if(raw.score<0.005) return;
    // Fine tempo fit (<0.01 BPM) limits grid drift over a six-minute track.
    const Fit precise=refine(e,raw.bpm,0.012,0.002);
    Fit chosen=precise;
    bool preferredInteger=false;
    const double nearest=std::round(precise.bpm);
    if(Settings::kPreferIntegerTempo &&
       std::abs(nearest-precise.bpm)<=Settings::kIntegerBpmTolerance &&
       nearest>=Settings::kBpmMin && nearest<=Settings::kBpmMax) {
        const Fit integerFit=refine(e,nearest,0,0.01);
        // Prefer a plausible DAW tempo only if a whole-track fit supports it.
        if(integerFit.score>=precise.score*Settings::kIntegerMinScoreRatio) {
            chosen=integerFit;
            chosen.bpm=nearest;
            preferredInteger=true;
        }
    }
    // Verify a SINGLE phase in every RHYTHMICALLY INFORMATIVE passage.
    // The local best phase supplies a reference for genuine drift; an empty
    // breakdown contributes no negative evidence. Strong evidence far apart
    // in time is especially valuable for constant-BPM dance music.
    const double phaseSeconds=chosen.phase*e.binSeconds;
    const double beatPeriodBins=60.0/(chosen.bpm*e.binSeconds);
    double consistent=0,weights=0,activeBaseline=0,activeOnset=0;
    double localTempoMin=1e9,localTempoMax=0;
    for(const auto& w:e.active){
        const double observed=evaluate(e,chosen.bpm,chosen.phase,w.from,w.until);
        double bestLocal=0;
        for(double phase=0;phase<beatPeriodBins;phase+=0.5)
            bestLocal=std::max(bestLocal,evaluate(e,chosen.bpm,phase,w.from,w.until));
        const double agreement=bestLocal>1e-8?std::clamp(observed/bestLocal,0.0,1.0):0.0;
        const double weight=std::sqrt(std::max(0.0,w.activity));
        consistent+=weight*std::clamp((agreement-0.75)/0.25,0.0,1.0);
        activeOnset+=weight*observed;
        activeBaseline+=weight*w.mean;
        weights+=weight;
        // Constant-tempo assurance: independently infer the best local tempo
        // across each active passage. A song that REALLY accelerates cannot
        // be called a reliable one-BPM grid merely by an intermediate fit.
        double localBest=-1,localBpm=chosen.bpm;
        for(double delta=-3.50;delta<=3.51;delta+=0.35){
            const double bpm=chosen.bpm+delta;
            if(bpm<Settings::kBpmMin || bpm>Settings::kBpmMax)continue;
            const double period=60.0/(bpm*e.binSeconds);
            for(double phase=0;phase<period;phase+=1.5){
                const double score=evaluate(e,bpm,phase,w.from,w.until);
                if(score>localBest){localBest=score;localBpm=bpm;}
            }
        }
        localTempoMin=std::min(localTempoMin,localBpm);
        localTempoMax=std::max(localTempoMax,localBpm);
        if(std::getenv("DECK001_MUSICAL_DIAG"))
            std::fprintf(stderr,"GRID_WINDOW from=%.1f until=%.1f bpm=%.3f obs=%.4f local=%.4f ratio=%.3f local_bpm=%.2f\n",
                w.from,w.until,chosen.bpm,observed,bestLocal,agreement,localBpm);
    }
    const double consistency=weights>0?consistent/weights:0.0;
    song.beatGrid.bpm=chosen.bpm;
    song.beatGrid.rawBpm=precise.bpm;
    song.beatGrid.firstBeatSeconds=phaseSeconds;
    // Confidence describes supported tempo/phase in active regions, not
    // percentage of the recording containing kicks. Still NOT downbeat proof.
    const double onsetLift=activeOnset/(activeBaseline+1e-9);
    const double onsetEvidence=std::clamp((onsetLift-1.15)/1.9,0.0,1.0);
    const double chosenEvidence=chosen.score*(0.40+0.60*onsetCoverage(e,chosen.bpm,chosen.phase));
    double runnerRatio=0.0;
    for(const auto& f:refined){
        // Nearby alternative refinements belong to the SAME tempo class.
        if(f.bpm>0 && std::abs(std::log(f.bpm/chosen.bpm))>0.03 &&
           !(octaveResolved && std::abs(2.0*f.bpm/chosen.bpm-1.0)<0.025)){
            const double score=f.score*(0.40+0.60*onsetCoverage(e,f.bpm,f.phase));
            runnerRatio=std::max(runnerRatio,score/(chosenEvidence+1e-9));
        }
    }
    const double separation=std::clamp((1.0-runnerRatio)/0.12,0.0,1.0);
    const double tempoEvidence=0.60+0.40*separation;
    // One isolated passage cannot establish reliable whole-track stability.
    const double regionEvidence= e.active.size()>1?1.0:0.75;
    const double spread=localTempoMax-localTempoMin;
    const double driftEvidence=e.active.size()<2?1.0:
        std::clamp((2.0-spread)/1.30,0.0,1.0);
    song.beatGrid.confidence=std::clamp(consistency*onsetEvidence*tempoEvidence*
                                         regionEvidence*driftEvidence,0.0,1.0);
    song.beatGrid.integerTempoSelected=preferredInteger;
    song.beatGrid.estimated=true;
    song.beatGrid.fromCache=false;
    song.beatGrid.manual=false;
    // Diagnostic-only ranked hypotheses; unchanged production selection.
    // The 124->186 case is a 3:2 interpretation, NOT a 0.02-BPM rounding error.
    static const bool trace=[]{const char* s=std::getenv("DECK001_MUSICAL_DIAG");
        return s && s[0]=='1' && s[1]=='\0';}();
    if(trace){
        std::fprintf(stderr,
            "BEAT ANALYSIS select=%.3f raw=%.3f phase=%.5fs confidence=%.3f score=%.5f runner=%.3f local_bpm_span=%.2f active_windows=%zu candidates=",
            chosen.bpm,precise.bpm,phaseSeconds,song.beatGrid.confidence,
            chosen.score,runnerRatio,spread,e.active.size());
        for(std::size_t i=0;i<std::min<std::size_t>(refined.size(),5);++i){
            const auto& f=refined[i];
            std::fprintf(stderr," %.3f/%.4f(%s)",f.bpm,f.score,
                MusicalSyncAudit::tempoRelation(f.bpm,chosen.bpm));
        }
        // Trace the 3:2 family independently of the weighted top-five.
        // These extra fits happen only with developer diagnostics enabled,
        // on the track-analysis thread, NEVER on an audio callback.
        const double relation2to3=chosen.bpm*2.0/3.0;
        const double relation3to2=chosen.bpm*1.5;
        if(relation2to3>=Settings::kBpmMin) {
            const auto alternative=fitTempo(e,relation2to3,0.75);
            std::fprintf(stderr," [2:3=%.2f score=%.4f]",relation2to3,alternative.score);
        }
        if(relation3to2<=Settings::kBpmMax) {
            const auto alternative=fitTempo(e,relation3to2,0.75);
            std::fprintf(stderr," [3:2=%.2f score=%.4f]",relation3to2,alternative.score);
        }
        std::fprintf(stderr,"\n");
    }
}

// v2.2.118h2/h3: Pulse (neural beat / downbeat tracker, pulse_beat.cpp) first; the legacy onset analyser
// above only when Pulse finds no steady tempo or DECK001_BEAT_ANALYZER=legacy. Runs on the
// track-preparation / analysis thread like before, NEVER on an audio callback.
namespace {
// Audio Pulse runs through per track: 0 = the whole track; N = three windows of N/3 s at 20 / 50 / 80 %.
// Measured on 200 hand-annotated tracks (PC, 3 threads, per 6.5-min track; tools/needle pulse_speed_eval.py):
//   whole track   0.64 s   tempo right 191/195, bar line on beat 1 in 87 % of tracks
//   180 (3x60 s)  0.33 s   190/195, 83 %
//   120 (3x40 s)  0.23 s   189/195, 78 %
// (2.2.119h, whole track: 0.35 s, 192/195, 87 %; the windows were not measured again.)
// Whole track by default: the windows cost bar-line accuracy. DECK001_PULSE_WINDOW=180 (seconds, set where
// the deck is started) switches to windows without a rebuild if the Pi is too slow; grids already in the
// cache stay as they are.
constexpr double kPulseAnalysisSeconds=0;
double pulseAnalysisSeconds() {
    static const double seconds=[]{
        const char* s=std::getenv("DECK001_PULSE_WINDOW");
        if(!s || !*s)return kPulseAnalysisSeconds;
        char* end=nullptr;
        const double v=std::strtod(s,&end);
        return end!=s && *end=='\0' && v>=0 && v<=3600 ? v : kPulseAnalysisSeconds;
    }();
    return seconds;
}
// GRID RESET runs estimateBeatGrid on the UI thread, and Pulse takes seconds on a Pi. So the automatic grid
// of the last few decoded tracks is remembered (PCM size, rate and a sample fingerprint): whatever the
// analysis gave (Pulse, the legacy analyser, or no grid), and the analysed grid a track was loaded with
// from the cache (rememberAutomaticBeatGrid). A reset then returns at once.
struct GridMemo { std::size_t samples=0; int rate=0; double fingerprint=0; BeatGrid grid; };
std::mutex gridMemoMutex;
std::vector<GridMemo> gridMemo;
double pcmFingerprint(const std::vector<float>& pcm) {
    double f=0;
    const std::size_t step=std::max<std::size_t>(1,pcm.size()/4099);
    for(std::size_t i=0;i<pcm.size();i+=step)f+=pcm[i]*double((i/step)%97+1);
    return f;
}
bool recallGrid(const Mp3Waveform& song,double fingerprint,BeatGrid& grid) {
    std::lock_guard<std::mutex> lock(gridMemoMutex);
    for(const auto& m:gridMemo)
        if(m.samples && m.samples==song.pcmStereo.size() && m.rate==song.sampleRate && m.fingerprint==fingerprint){
            grid=m.grid;
            return true;
        }
    return false;
}
void rememberGrid(const Mp3Waveform& song,double fingerprint,BeatGrid grid) {
    grid.fromCache=false;
    grid.manual=false;
    std::lock_guard<std::mutex> lock(gridMemoMutex);
    for(auto& m:gridMemo)
        if(m.samples==song.pcmStereo.size() && m.rate==song.sampleRate && m.fingerprint==fingerprint){
            m.grid=grid;
            return;
        }
    if(gridMemo.size()>=8)gridMemo.erase(gridMemo.begin());
    gridMemo.push_back({song.pcmStereo.size(),song.sampleRate,fingerprint,grid});
}
void analyseBeatGrid(Mp3Waveform& song);
}

void rememberAutomaticBeatGrid(const Mp3Waveform& song) {
    if(song.beatGrid.estimated && !song.beatGrid.manual && !song.pcmStereo.empty())
        rememberGrid(song,pcmFingerprint(song.pcmStereo),song.beatGrid);
}

void estimateBeatGrid(Mp3Waveform& song) {
    const double fingerprint=pcmFingerprint(song.pcmStereo);
    if(recallGrid(song,fingerprint,song.beatGrid))return;
    analyseBeatGrid(song);
    if(!song.pcmStereo.empty())rememberGrid(song,fingerprint,song.beatGrid);
}

namespace {
void analyseBeatGrid(Mp3Waveform& song) {
    static const bool legacyOnly=[]{const char* s=std::getenv("DECK001_BEAT_ANALYZER");
        return s && std::string(s)=="legacy";}();
    static const bool trace=[]{const char* s=std::getenv("DECK001_MUSICAL_DIAG");
        return s && s[0]=='1' && s[1]=='\0';}();
    if(!legacyOnly && song.sampleRate>0 && song.pcmStereo.size()>=std::size_t(25.0*song.sampleRate)*2) {
        PulseBeat::Result r;
        // v2.2.118h3: default threads (cores - 1, at most 3, each at nice +10 so a playing deck keeps the
        // CPU); the whole track, or three windows (kPulseAnalysisSeconds / DECK001_PULSE_WINDOW).
        PulseBeat::Options options;
        options.maxSeconds=pulseAnalysisSeconds();
        const auto started=std::chrono::steady_clock::now();
        try {
            r=PulseBeat::analyze(song.pcmStereo.data(),song.pcmStereo.size()/2,2,song.sampleRate,
                                 Settings::kPreferIntegerTempo?0.02:0.0,options);
        } catch(...) { r=PulseBeat::Result{}; }
        const double elapsedMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-started).count();
        // One line per analysed track (not per cache hit), so the Pi's analysis time can be read in the log.
        std::fprintf(stderr,"BEAT GRID pulse %s bpm=%.3f in %.0f ms (%.0f s of %.0f s analysed)\n",
                     r.ok&&r.steady?"ok":"no-steady-grid",r.bpm,elapsedMs,r.analysedSeconds,
                     double(song.pcmStereo.size()/2)/song.sampleRate);
        if(r.ok && r.steady && std::isfinite(r.bpm) && r.bpm>0) {
            double bpm=r.bpm, raw=r.rawBpm, first=r.firstBeatSeconds;
            // The deck's tempo range: fold double / half time into it (a beat stays a beat, a bar line a bar line).
            while(bpm>Settings::kBpmMax){bpm*=0.5;raw*=0.5;}
            while(bpm<Settings::kBpmMin){bpm*=2.0;raw*=2.0;}
            const double bar=4.0*60.0/bpm;
            // The first bar line of the track. A track that starts on beat 1 has it at 0 s give or take a
            // few ms, so a bar line up to 50 ms before 0 counts as that one (not the one a bar later:
            // LOAD and Seamless start an incoming track at firstBeatSeconds, clamped to 0).
            first-=std::floor((first+kBarLineBeforeStart)/bar)*bar;
            // v2.2.131h: no step back below 0 s (BeatGridQuality needs an origin >= 0); the cache allows up to 8 s.
            song.beatGrid={};
            song.beatGrid.bpm=bpm;
            song.beatGrid.rawBpm=raw;
            song.beatGrid.firstBeatSeconds=first;
            // From the share of Pulse's beats that sit on the grid: 0.50 (DECK LINK's "reliable") at the
            // 60 % a steady grid needs, 0.65 (the Seamless / AUTO PILOT gate, beat_grid_quality.h) at 80 %,
            // 1.0 at 100 %. So a grid that a fifth of the beats do not follow still syncs over DECK LINK
            // but is not mixed automatically: 3 of the 194 gridded test tracks. A judgement, not a measured
            // gain: nothing Pulse measures predicts a wrong tempo or a grid tens of ms off (PATCH_NOTE).
            song.beatGrid.confidence=r.onGridShare<0.8
                ?std::clamp(0.50+0.15*(r.onGridShare-0.6)/0.2,0.50,0.65)
                :std::clamp(0.65+0.35*(r.onGridShare-0.8)/0.2,0.65,1.0);
            song.beatGrid.integerTempoSelected=r.integerTempo;
            song.beatGrid.estimated=true;
            song.beatGrid.fromCache=false;
            song.beatGrid.manual=false;
            if(trace)std::fprintf(stderr,
                "BEAT ANALYSIS pulse bpm=%.4f raw=%.4f first=%.5fs (bar line) confidence=%.3f onGrid=%.2f "
                "barShare=%.2f peaks=%d integer=%d parity=%.2f halved=%d\n",bpm,raw,first,song.beatGrid.confidence,
                r.onGridShare,r.barPhaseShare,r.beatPeaks,int(r.integerTempo),r.beatParity,int(r.halved));
            return;
        }
        if(trace)std::fprintf(stderr,"BEAT ANALYSIS pulse: no steady grid (ok=%d onGrid=%.2f peaks=%d), legacy analyser\n",
                              int(r.ok),r.onGridShare,r.beatPeaks);
    }
    estimateBeatGridLegacy(song);
}
}  // namespace
