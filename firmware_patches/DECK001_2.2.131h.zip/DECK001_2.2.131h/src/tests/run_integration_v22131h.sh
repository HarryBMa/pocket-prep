#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
${CXX:-g++} -std=c++17 -O0 -pthread -Wall -Wextra -Wpedantic -DDECK001_ENABLE_DECKSTRETCH -I. -fsyntax-only \
 beat_grid.cpp pulse_beat.cpp stick_beat_grid.cpp beat_grid_cache.cpp mp3_waveform.cpp metadata_store.cpp \
 ui_frame_renderer.cpp ui_scene_composer.cpp ui_wave_scene.cpp interface.cpp \
 ui_settings_controller.cpp user_preferences.cpp deck_application.cpp \
 track_session.cpp track_preparation.cpp player.cpp deck_link.cpp
python3 tools/build_release.py version | grep -Fx '2.2.131'
# v2.2.130's integration gates (its last line checks the version string 2.2.130, so it runs without that line)
sed "/build_release.py version/d" tests/run_integration_v22130.sh > tests/.run_integration_v22130_noversion.sh
sh tests/.run_integration_v22130_noversion.sh; rm -f tests/.run_integration_v22130_noversion.sh
printf 'PASS v2.2.131h INTEGRATION (analyser, stick grid, cache, loader, metadata store, UI + inherited v2.2.130 integration)\n'
