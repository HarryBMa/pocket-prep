# Patch 2.2.131h: Pulse beat grid + prepared grids from the stick, on v2.2.131

Based on: DECK001 v2.2.131 source ZIP. This is patch 2.2.119h (Pulse, stick grids) moved onto v2.2.131,
plus an exact linked tempo for DECK LINK. Apply it alone. New dependencies: none.

**Pulse is still being improved** (retraining for slow tracks / double time). Its files are self-contained and
drop-in: a newer Pulse replaces `pulse_beat.h`, `pulse_beat.cpp`, `pulse_weights.h` and
`tests/fixtures/pulse/*.f32` without touching anything else.

## What it does
- **Pulse** (`pulse_beat.*`, `pulse_weights.h`): small neural beat / downbeat tracker (81 k parameters).
  `estimateBeatGrid()` runs it first; your v2.2.119/120 multi-section analyser (now `estimateBeatGridLegacy`,
  unchanged) runs when Pulse finds no steady tempo, the track is < 25 s, or `DECK001_BEAT_ANALYZER=legacy`.
  `firstBeatSeconds` is the **bar line** (beat 1).
- **Grid from a prepared stick** (`stick_beat_grid.*`, `stick_path_fold.h`): rekordbox / DKPRP exports
  (`PIONEER/rekordbox/export.pdb` -> `ANLZ0000.DAT` PQTZ). Read-only. `DECK001_STICK_GRID=off` ignores them.
- Grid priority: manual grid in the cache > stick > automatic grid in the cache > analysis. Instant GRID RESET.
- Everything else from 2.2.119h (its PATCH_NOTE has the details): exact stick tempo, tempo-change sections,
  double-time fix below ~105 BPM, confidence 0.50 at 60 % / 0.65 at 80 % / 1.0 at 100 % of beats on the grid,
  `DECK001_PULSE_WINDOW`, the 2x faster C++.

## What changed against 2.2.119h, for v2.2.131
1. **Cache format 6** (`beat_grid_cache.cpp`). v2.2.120 already uses 5, so 2.2.119h's 4 would count as old.
   Automatic grids of formats 2-5 are analysed again once; MANUAL grids of any older format are kept (your rule
   since v2.2.120), now with 2.2.119h's second `auto` line.
2. **Grid origin never negative.** v2.2.131's `BeatGridQuality::phaseCandidateUsable` (provisional sync) needs
   `firstBeatSeconds >= 0`. 2.2.119h allowed a bar line up to 50 ms before 0 and moved a stick grid one bar back when
   its bar line was past 3 s. Now: `kBarLineBeforeStart = 0` (the first bar line at or after 0 s) and no step back;
   the cache accepts origins up to 8 s (one bar at 30 BPM). Cost: a track that starts exactly on beat 1 but is
   measured a few ms early gets its anchor one bar later (as in h4); the grid itself is the same.
3. **Exact linked tempo (DECK LINK)** (`player.cpp`, `Player::setLinkedTempoBpm`). It rounded the session BPM to
   0.1. Since v2.2.129 the session reference carries the BPM as a double, and Pulse and stick grids are not whole
   numbers (e.g. 124.37), so a follower ran up to 0.05 BPM off (0.03 BPM = about 14 ms per minute) and the phase servo
   had to chase it. Now the BPM is applied exactly, in the same +-20 % window. Manual tempo steps keep 0.1 BPM. The
   legacy motion packet (`deck_link.cpp`, bpm x 10 for older peers) is unchanged. This is the one change outside the
   beat grid; drop the hunk if you prefer the old behaviour.
4. Test scripts: `tests/run_fast_v22131h.sh` (Pulse, stick, grid sources, DECK LINK + Pulse, cache, then
   `run_fast_v22120.sh` and `run_fast_v22131.sh`), `tests/run_integration_v22131h.sh` (all changed translation
   units, version check `2.2.131`, then v2.2.130's integration gates). `run_fast_v22119.sh` / `run_fast_v22120.sh`
   link `pulse_beat.cpp` (their legacy-analyser tests are unchanged and pass).

## DECK LINK: Pulse between units
- **Same file, same grid on every unit.** Pulse is deterministic: 1 and 3 threads give bit-identical grids, and a
  44.1 kHz and a 48 kHz decode of the same music agree (new test: 124.3696 BPM, same first bar line, on both).
  Both decks need the patch to analyse alike; a unit on stock v2.2.131 keeps its own analyser.
- **Mixed units work as before.** Sync aligns beats (phase within one beat), not bars, so a Pulse unit and a stock
  unit sync normally; only the grids' accuracy differs.
- **Not in this patch: bar alignment across units.** Pulse's anchor is beat 1, and `beatInBar` is already
  published, so DECK LINK could align downbeats (phase modulo the session `quantum` of 4) when both units report a
  bar-line anchor. That needs a capability flag (a stock unit's first beat is any beat) and a change in the
  servo's error wrap. That's your architecture to decide.

## What was verified (Linux x86-64, g++ 13, dependencies from `prepare_dependencies.sh`, SQLite 3.54.1)
- Clean v2.2.131 + `2.2.131h.diff` (+ the two binary fixtures) = the files in `src/`.
- `sh tests/run_fast_v22131h.sh`: every Pulse / stick / grid-source / DECK LINK + Pulse / cache test passes, then
  the v2.2.120 chain (42 PASS lines, through v2.2.113 ... v2.2.120). The script then fails in
  `run_fast_v22131.sh`: the VT-guard test does not compile with g++ 13 (`-Werror`, unused `write()` result in
  `tools/deck_vt_guard_v22131.c:53`). **Clean v2.2.131 fails the same way here**, so it's this compiler, not the
  patch.
- `run_fast_v22125.sh` ... `run_fast_v22130.sh`: PASS. `run_fast_v22121.sh` ... `v22124.sh` fail at the same
  assertions on clean v2.2.131 and on the patched tree (old tests that expect unsynchronised fallback, obsolete
  since v2.2.125 per AGENTS.md).
- `sh tests/run_integration_v22131h.sh`: PASS (includes v2.2.130's integration gates).
- `make all`: `deck001`, `deck001-scanner`, `deck001-metadata` build.

## Not verified
- Not built or run on a Pi; no Pi timing (estimate about 1 s per new track on a Pi 4 with 3 threads).
- Not tested with a real USB stick or two physical decks. DECK LINK with Pulse grids is checked only by the new
  host test (determinism, exact linked tempo) and your existing servo / GRID SYNC tests.
- Not listened to.

## How to try it
1. On the Mac (Pi offline): copy `src/` over a clean v2.2.131 tree (or `patch -p1 < 2.2.131h.diff`, then copy
   `src/tests/fixtures/pulse/*.f32`). Run the two `v22131h` scripts. Build, install on **both** decks.
2. One deck: familiar tracks, BPM, grid on the kicks, bar line on beat 1; compare with
   `DECK001_BEAT_ANALYZER=legacy`. Slow tracks (85-100 BPM) should not be doubled.
3. Two decks over DECK LINK, GRID SYNC ORGANIC: tracks at non-integer tempos (from a rekordbox stick, or Pulse
   grids like 124.37): the follower's `trim` should settle near 0 instead of holding a small constant correction.
4. Send the `BEAT GRID pulse ... in N ms` and `BEAT GRID stick ok ...` lines.
