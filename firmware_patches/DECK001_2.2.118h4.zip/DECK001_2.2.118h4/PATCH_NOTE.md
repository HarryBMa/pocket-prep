# Patch 2.2.118h4: prepared grids from the stick + Pulse beat grid (+ the 2.2.118h sync fix)

Based on: DECK001 v2.2.118 source ZIP. Replaces 2.2.118h2 and h3 (everything in them is here) and includes
2.2.118h unchanged (exact BPM through DECK LINK, `player.cpp` + `deck_link.cpp`). Apply this one alone.

## New in h4: the grid from a prepared stick (no analysis on the deck)
A stick exported by the prep app (DKPRP) or by rekordbox holds every track's beat grid:
`PIONEER/rekordbox/export.pdb` maps the audio file to `PIONEER/USBANLZ/.../ANLZ0000.DAT`, whose PQTZ section lists
every beat (bar position 1-4, time in ms). New `stick_beat_grid.h/.cpp` (read-only, no library) reads it:
- **Where:** `mp3_waveform.cpp` (both cache-miss paths: `loadAudio` and `finishPreparedBeatGrid`) now try the stick
  grid first and run Pulse only when there is none. GRID RESET (`deck_application.cpp`) goes back to the stick
  grid too (via `currentTrackIdentity.path`). The grid is then cached as before.
- **How:** the stick root is the nearest parent folder with `PIONEER/rekordbox/export.pdb`; the track is looked up
  by its path relative to it (case-insensitive, as on FAT / exFAT; UTF-16 names handled). export.pdb is parsed
  once per stick and again only if it changes (size / time).
- **Grid:** one straight line through all PQTZ beats (least squares; rejected if any beat is > 5 ms off it, e.g.
  rekordbox grids with tempo changes: then Pulse analyses the track). Whole BPM within 0.02 snaps like Pulse.
  `firstBeatSeconds` = the bar line from the beats numbered 1. Folded into 60-200 BPM. Confidence 0.95.
- **Log:** `BEAT GRID stick ok bpm=126.000 (600 beats from /PIONEER/USBANLZ/...)`.
- Any problem (no export.pdb, track not in it, missing or damaged ANLZ, damaged PDB) just means "no stick
  grid": the track is analysed as in h3. Nothing is ever written to the stick.
- **Works with rekordbox's own exports too** (checked on rekordcrate's sample rekordbox export: 128.000 and
  120.000 BPM, first downbeat 25 ms, as rekordbox shows them).
- DKPRP writes Pulse grids into PQTZ once its Pulse update is in (separate change in the DKPRP repo), so a
  DKPRP-prepared stick gives the same grid the deck would compute, with 0 s analysis at load.

## From h3 (vs h2)
- **Multi-core analysis:** Pulse's resampler, spectrogram and network run on cores - 1 worker threads (at most
  3; on a Pi 4: 3). Each worker sets itself to nice +10 first, so a deck that is playing keeps the CPU.
  Same results as one thread (checked on all 200 test tracks).
- **Log line per analysed track** (not for cache hits), always on:
  `BEAT GRID pulse ok bpm=124.369 in 539 ms (60 s of 60 s analysed)`. Please send these from the Pi.
- **Window option:** `kPulseAnalysisSeconds` in `beat_grid.cpp` (default 0 = whole track). 180 analyses three
  60-s windows instead: about twice as fast, but the bar line is right on fewer tracks (table in the code).
New dependencies: none (plain C++17, no libraries; ~1.2 MB of weights as a header).

## What changed
1. **New analyser, Pulse** (`pulse_beat.h/.cpp`, `pulse_weights.h`): a small neural beat / downbeat tracker
   (81 k parameters, distilled from the Beat This! research model and fine-tuned on 820 hand-annotated DJ
   tracks), then one straight tempo + phase line through its beats, then the bar line. No tempo range cap
   in the network; the result is folded into the deck's 60-200 BPM range (half / double time).
2. **`beat_grid.cpp`**: `estimateBeatGrid()` runs Pulse on `song.pcmStereo` first. The old analyser
   (unchanged, now `estimateBeatGridLegacy`) runs only when Pulse finds no steady tempo (<60 % of its beats on
   one line), the track is < 25 s, or `DECK001_BEAT_ANALYZER=legacy` is set.
   - `firstBeatSeconds` is now **the bar line (beat 1)**: the first downbeat at or after 0 s (moved back one
     bar if > 3 s, for the cache's +-3 s check).
   - `bpm` is snapped to a whole BPM when Pulse's tempo is within 0.02 BPM of it (phase refitted for the whole
     BPM); `rawBpm` keeps the fitted value.
   - `confidence` = 0.5 + 0.5 x (share of beats on the line - 0.6) / 0.3, so 0.5-1.0 for every Pulse grid
     (>= 0.5 = DECK LINK "reliable").
   - GRID RESET (UI thread) reuses the last 8 Pulse results per decoded track, so it stays instant.
   - `DECK001_MUSICAL_DIAG=1` prints a `BEAT ANALYSIS pulse ...` line.
3. **`beat_grid_cache.cpp`**: cache format 3 -> 4, so automatic grids from older firmware are re-analysed
   once with Pulse. MANUAL grids from v2 and v3 caches are kept (user corrections never lost).
4. **Makefile**: `pulse_beat.cpp` in SOURCES and SEAMLESS_LIVE_SOURCES; `pulse_beat.o` built with
   `-O3 -ffast-math` (about 2.5x faster than -O2; changes logits by < 2e-5).
5. **Tests**: new `tests/run_stick_grid_v22118h4.sh` (builds a small stick with export.pdb + ANLZ files and
   checks the reader: grid, bar line, case-insensitive and UTF-16 paths, tempo-change rejection, 250 -> 125 BPM
   fold, missing / damaged files; then runs the Pulse test). `tests/run_pulse_v22118h2.sh` (name kept from h2) (C++ log-mel and network vs the PyTorch reference, a
   synthetic 128-BPM grid). Test scripts that link `beat_grid.cpp` now also link `pulse_beat.cpp`;
   `test_bpm_cache_migration_v22113.cpp` checks v2 and v3 caches against format 4.

## Results (200 DJ tracks with hand-marked beats, none used in training)
House, techno, trance, drum & bass (Raveform dataset). End to end through the patched `beat_grid.cpp`
(built as a PC tool, same code):

| | v2.2.118 | **2.2.118h3** (= h2) |
|---|---|---|
| Tempo right (not half / double / 3:2) | 158 / 195 (81 %) | **193 / 195 (99 %)** |
| Grid offset from the beats, median | 7.0 ms | **3.2 ms** |
| Grid more than 20 ms off | 32 % of tracks | **16 %** |
| Bar line on the human downbeats | 75 % | **87 %** |
| Tracks with > 90 % of bar lines right | 75 % | **87 %** |
| Grids marked reliable (confidence >= 0.5) | 18 % | 100 % (see note) |

Note on confidence: v2.2.118 marks only 18 % of these grids as reliable, so DECK LINK treats most real tracks
as unreliable today. 2.2.118h3 marks every steady Pulse grid reliable, including the 2 of 195 with a wrong
tempo family. If a stricter gate is wanted, `beatPeaks` / `onGridShare` / `barPhaseShare` in
`PulseBeat::Result` are the inputs to tune it.

Bar line = the share of the human-marked downbeats that the grid's bar line hits (+-70 ms). v2.2.118 makes
no downbeat claim; its first beat is often the first kick, which is often beat 1.

## Speed (and why it matters)
The track load waits for the grid (`TrackPreparation::prepare` joins the beat job), so on the FIRST load of a
track Pulse's time adds to the load, minus what the waveform / contour / transient jobs take in parallel.
Later loads read the cached grid (0 s).

| per 6.5-min track, PC (Ryzen) | time |
|---|---|
| old analyser | 0.15 s |
| Pulse, 1 thread (h2) | 1.74 s |
| **Pulse, 3 threads (h3)** | **0.64 s** |
| Pulse, 3 threads, 3 x 60 s windows | 0.33 s |

A Pi 4 core is roughly 3x slower than this PC's, so expect **about 2 s** on a Pi 4 with h3 (~1 s with
windows). **Not measured: please send the `BEAT GRID pulse` lines.** Next step that removes the wait
entirely: grids made by the prep app (DKPRP) and read from the stick.

## What was verified
- `sh tests/run_fast_v22118.sh` and `sh tests/run_integration_v22118.sh`: all PASS (Linux x86-64, g++).
- `2.2.118h4.diff` applied with `patch -p1` to a clean v2.2.118 tree gives exactly the files in `src/`.
- `sh tests/run_stick_grid_v22118h4.sh`: PASS. End to end on Linux: `loadAudio()` on a WAV inside a stick
  (rekordcrate's sample rekordbox ANLZ, our export.pdb) takes the stick grid with no Pulse run; the second load
  is a cache hit. The same WAV outside a stick runs Pulse.
- `mp3_waveform.cpp`, `deck_application.cpp` compile (`-fsyntax-only` with dr_libs headers).
- `sh tests/run_pulse_v22118h2.sh`: PASS (log-mel max error 4e-4, logits 1e-5 vs PyTorch).
- The results table: the patched `beat_grid.cpp` + `pulse_beat.cpp` (h2) built on Windows (w64devkit g++),
  on decoded real tracks. h3's threaded C++ gives the same results on all 200 tracks (pulse_speed_eval.py).

## Not verified
- Not built as the full firmware on the Pi, not run on the Pi, no Pi timing.
- Not tested on a real USB stick on the Pi, or with a DKPRP export (DKPRP's Pulse update isn't built yet); the
  PDB reader is checked against rekordcrate's sample rekordbox export and our own test writer.
- Not listened to on the decks: grid placement on screen, Seamless / AUTO PILOT, BEAT sync with the new
  bar-line anchor, GRID RESET timing.
- DECK LINK part: same as 2.2.118h (protocol 3; both decks must run it).

## How to try it
1. On the Mac (Pi offline): copy `src/` over a clean v2.2.118 tree (or `patch -p1 < 2.2.118h4.diff`, then copy
   `src/tests/fixtures/pulse/*.f32`, the two binary test fixtures the diff can't carry), run the tests
   above, build, install on both decks.
2. Load tracks you know: BPM, grid lines on the kicks, and the bar line on beat 1 (first kick after a
   breakdown, start of a phrase). Compare with `DECK001_BEAT_ANALYZER=legacy`.
3. Send the `BEAT GRID pulse ... in N ms` lines from the Pi 4 (first load of a few 6-7 min tracks), and say
   whether the extra load time is noticeable.
4. A stick exported by rekordbox (or DKPRP once it has Pulse): load tracks, check for `BEAT GRID stick ok` in the
   log, and that grid and bar line match what rekordbox shows.
