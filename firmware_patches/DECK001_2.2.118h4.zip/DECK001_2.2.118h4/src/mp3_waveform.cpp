#include "mp3_waveform.h"
#include "auto_cue_detector.h"
#include "beat_grid.h"
#include "stick_beat_grid.h"
#include "beat_grid_cache.h"
#include "waveform_cache.h"
#include "settings.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cctype>
#include <filesystem>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>

// Upstream single-header decoders: each implementation in exactly one TU.
#define DR_MP3_IMPLEMENTATION
#include "third_party/dr_mp3.h"
#define DR_WAV_IMPLEMENTATION
#include "third_party/dr_wav.h"
#define DR_FLAC_IMPLEMENTATION
#include "third_party/dr_flac.h"

namespace {
constexpr std::size_t kChunk=4096;
constexpr std::size_t kBytesPerStereoFrame=sizeof(float)*2;
struct AudioReader {
    drmp3 mp3{};
    drwav wav{};
    drflac* flac=nullptr;
    enum class Format { None,Mp3,Wav,Flac } format=Format::None;
    int channels=0, rate=0;
    std::uint64_t estimatedFrames=0;
    explicit AudioReader(const std::string& path) {
      try {
        std::string ext=std::filesystem::path(path).extension().string();
        std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return char(std::tolower(c));});
        if(ext==".mp3") {
            if(!drmp3_init_file(&mp3,path.c_str(),nullptr))throw std::runtime_error("Cannot decode MP3");
            format=Format::Mp3;
            channels=int(mp3.channels);rate=int(mp3.sampleRate);
            // Prefer the already parsed Xing/VBR length. A full MP3 frame-count
            // scan would read the entire USB file twice on every load.
            estimatedFrames=mp3.totalPCMFrameCount==std::numeric_limits<drmp3_uint64>::max()
                ? 0 : mp3.totalPCMFrameCount;
        } else if(ext==".wav") {
            if(!drwav_init_file(&wav,path.c_str(),nullptr))throw std::runtime_error("Cannot decode WAV");
            format=Format::Wav;
            channels=int(wav.channels);rate=int(wav.sampleRate);
            estimatedFrames=wav.totalPCMFrameCount;
            // PCM 16/24 and IEEE-float 32. Reject compressed or unsupported WAV.
            if(!((wav.translatedFormatTag==DR_WAVE_FORMAT_PCM && (wav.bitsPerSample==16 || wav.bitsPerSample==24)) ||
                 (wav.translatedFormatTag==DR_WAVE_FORMAT_IEEE_FLOAT && wav.bitsPerSample==32)))
                throw std::runtime_error("WAV must be PCM16/24 or float32");
        } else if(ext==".flac") {
            flac=drflac_open_file(path.c_str(),nullptr);
            if(!flac)throw std::runtime_error("Cannot decode FLAC");
            format=Format::Flac;
            channels=int(flac->channels);rate=int(flac->sampleRate);
            estimatedFrames=flac->totalPCMFrameCount;
            if(flac->bitsPerSample!=16 && flac->bitsPerSample!=24)
                throw std::runtime_error("FLAC must be 16/24 bit");
        } else throw std::runtime_error("Unsupported audio format");
        if((channels!=1 && channels!=2) || (rate!=44100 && rate!=48000))
            throw std::runtime_error("Only mono/stereo 44.1 or 48 kHz supported");
      } catch(...) {
        close(); // A throwing constructor never invokes ~AudioReader().
        throw;
      }
    }
    ~AudioReader() { close(); }
    void close() noexcept {
        switch(format){
            case Format::Mp3:drmp3_uninit(&mp3);break;
            case Format::Wav:drwav_uninit(&wav);break;
            case Format::Flac:if(flac)drflac_close(flac);break;
            case Format::None:break;
        }
        format=Format::None;
        flac=nullptr;
    }
    AudioReader(const AudioReader&)=delete;
    AudioReader& operator=(const AudioReader&)=delete;
    bool seek(std::uint64_t frame) {
        switch(format){
            case Format::Mp3:return drmp3_seek_to_pcm_frame(&mp3,frame)!=0;
            case Format::Wav:return drwav_seek_to_pcm_frame(&wav,frame)!=0;
            case Format::Flac:return drflac_seek_to_pcm_frame(flac,frame)!=0;
            case Format::None:return false;
        }
        return false;
    }
    std::size_t read(float* samples,std::size_t frames) {
        switch(format){
            case Format::Mp3:return std::size_t(drmp3_read_pcm_frames_f32(&mp3,frames,samples));
            case Format::Wav:return std::size_t(drwav_read_pcm_frames_f32(&wav,frames,samples));
            case Format::Flac:return std::size_t(drflac_read_pcm_frames_f32(flac,frames,samples));
            case Format::None:return 0;
        }
        return 0;
    }
};
float clampedFinite(float x) {return std::isfinite(x)?x:0.0f;}
}
namespace {
Mp3Waveform loadAudioImpl(const std::string& path,std::size_t pcmBudgetBytes,
                          bool deferAnalysis,
                          const std::function<void(DecodeMilestone)>& milestone) {
    AudioReader decoder(path);
    if(milestone)milestone(DecodeMilestone::DecoderOpen);
    bool firstPcmReported=false;
    Mp3Waveform song;
    song.sampleRate=decoder.rate;song.channels=decoder.channels;
    song.framesPerBin=std::max(1,song.sampleRate*Settings::kAnalysisWindowMs/1000);
    const bool cachedWave=loadWaveformCache(path,song);
    song.waveformFromCache=cachedWave;
    const std::size_t maxFrames=std::min<std::size_t>(Settings::kMaxPcmMiB*1024ULL*1024ULL,pcmBudgetBytes)/kBytesPerStereoFrame;
    if(maxFrames==0 || (decoder.estimatedFrames && decoder.estimatedFrames>maxFrames))
        throw std::runtime_error("Decoded audio would exceed available shared PCM budget (long-track streaming deferred)");
    // Reserve exact predicted length where available. Memory admission checks the
    // *resident old track* in main.cpp before this allocation. No 512 MiB preallocation.
    if(decoder.estimatedFrames) song.pcmStereo.reserve(std::size_t(decoder.estimatedFrames)*2);
    std::array<float,kChunk*2> decoded{};
    double squares=0,bassSquares=0,midSquares=0,highSquares=0;
    double lowBass=0,lowMid=0;
    const double bassAlpha=1.0-std::exp(-2.0*3.141592653589793*Settings::kBassCutoffHz/song.sampleRate);
    const double midAlpha=1.0-std::exp(-2.0*3.141592653589793*Settings::kMidCutoffHz/song.sampleRate);
    std::uint32_t samplesInBin=0;
    WaveformBin bin;
    auto finishBin=[&]() {
        if(!samplesInBin)return;
        bin.rms=float(std::sqrt(squares/samplesInBin));
        bin.bass=float(std::sqrt(bassSquares/samplesInBin));
        bin.mids=float(std::sqrt(midSquares/samplesInBin));
        bin.highs=float(std::sqrt(highSquares/samplesInBin));
        const float prior=song.bins.empty()?0.f:song.bins.back().rms;
        bin.attack=std::max(0.0f,bin.rms-prior);
        song.bins.push_back(bin);bin=WaveformBin{};
        squares=bassSquares=midSquares=highSquares=0;samplesInBin=0;
    };
    for(;;){
        const std::size_t frames=decoder.read(decoded.data(),kChunk);
        if(frames==0)break;
        if(!firstPcmReported){firstPcmReported=true;if(milestone)milestone(DecodeMilestone::FirstPcm);}
        if(frames>maxFrames || song.totalFrames>maxFrames-frames)
            throw std::runtime_error("Decoded audio exceeds shared PCM memory budget");
        const auto required=(std::size_t(song.totalFrames)+frames)*2;
        if(required>song.pcmStereo.capacity()){
            // Bounded incremental growth for unknown duration sources. Avoid
            // allocating beyond admitted PCM budget, including old capacity.
            const auto maxSamples=maxFrames*2;
            const auto next=std::min(maxSamples,std::max(required,
                song.pcmStereo.capacity()+std::max<std::size_t>(2*1024*1024/sizeof(float),song.pcmStereo.capacity()/4)));
            song.pcmStereo.reserve(next);
        }
        for(std::size_t i=0;i<frames;++i){
            const float left=clampedFinite(decoded[i*decoder.channels]);
            const float right=decoder.channels==2?clampedFinite(decoded[i*2+1]):left;
            if(std::abs(left)>=0.999f)++song.nearFullScaleSamples;
            if(std::abs(right)>=0.999f)++song.nearFullScaleSamples;
            song.pcmStereo.push_back(left);song.pcmStereo.push_back(right);
            if(cachedWave)continue;
            const auto l16=std::int16_t(std::lrint(std::clamp(left*32768.f,-32768.f,32767.f)));
            const auto r16=std::int16_t(std::lrint(std::clamp(right*32768.f,-32768.f,32767.f)));
            bin.minimum=std::min(bin.minimum,std::min(l16,r16));
            bin.maximum=std::max(bin.maximum,std::max(l16,r16));
            const double l=left,r=right;
            squares+=(l*l+r*r)*0.5;
            const double mono=0.5*(l+r);
            lowBass+=bassAlpha*(mono-lowBass);lowMid+=midAlpha*(mono-lowMid);
            const double midBand=lowMid-lowBass,highBand=mono-lowMid;
            bassSquares+=lowBass*lowBass;midSquares+=midBand*midBand;highSquares+=highBand*highBand;
            if(++samplesInBin>=song.framesPerBin)finishBin();
        }
        song.totalFrames+=frames;
    }
    if(!cachedWave)finishBin();
    if(milestone)milestone(DecodeMilestone::PcmReady);
    if(decoder.format!=AudioReader::Format::Mp3 && decoder.estimatedFrames &&
       song.totalFrames!=decoder.estimatedFrames)
        throw std::runtime_error("Truncated audio file; current track remains loaded");
    if(!song.totalFrames || song.bins.empty())throw std::runtime_error("Empty or corrupt audio file");
    if(!cachedWave){
        std::vector<float> levels;levels.reserve(song.bins.size());
        for(const auto& item:song.bins)levels.push_back(item.rms);
        auto nth=levels.begin()+std::ptrdiff_t(levels.size()*95/100);
        std::nth_element(levels.begin(),nth,levels.end());
        song.referenceRms=std::max(.02,double(*nth));
        auto percentile=[&](float WaveformBin::*field){
            std::vector<float> v;v.reserve(song.bins.size());
            for(const auto& b:song.bins)v.push_back(b.*field);
            auto it=v.begin()+std::ptrdiff_t(v.size()*95/100);
            std::nth_element(v.begin(),it,v.end());return std::max(.005,double(*it));
        };
        song.referenceBass=percentile(&WaveformBin::bass);
        song.referenceMids=percentile(&WaveformBin::mids);
        song.referenceHighs=percentile(&WaveformBin::highs);
        song.autoCueFrame=AutoCueDetection::detect(song);
        song.autoCueAnalyzed=true;
        song.waveformCacheNeedsWrite=true;
        if(!deferAnalysis)saveWaveformCache(path,song);
    }
    if(!song.autoCueAnalyzed) {
        song.autoCueFrame=AutoCueDetection::detect(song);
        song.autoCueAnalyzed=true;
        song.waveformCacheNeedsWrite=true;
        if(!deferAnalysis)saveWaveformCache(path,song);
    }
    if(song.autoCueFrame>=song.totalFrames) song.autoCueFrame=0;
    if(!loadBeatGridCache(path,song.beatGrid) && !deferAnalysis){
        // v2.2.118h4: a grid prepared on the stick (DKPRP / rekordbox export) first, analysis only without one
        if(!loadStickBeatGrid(path,song.beatGrid))estimateBeatGrid(song);
        if(song.beatGrid.estimated)saveBeatGridCache(path,song.beatGrid);
    }
    return song;
}
} // namespace
Mp3Waveform loadAudio(const std::string& path,std::size_t budget) {
    return loadAudioImpl(path,budget,false,{});
}
Mp3Waveform loadAudioForPreparation(const std::string& path,std::size_t budget,
                                  const std::function<void(DecodeMilestone)>& milestone) {
    return loadAudioImpl(path,budget,true,milestone);
}
void finishPreparedBeatGrid(Mp3Waveform& song,const std::string& path) {
    if(song.beatGrid.estimated)return;
    // Cache may have appeared since initial preparation (e.g., concurrent reload).
    if(!loadBeatGridCache(path,song.beatGrid)) {
        if(!loadStickBeatGrid(path,song.beatGrid))estimateBeatGrid(song);   // v2.2.118h4: prepared grid first
        if(song.beatGrid.estimated)saveBeatGridCache(path,song.beatGrid);
    }
}
AudioWindowInfo probeAudioWindow(const std::string& path) {
    AudioReader r(path);
    return {r.rate,r.channels,r.estimatedFrames};
}
std::size_t decodeAudioWindow(const std::string& path,std::uint64_t firstFrame,
                              float* stereo,std::size_t frames) {
    if(!stereo || !frames)return 0;
    AudioReader decoder(path);
    if(!decoder.seek(firstFrame))throw std::runtime_error("Decoder cannot seek to requested frame");
    constexpr std::size_t kRead=4096;
    std::array<float,kRead*2> decoded{};
    std::size_t output=0;
    while(output<frames){
        const auto count=decoder.read(decoded.data(),std::min(kRead,frames-output));
        if(!count)break;
        for(std::size_t i=0;i<count;++i){
            const float l=clampedFinite(decoded[i*decoder.channels]);
            const float r=decoder.channels==2?clampedFinite(decoded[i*2+1]):l;
            stereo[(output+i)*2]=l;
            stereo[(output+i)*2+1]=r;
        }
        output+=count;
    }
    return output;
}
Mp3Waveform loadMp3(const std::string& path){return loadAudio(path,Settings::kMaxPcmMiB*1024ULL*1024ULL);}
