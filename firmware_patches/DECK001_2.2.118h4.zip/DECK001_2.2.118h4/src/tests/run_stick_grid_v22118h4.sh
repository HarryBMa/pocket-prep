#!/bin/sh
# v2.2.118h4: beat grid from a prepared stick (export.pdb + ANLZ PQTZ), plus the Pulse test.
set -eu
cd "$(dirname "$0")/.."
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT HUP INT TERM
${CXX:-g++} -std=c++17 -O2 -Wall -Wextra -Wpedantic -I. \
    tests/test_stick_grid_v22118h4.cpp stick_beat_grid.cpp -o "$tmp/stick"
"$tmp/stick"
sh tests/run_pulse_v22118h2.sh
printf 'PASS v2.2.118h4 STICK GRID + PULSE\n'
