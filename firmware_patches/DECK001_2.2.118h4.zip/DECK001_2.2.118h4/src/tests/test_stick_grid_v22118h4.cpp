// v2.2.118h4: beat grid read from a prepared stick (export.pdb + ANLZ PQTZ). Builds a small stick in a temp
// folder with its own minimal writer (same layout as rekordbox / DKPRP exports) and checks the reader.
#include "../mp3_waveform.h"
#include "../stick_beat_grid.h"
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <string>
#include <vector>
namespace fs = std::filesystem;
using Bytes = std::vector<unsigned char>;

static void le16(Bytes& d, std::size_t o, unsigned v) { d[o] = v & 0xFF; d[o + 1] = (v >> 8) & 0xFF; }
static void le32(Bytes& d, std::size_t o, std::uint32_t v) { for (int i = 0; i < 4; ++i) d[o + i] = (v >> (8 * i)) & 0xFF; }
static void be16(Bytes& d, unsigned v) { d.push_back((v >> 8) & 0xFF); d.push_back(v & 0xFF); }
static void be32(Bytes& d, std::uint32_t v) { for (int i = 3; i >= 0; --i) d.push_back((v >> (8 * i)) & 0xFF); }

static Bytes shortAscii(const std::string& s) { Bytes b{(unsigned char)(((s.size() + 1) << 1) | 1)}; b.insert(b.end(), s.begin(), s.end()); return b; }
static Bytes utf16(const std::u16string& s) {
    Bytes b{0x90, 0, 0, 0};
    for (char16_t c : s) { b.push_back(c & 0xFF); b.push_back(c >> 8); }
    le16(b, 1, unsigned(b.size()));
    return b;
}

static Bytes trackRow(const Bytes& anlz, const Bytes& file) {
    Bytes r(0x5E + 42, 0);
    le16(r, 0, 0x24);
    const Bytes empty = shortAscii("");
    std::vector<std::size_t> at(21);
    for (int i = 0; i < 21; ++i) {
        at[i] = r.size();
        const Bytes& s = i == 14 ? anlz : i == 20 ? file : empty;
        r.insert(r.end(), s.begin(), s.end());
        le16(r, 0x5E + 2 * i, unsigned(at[i]));
    }
    return r;
}

static void writePdb(const fs::path& p, const std::vector<Bytes>& rows) {
    const std::size_t ps = 4096;
    Bytes d(3 * ps, 0);
    le32(d, 4, ps); le32(d, 8, 1); le32(d, 12, 3); le32(d, 20, 1);
    le32(d, 0x1C, 0); le32(d, 0x20, 0); le32(d, 0x24, 1); le32(d, 0x28, 2);              // tracks: pages 1..2
    le32(d, ps + 4, 1); le32(d, ps + 12, 2); d[ps + 0x1B] = 0x64;                       // index page
    const std::size_t b = 2 * ps;
    le32(d, b + 4, 2); le32(d, b + 12, 3);
    const std::uint32_t counts = std::uint32_t(rows.size()) | std::uint32_t(rows.size()) << 13;
    d[b + 0x18] = counts & 0xFF; d[b + 0x19] = (counts >> 8) & 0xFF; d[b + 0x1A] = (counts >> 16) & 0xFF;
    d[b + 0x1B] = 0x34;
    std::size_t heap = 0;
    unsigned present = 0;
    for (std::size_t r = 0; r < rows.size(); ++r) {
        std::copy(rows[r].begin(), rows[r].end(), d.begin() + std::ptrdiff_t(b + 0x28 + heap));
        le16(d, b + ps - 0x24 + 2 * (15 - r), unsigned(heap));                         // row r -> offsets[15 - r]
        present |= 1u << r;
        heap += (rows[r].size() + 3) & ~std::size_t(3);
    }
    le16(d, b + ps - 4, present);
    fs::create_directories(p.parent_path());
    std::ofstream(p, std::ios::binary).write(reinterpret_cast<const char*>(d.data()), std::streamsize(d.size()));
}

static void writeAnlz(const fs::path& p, const std::vector<StickBeatGrid::Beat>& beats) {
    Bytes s;
    s.insert(s.end(), {'P', 'Q', 'T', 'Z'});
    be32(s, 24); be32(s, std::uint32_t(24 + 8 * beats.size())); be32(s, 0); be32(s, 0x80000); be32(s, std::uint32_t(beats.size()));
    for (const auto& x : beats) { be16(s, unsigned(x.number)); be16(s, 12600); be32(s, std::uint32_t(std::lround(x.ms))); }
    Bytes f{'P', 'M', 'A', 'I'};
    be32(f, 28); be32(f, std::uint32_t(28 + s.size()));
    f.resize(28, 0);
    f.insert(f.end(), s.begin(), s.end());
    fs::create_directories(p.parent_path());
    std::ofstream(p, std::ios::binary).write(reinterpret_cast<const char*>(f.data()), std::streamsize(f.size()));
}

static std::vector<StickBeatGrid::Beat> beatsAt(double bpm, double t0, int n, int downIndex) {
    std::vector<StickBeatGrid::Beat> b;
    for (int i = 0; i < n; ++i) b.push_back({((i - downIndex) % 4 + 4) % 4 + 1, std::round((t0 + i * 60.0 / bpm) * 1000.0)});
    return b;
}

int main() {
    const fs::path root = fs::temp_directory_path() / "deck001-v22118h4-stick";
    fs::remove_all(root);
    const fs::path pdb = root / "PIONEER" / "rekordbox" / "export.pdb";
    writePdb(pdb, {trackRow(shortAscii("/PIONEER/USBANLZ/P001/00000001/ANLZ0000.DAT"), shortAscii("/Contents/Artist/Track One.mp3")),
                   trackRow(shortAscii("/PIONEER/USBANLZ/P001/00000002/ANLZ0000.DAT"), utf16(u"/Contents/Ångest/Spår Två.flac")),
                   trackRow(shortAscii("/PIONEER/USBANLZ/P001/00000003/ANLZ0000.DAT"), shortAscii("/Contents/Artist/Drift.mp3")),
                   trackRow(shortAscii("/PIONEER/USBANLZ/P001/00000004/ANLZ0000.DAT"), shortAscii("/Contents/Artist/Fast.mp3"))});
    writeAnlz(root / "PIONEER/USBANLZ/P001/00000001/ANLZ0000.DAT", beatsAt(126.0, 0.123, 600, 2));   // beat 1 = beat #2
    writeAnlz(root / "PIONEER/USBANLZ/P001/00000002/ANLZ0000.DAT", beatsAt(123.456, 0.400, 500, 0));
    auto drift = beatsAt(120.0, 0.05, 200, 0);                                                     // tempo change
    for (const auto& b : beatsAt(124.0, drift.back().ms / 1000.0 + 60.0 / 124.0, 200, 0)) drift.push_back(b);
    writeAnlz(root / "PIONEER/USBANLZ/P001/00000003/ANLZ0000.DAT", drift);
    writeAnlz(root / "PIONEER/USBANLZ/P001/00000004/ANLZ0000.DAT", beatsAt(250.0, 0.010, 800, 1));

    BeatGrid g;
    // 1. straight 126 BPM grid; bar line on the beat numbered 1; path case-insensitive (FAT / exFAT)
    assert(loadStickBeatGrid((root / "contents/ARTIST/track one.MP3").string(), g));
    const double p126 = 60.0 / 126.0, bar126 = 4 * p126;
    const double expect = std::fmod(0.123 + 2 * p126, bar126);
    std::printf("126: bpm=%.4f raw=%.4f first=%.4f (expect %.4f) snapped=%d\n", g.bpm, g.rawBpm, g.firstBeatSeconds, expect, g.integerTempoSelected);
    assert(g.bpm == 126.0 && g.integerTempoSelected && std::abs(g.firstBeatSeconds - expect) < 0.002);
    assert(g.estimated && !g.manual && !g.fromCache && g.confidence >= 0.5);
    // 2. UTF-16 path, decimal tempo kept
    assert(loadStickBeatGrid((root / u8"Contents/Ångest/Spår Två.flac").string(), g));
    std::printf("123.456: bpm=%.4f first=%.4f\n", g.bpm, g.firstBeatSeconds);
    assert(std::abs(g.bpm - 123.456) < 0.002 && !g.integerTempoSelected && std::abs(g.firstBeatSeconds - 0.400) < 0.002);
    // 3. tempo change: not a straight grid -> false (the deck analyses the track)
    assert(!loadStickBeatGrid((root / "Contents/Artist/Drift.mp3").string(), g));
    // 4. 250 BPM folds into the deck's range; the bar line stays on a beat numbered 1
    assert(loadStickBeatGrid((root / "Contents/Artist/Fast.mp3").string(), g));
    std::printf("250 -> bpm=%.3f first=%.4f\n", g.bpm, g.firstBeatSeconds);
    assert(g.bpm == 125.0 && std::abs(std::remainder(g.firstBeatSeconds - (0.010 + 60.0 / 250.0), 60.0 / 250.0)) < 0.002);
    // 5. not in the export, outside any stick, missing ANLZ, damaged ANLZ
    assert(!loadStickBeatGrid((root / "Contents/Artist/Other.mp3").string(), g));
    assert(!loadStickBeatGrid("/nonexistent/deck001/x.mp3", g));
    fs::remove(root / "PIONEER/USBANLZ/P001/00000002/ANLZ0000.DAT");
    assert(!loadStickBeatGrid((root / u8"Contents/Ångest/Spår Två.flac").string(), g));
    std::ofstream(root / "PIONEER/USBANLZ/P001/00000001/ANLZ0000.DAT", std::ios::binary | std::ios::trunc) << "PMAI garbage";
    assert(!loadStickBeatGrid((root / "Contents/Artist/Track One.mp3").string(), g));
    // 6. damaged export.pdb: no crash, no grid
    std::ofstream(pdb, std::ios::binary | std::ios::trunc) << std::string(5000, '\xff');
    assert(!loadStickBeatGrid((root / "Contents/Artist/Fast.mp3").string(), g));
    fs::remove_all(root);
    std::printf("PASS v2.2.118h4 stick beat grid (export.pdb + PQTZ, case-insensitive paths, UTF-16, tempo change, fold, damaged files)\n");
}
