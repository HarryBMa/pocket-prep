// v2.2.118h4: beat grid from a prepared stick. See stick_beat_grid.h.
// Formats (rekordbox USB export, as documented by Deep Symmetry's crate-digger and rekordcrate):
//  export.pdb  little-endian. File header: u32 0, u32 page size, u32 table count, ..., table pointers from
//              0x1C (16 bytes each: u32 type, u32 -, u32 first page, u32 last page). Table type 0 = tracks.
//              Page: 0x28-byte header (u32 next page at 0x0C; 24-bit row counts at 0x18: 13 bits row
//              slots, 11 bits valid rows; flags at 0x1B, bit 0x40 = index page), rows on the heap from 0x28,
//              row groups of 16 from the page end backwards: [16 x u16 offsets][u16 present bits][u16];
//              row r of a group is offsets[15 - r] and present bit r.
//              Track row: u16 subtype, ..., 21 u16 string offsets at 0x5E (relative to the row);
//              string 14 = ANLZ path, 20 = file path. DeviceSQL strings: short ASCII ((len+1)<<1 | 1, bytes),
//              long ASCII (0x40, u16 total length, pad), UTF-16LE (0x90, u16 total length, pad).
//  ANLZ0000.DAT big-endian. "PMAI", u32 header length, u32 file length, then sections: 4-char tag,
//              u32 header length, u32 section length. PQTZ: header 24 bytes ending in u32 beat count;
//              beats of 8 bytes: u16 bar position (1-4), u16 tempo x 100, u32 time in ms.
#include "stick_beat_grid.h"
#include "mp3_waveform.h"
#include "settings.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <map>
#include <mutex>

namespace {
namespace fs = std::filesystem;

std::vector<unsigned char> readFile(const fs::path& p, std::size_t maxBytes) {
    std::error_code ec;
    const auto size = fs::file_size(p, ec);
    if (ec || size == 0 || size > maxBytes) return {};
    std::ifstream f(p, std::ios::binary);
    std::vector<unsigned char> d(size);
    if (!f.read(reinterpret_cast<char*>(d.data()), std::streamsize(size))) return {};
    return d;
}

std::uint32_t le32(const std::vector<unsigned char>& d, std::size_t o) {
    return o + 4 <= d.size() ? std::uint32_t(d[o]) | std::uint32_t(d[o + 1]) << 8 | std::uint32_t(d[o + 2]) << 16 |
                                   std::uint32_t(d[o + 3]) << 24 : 0;
}
std::uint16_t le16(const std::vector<unsigned char>& d, std::size_t o) {
    return o + 2 <= d.size() ? std::uint16_t(d[o] | d[o + 1] << 8) : 0;
}
std::uint32_t be32(const std::vector<unsigned char>& d, std::size_t o) {
    return o + 4 <= d.size() ? std::uint32_t(d[o]) << 24 | std::uint32_t(d[o + 1]) << 16 | std::uint32_t(d[o + 2]) << 8 |
                                   std::uint32_t(d[o + 3]) : 0;
}
std::uint16_t be16(const std::vector<unsigned char>& d, std::size_t o) {
    return o + 2 <= d.size() ? std::uint16_t(d[o] << 8 | d[o + 1]) : 0;
}

void putUtf8(std::string& s, std::uint32_t c) {
    if (c < 0x80) s += char(c);
    else if (c < 0x800) { s += char(0xC0 | c >> 6); s += char(0x80 | (c & 0x3F)); }
    else if (c < 0x10000) { s += char(0xE0 | c >> 12); s += char(0x80 | ((c >> 6) & 0x3F)); s += char(0x80 | (c & 0x3F)); }
    else { s += char(0xF0 | c >> 18); s += char(0x80 | ((c >> 12) & 0x3F)); s += char(0x80 | ((c >> 6) & 0x3F)); s += char(0x80 | (c & 0x3F)); }
}

// DeviceSQL string at absolute offset o (bounded by end); "" if malformed
std::string deviceSqlString(const std::vector<unsigned char>& d, std::size_t o, std::size_t end) {
    if (o >= end) return {};
    const unsigned kind = d[o];
    std::string s;
    if (kind & 1) {                                                  // short ASCII
        const std::size_t n = (kind >> 1) ? (kind >> 1) - 1 : 0;
        if (o + 1 + n > end) return {};
        s.assign(d.begin() + std::ptrdiff_t(o + 1), d.begin() + std::ptrdiff_t(o + 1 + n));
    } else if (kind == 0x40 || kind == 0x90) {
        const std::size_t total = le16(d, o + 1);
        if (total < 4 || o + total > end) return {};
        if (kind == 0x40) {
            s.assign(d.begin() + std::ptrdiff_t(o + 4), d.begin() + std::ptrdiff_t(o + total));
        } else {                                                     // UTF-16LE -> UTF-8
            for (std::size_t i = o + 4; i + 1 < o + total; i += 2) {
                std::uint32_t c = le16(d, i);
                if (c >= 0xD800 && c < 0xDC00 && i + 3 < o + total) {
                    const std::uint32_t lo = le16(d, i + 2);
                    if (lo >= 0xDC00 && lo < 0xE000) { c = 0x10000 + ((c - 0xD800) << 10) + (lo - 0xDC00); i += 2; }
                }
                putUtf8(s, c);
            }
        }
    }
    return s;
}

std::string normalise(std::string p) {                               // FAT / exFAT: case-insensitive, '/' only
    for (auto& c : p) {
        if (c == '\\') c = '/';
        else if (c >= 'A' && c <= 'Z') c = char(c - 'A' + 'a');
    }
    if (p.empty() || p[0] != '/') p.insert(p.begin(), '/');
    return p;
}

// track path -> ANLZ path, for one export.pdb
std::map<std::string, std::string> parseTracks(const std::vector<unsigned char>& d) {
    std::map<std::string, std::string> out;
    const std::uint32_t pageSize = le32(d, 4), tables = le32(d, 8);
    if (pageSize < 512 || pageSize > 65536 || tables == 0 || tables > 64) return out;
    for (std::uint32_t t = 0; t < tables; ++t) {
        const std::size_t tp = 0x1C + std::size_t(t) * 16;
        if (le32(d, tp) != 0) continue;                              // 0 = tracks
        std::uint32_t page = le32(d, tp + 8);
        const std::uint32_t last = le32(d, tp + 12);
        for (int guard = 0; guard < 100000; ++guard) {
            const std::size_t base = std::size_t(page) * pageSize;
            if (base + pageSize > d.size()) break;
            const std::uint32_t counts = std::uint32_t(d[base + 0x18]) | std::uint32_t(d[base + 0x19]) << 8 |
                                         std::uint32_t(d[base + 0x1A]) << 16;
            const unsigned slots = counts & 0x1FFF;
            const bool indexPage = d[base + 0x1B] & 0x40;
            if (!indexPage && slots) {
                const std::size_t heapEnd = base + pageSize;
                for (unsigned g = 0; g < (slots + 15) / 16; ++g) {
                    const std::size_t end = base + pageSize - std::size_t(g) * 0x24;
                    if (end < base + 0x28 + 0x24) break;
                    const std::uint16_t present = le16(d, end - 4);
                    for (unsigned r = 0; r < 16; ++r) {
                        if (!(present >> r & 1)) continue;
                        const std::size_t row = base + 0x28 + le16(d, end - 0x24 + 2 * (15 - r));
                        if (row + 0x5E + 42 > heapEnd) continue;
                        const std::uint16_t subtype = le16(d, row);
                        if (!(subtype & 0x04)) continue;             // track rows use 16-bit string offsets
                        const std::string anlz = deviceSqlString(d, row + le16(d, row + 0x5E + 2 * 14), heapEnd);
                        const std::string file = deviceSqlString(d, row + le16(d, row + 0x5E + 2 * 20), heapEnd);
                        if (!anlz.empty() && !file.empty()) out[normalise(file)] = anlz;
                    }
                }
            }
            if (page == last) break;
            const std::uint32_t next = le32(d, base + 0x0C);
            if (next == page || next == 0) break;
            page = next;
        }
    }
    return out;
}

struct PdbIndex { std::uintmax_t size = 0; fs::file_time_type time{}; std::map<std::string, std::string> tracks; };
std::mutex indexMutex;
std::map<std::string, PdbIndex> indexes;                             // per export.pdb path

}  // namespace

namespace StickBeatGrid {

std::string anlzPathFor(const std::string& pdbFile, const std::string& trackPath) {
    std::error_code ec;
    const auto size = fs::file_size(pdbFile, ec);
    if (ec) return {};
    const auto time = fs::last_write_time(pdbFile, ec);
    if (ec) return {};
    std::lock_guard<std::mutex> lock(indexMutex);
    auto& ix = indexes[pdbFile];
    if (ix.size != size || ix.time != time) {                         // parse once per stick (and on change)
        ix.tracks = parseTracks(readFile(pdbFile, 256u << 20));
        ix.size = size;
        ix.time = time;
    }
    const auto it = ix.tracks.find(normalise(trackPath));
    return it == ix.tracks.end() ? std::string() : it->second;
}

bool readPqtz(const std::string& anlzFile, std::vector<Beat>& beats) {
    beats.clear();
    const auto d = readFile(anlzFile, 64u << 20);
    if (d.size() < 12 || d[0] != 'P' || d[1] != 'M' || d[2] != 'A' || d[3] != 'I') return false;
    std::size_t p = be32(d, 4);
    while (p + 12 <= d.size()) {
        const std::uint32_t headerLen = be32(d, p + 4), sectionLen = be32(d, p + 8);
        if (sectionLen < 12 || p + sectionLen > d.size()) return false;
        if (d[p] == 'P' && d[p + 1] == 'Q' && d[p + 2] == 'T' && d[p + 3] == 'Z' && headerLen >= 24) {
            const std::uint32_t n = be32(d, p + 20);
            if (headerLen + std::size_t(n) * 8 > sectionLen) return false;
            beats.reserve(n);
            for (std::uint32_t i = 0; i < n; ++i) {
                const std::size_t b = p + headerLen + std::size_t(i) * 8;
                beats.push_back({be16(d, b), double(be32(d, b + 4))});
            }
            return !beats.empty();
        }
        p += sectionLen;
    }
    return false;
}

bool gridFromBeats(const std::vector<Beat>& beats, BeatGrid& grid) {
    const std::size_t n = beats.size();
    if (n < 16) return false;
    // least-squares line t_ms = a + i * period through all beats
    double mi = 0, mt = 0;
    for (std::size_t i = 0; i < n; ++i) { mi += double(i); mt += beats[i].ms; }
    mi /= double(n);
    mt /= double(n);
    double sxy = 0, sxx = 0;
    for (std::size_t i = 0; i < n; ++i) { sxy += (double(i) - mi) * (beats[i].ms - mt); sxx += (double(i) - mi) * (double(i) - mi); }
    double period = sxy / sxx;
    if (!(period > 100.0 && period < 2000.0)) return false;           // 30-600 BPM
    double a = mt - period * mi;
    double worst = 0;
    for (std::size_t i = 0; i < n; ++i) worst = std::max(worst, std::abs(beats[i].ms - (a + period * double(i))));
    if (worst > 5.0) return false;     // not one straight tempo (a rekordbox grid with tempo changes): analyse instead
    const double raw = 60000.0 / period;
    double bpm = raw;
    bool snapped = false;
    if (Settings::kPreferIntegerTempo && std::abs(std::round(raw) - raw) <= 0.02) {
        bpm = std::round(raw);
        period = 60000.0 / bpm;
        a = 0;
        for (std::size_t i = 0; i < n; ++i) a += beats[i].ms - period * double(i);
        a /= double(n);
        snapped = true;
    }
    // bar line: the bar position the beats numbered 1 vote for
    int votes[4] = {0, 0, 0, 0};
    for (std::size_t i = 0; i < n; ++i) if (beats[i].number == 1) ++votes[i % 4];
    const int pos = int(std::max_element(votes, votes + 4) - votes);
    double raw2 = raw, beatMs = period;
    while (bpm > Settings::kBpmMax) { bpm *= 0.5; raw2 *= 0.5; beatMs *= 2; }   // into the deck's tempo range
    while (bpm < Settings::kBpmMin) { bpm *= 2.0; raw2 *= 2.0; beatMs *= 0.5; }
    const double bar = 4.0 * beatMs / 1000.0;
    double first = (a + period * pos) / 1000.0;                       // a downbeat
    first -= std::floor(first / bar) * bar;                           // the first bar line at or after 0 s ...
    if (first > 3.0) first -= bar;                                    // ... within the grid cache's +-3 s
    grid = BeatGrid{};
    grid.bpm = bpm;
    grid.rawBpm = raw2;
    grid.firstBeatSeconds = first;
    grid.confidence = 0.95;                                           // prepared grid: reliable
    grid.integerTempoSelected = snapped;
    grid.estimated = true;
    grid.fromCache = false;
    grid.manual = false;
    return true;
}

}  // namespace StickBeatGrid

bool loadStickBeatGrid(const std::string& audioPath, BeatGrid& grid) {
    try {
        std::error_code ec;
        const fs::path audio = fs::absolute(fs::path(audioPath), ec).lexically_normal();
        if (ec) return false;
        fs::path root;
        for (fs::path dir = audio.parent_path(); !dir.empty(); dir = dir.parent_path()) {
            if (fs::exists(dir / "PIONEER" / "rekordbox" / "export.pdb", ec)) { root = dir; break; }
            if (dir == dir.parent_path()) break;
        }
        if (root.empty()) return false;
        const std::string rel = "/" + audio.lexically_relative(root).generic_string();
        const std::string anlz = StickBeatGrid::anlzPathFor((root / "PIONEER" / "rekordbox" / "export.pdb").string(), rel);
        if (anlz.empty()) return false;
        std::vector<StickBeatGrid::Beat> beats;
        const fs::path anlzFile = root / fs::path(anlz).relative_path();
        if (!StickBeatGrid::readPqtz(anlzFile.string(), beats)) return false;
        BeatGrid g;
        if (!StickBeatGrid::gridFromBeats(beats, g)) {
            std::fprintf(stderr, "BEAT GRID stick: %s has no straight grid, analysing\n", anlz.c_str());
            return false;
        }
        grid = g;
        std::fprintf(stderr, "BEAT GRID stick ok bpm=%.3f (%zu beats from %s)\n", grid.bpm, beats.size(), anlz.c_str());
        return true;
    } catch (...) {
        return false;
    }
}
