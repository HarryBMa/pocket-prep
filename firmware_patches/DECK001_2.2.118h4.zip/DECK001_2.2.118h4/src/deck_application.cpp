#include "deck_application.h"
#include "deck_link_worker.h"
#include "deck_link_runtime.h"
#include "deck_link_update_ui.h"
#include "deck_update_approval.h"
#include "dev_source_mode.h"
#include "updater/pair_ui.h"
#include "deck_boot_readiness.h"
#include "audio_library.h"
#include "audio_cache_budget.h"
#include "track_load_lifecycle.h"
#include "track_preparation.h"
#include "track_session.h"
#include "library_ipc.h"
#include "scanner_runtime.h"
#include "beat_grid.h"
#include "stick_beat_grid.h"
#include "beat_heart.h"
#include "beat_grid_cache.h"
#include "display_fb.h"
#include "display_kms.h"
#include "i2c_encoder.h"
#include "modulino_controls.h"
#include "modulino_leds.h"
#include "neokey_leds.h"
#include "neokey_mode_controls.h"
#include "ui_led_controller.h"
#include "i2c_bus.h"
#include "graphics.h"
#include "wave_tiles.h"
#include "contour_waveform.h"
#include "grid_editor.h"
#include "grid_zoom_anchor.h"
#include "interface.h"
#include "deck_controller.h"
#include "cue_pad_controller.h"
#include "ui_settings_controller.h"
#include "ui_key_shift.h"
#include "browser_controller.h"
#include "loop_wave_camera.h"
#include "cues_storage.h"
#include "cues_ui.h"
#include "usb_indicator.h"
#include "mp3_waveform.h"
#include "player.h"
#include "seamless_live_engine.h"
#include "seamless_toggle_policy.h"
#include "seamless_wave_visual.h"
#include "settings.h"
#include "touch_input.h"
#include "browser_row_action.h"
#include "touch_routing.h"
#include "waveform_scrub_mapping.h"
#include "ui_scrub_display_clock.h"
#include "ui_beat_clock.h"
#include "ui_sync_presentation.h"
#include "vinyl_scrub.h"
#include "live_cues_touch.h"
#include "fx_overlay.h"
#include "fx_types.h"
#include "visual_motion_clock.h"
#if defined(DECK001_B12_TRACE)
#include "b12_visual_trace.h"
#endif
#include "loop_selection.h"
#include "live_loop_grid.h"
#include "app_view_helpers.h"
#include "app_performance_mode.h"
#include "encoder_focus.h"
#include "app_source_identity.h"
#include "app_browser_status.h"
#include "performance_encoder_direction.h"
#include "backlight_control.h"
#include "navigation_colors.h"
#include "track_metadata.h"
#include "deck_command.h"
#include "ui_command_router.h"
#include "midi_input.h"
#include "memory_diagnostics.h"
#include "debug_hud.h"
#include "ui_performance_monitor.h"
#include "user_preferences.h"
#include "auto_pilot_controller.h"
#include "app_view_state.h"
#include "ui_boot_screen.h"
#include "ui_frame_renderer.h"
#include "ui_scene_composer.h"
#include "multitrack_layout.h"
#include "deferred_retirement_queue.h"
#include "ui_panel_actions.h"
#include "ui_grid_actions.h"
#include "ui_physical_actions.h"
#include "ui_wave_scene.h"
#include "input_router.h"
#include "panel_navigation.h"
#include "metadata_client.h"
#include <optional>
#include "audio_device_preference.h"
#include <unordered_map>
#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <cstdlib>
#include <cmath>
#include <csignal>
#include <cstdio>
#include <cstdint>
#include <iostream>
#include <memory>
#include <future>
#include <fstream>
#include "transient_map.h"
#include <poll.h>
#include <stdexcept>
#include <string>
#include <unistd.h>
#include <vector>

namespace {
volatile std::sig_atomic_t exitRequested=0;
void onSignal(int) { exitRequested=1; }
using Clock=std::chrono::steady_clock;

}
int DeckApplication::run(int argc,char** argv) {
    if(argc>3) {
        std::cerr << "Usage: ./deck001 [audio-file] [ALSA-device]\n";
        return 1;
    }
    try {
        const std::string folder=Settings::kMusicFolder;
        const std::string initial=argc>=2?argv[1]:std::string{};
        std::unique_ptr<Display> display;
        if(Settings::kPreferDrmKms && !std::getenv("DECK001_FORCE_FB")) {
            try {
                display=std::make_unique<KmsDisplay>(Settings::kDrmCardPath);
            } catch(const std::exception& e) {
                std::cerr<<"DRM/KMS not available: "<<e.what()
                         <<". Using existing framebuffer backend.\n";
            }
        }
        if(!display) display=std::make_unique<FramebufferDisplay>(Settings::kFramebufferPath);
        // Put the splash on screen BEFORE hardware-controller/scanner setup.
        // Same DRM/KMS owner and Graphics surface as the final DJ UI.
        if(display->width()!=Ui::width || display->height()!=Ui::height)
            throw std::runtime_error("Unexpected framebuffer dimensions; no pixels changed");
        Graphics canvas(display->width(),display->height());
        try {UiBootScreen::present(*display,canvas,Settings::kVersion);}
        catch(const std::exception& e) {
            // A splash error must never prevent normal DJ initialization.
            std::cerr<<"DECK 001 boot splash skipped: "<<e.what()<<'\n';
        }
        LibraryIpc library(LibraryIpc::defaultSocket());
        // An already-live compatible scanner is reused. Otherwise launch our
        // matching scanner executable automatically; the UI never waits on it.
        library.poll();
        ScannerRuntime scanner;
        MetadataClient metadata; // separate process; no DB/media I/O in playback process
        scanner.tick(library.connected());
        BrowserController::State browser; // browsing, selection, folder, list ownership.
        bool usbLost=false, loadedTrackFromUsb=false;
        std::string loadedTrackUsbId;
        const char* configuredUsbRoot=std::getenv("DECK001_USB_ROOT");
        const std::string usbRoot=configuredUsbRoot?configuredUsbRoot:"/run/deck001/usb";
        auto rememberTrackSource=[&](const std::string& filename) {
            loadedTrackFromUsb=AppSourceIdentity::onUsb(filename,usbRoot);
            loadedTrackUsbId=AppSourceIdentity::forPlayingTrack(
                filename,usbRoot,library.usbReady(),library.usbIdentity());
            usbLost=false;
        };
        bool previousUsbReady=false;
        // Source with no FS UUID remains session-local, never associated
        // with another anonymous stick through a reused mount point.
        std::uint64_t unknownUsbGeneration=1;
        const std::string usbSessionBase=std::to_string(getpid())+"-"+
            std::to_string(Clock::now().time_since_epoch().count());
        auto usbSessionId=[&]{return "SESSION:"+usbSessionBase+"-"+std::to_string(unknownUsbGeneration);};
        // Read one small optional configuration at startup, not from the
        // audio worker. Explicit CLI override keeps the existing interface.
        const std::string audioDevice=AudioDevicePreference::choose(
            argc==3?argv[2]:"", std::getenv("DECK001_MASTER_ALSA_DEVICE"),
            AudioDevicePreference::configDevice("config/audio_master.conf"),
            Settings::kAudioDevice);
        // One owned worker drains previously audible PCM after each seamless promotion.
        struct RetiredAudioObjects {
            std::unique_ptr<DeckAudio::LiveResidentSource> audio;
            std::shared_ptr<const Mp3Waveform> priorTrack;
        };
        DeferredRetirement::Queue<RetiredAudioObjects,8> retiredAudio;
        TrackMetadata currentMetadata;
        KeyShift::State keyShift;
        // Optional direct-cable Ethernet link; never part of audio callback.
        DeckLink::Worker deckLink;

        BacklightControl backlight; // Optional sysfs; non-writable -> software fallback.
        I2cBus i2c(Settings::kI2cDevice);
        I2cEncoder encoder(i2c,Settings::kI2cEncoderAddress,Settings::kI2cPollMs);
        ModulinoControls modulinoControls;
        Cues::Store storedCues;
        Metadata::Packet currentTrackIdentity{};
        LiveCuesNav::View navView=LiveCuesNav::View::Default;
        DeckFx::Selection fxSelection;
        PanelNavigation panelNavigation;
        std::uint64_t navEpoch=0;
        int cuesBank=0;
        auto lastNeoKeyRoute=NeoKeyModeControls::route(navView,false,false,cuesBank);
        int lastTriggeredCue=-1;
        Clock::time_point lastCueTriggerAt{};
        const auto cueVisuals=[&](double sampleRate) {
            return AppViewHelpers::cueVisuals(storedCues,sampleRate);
        };
        bool cuePreviewActive=false;
        const char* customMidiMap=std::getenv("DECK001_MIDI_MAP");
        MidiInput midi(customMidiMap && *customMidiMap ? customMidiMap : "config/midi_generic.map");
        // Reusable offscreen drawing surface for the incoming side of a
        // chronological stitched waveform; allocated ONCE, not per frame.
        Graphics seamlessWaveCanvas(display->width(),display->height());
        if(!canvas.smoothFontAvailable())
            throw std::runtime_error("Smooth font unavailable: missing renderer header or bundled font; run bash prepare_visuals_macos.sh "
                                     "on your Mac, then copy the whole folder to the Pi. "
                                     "No bitmap-font UI is allowed in v1.5.");
        TouchInput touch(display->width(),display->height());
        std::cout << "DECK 001 v" << Settings::kVersion << " | ALSA " << audioDevice << " | touchscreen "
                  << (touch.fd()>=0?touch.deviceName():"not found") << '\n';
        std::cout << "Keys (+ Enter): p play, b browse/back, j/k rows, l load, o loop,"
                     " h/n jump -/+4 bars, t quantize, s settings, +/- zoom, [/] BPM,"
                     " ,/. grid offset, g grid editor, w save grid, r reset, q exit\n"
                     "Live-deck LOAD confirmation: L = confirm, C/B = cancel\n";
        std::shared_ptr<Mp3Waveform> track;
        std::unique_ptr<Player> player;
        UiWaveCache cache;
        WaveTiles waveTiles;
        ContourWaveform contourWave;
        ContourWaveform seamlessContourWave;
        WaveTiles seamlessWaveTiles;
        UiWaveScene::Renderer waveScene(canvas,seamlessWaveCanvas,seamlessWaveTiles,seamlessContourWave);
        ContourAnalysis contourData;
        GridEditor gridEditor;
        bool confirmGridExit=false;
        UiAction gridExitTarget=UiAction::None;
        LoopRegion priorPerformanceLoop{};
        bool gridEditing=false;
        std::string path=initial, error;
        const UserPreferences::LoadResult restoredPrefs=UserPreferences::load();
        const UserPreferences::Values& prefs=restoredPrefs.values;
        UiSettingsController::State uiSettings(prefs);
        UserPreferences::Writer preferencesWriter; // SD writes stay off UI/audio threads.
        bool browsing=initial.empty(), settingsOpen=false;
        
        DebugHud debugHud;
        
        // OFF by default. Compatible (44.1 kHz) decks are always prepared
        // with a seamless-capable persistent worker at initial LOAD; this
        // Settings flag gates whether the NEXT incoming track crossfades.
        // Turning ON never restarts the current audio output/session.
        AutoPilot::Controller autoPilot; // OFF on boot; no unattended resume.
        std::string autoPilotNotice;
        
        debugHud.setEnabled(prefs.debugInfo); // No /proc work when disabled.
        UiLedController::Presenter ledPresenter;
        
        
        
        
        
        
        double liveLoopBeats=Settings::kLoopBeats;
        int beatJumpBeats=Settings::kBeatJumpBeats;
        
        
        
        
        {
            constexpr double levels[]={0.38,0.67,1.0};
            const bool hardware=backlight.set(levels[uiSettings.brightnessLevel]);
            display->setBrightness(hardware?1.0:levels[uiSettings.brightnessLevel]);
        }
        using PerformanceMode=AppPerformance::Mode;
        PerformanceMode performanceMode=PerformanceMode::None; // No hidden knob action.
        PerformanceMode normalEncoderFocus=performanceMode; // CUES must not overwrite this.
        auto bpmPart=[&]() {return AppPerformance::bpmPart(performanceMode);};
        int lastBpmPulseTick=-1;
        long long lastUiBeatPulseTick=-1;
        bool confirmingLiveLoad=false;
        int proposedLoadIndex=-1;
        Clock::time_point liveWarningStart{};
        int liveWarningLastTick=-1;
        
        AppViewState viewState; // Only UI redraw flags; no audio or device state.
        bool& fullRedraw=viewState.fullRedraw;
        bool& detailDirty=viewState.detailDirty;
        bool& overviewDirty=viewState.overviewDirty;
        bool& transportDirty=viewState.transportDirty;
        bool& bpmDirty=viewState.bpmDirty;
        bool& footerDirty=viewState.footerDirty;
        bool& browserDirty=viewState.browserDirty;
        bool& encoderHeaderDirty=viewState.encoderHeaderDirty;
        UiFrameRenderer::AutoPilotIndicator autoPilotIndicator;
        UiSceneComposer::State sceneComposer;
        // The only Settings persistence path. Called from UI settings actions,
        // copies a small immutable snapshot; the writer debounces and commits
        // to the internal SD asynchronously, never in audio or KMS callbacks.
        auto persistUserSettings=[&]() {
            preferencesWriter.request(uiSettings.snapshot(debugHud.enabled()));
        };
        // Migrate separate legacy AUTO CUE/DEBUG INFO/SEAMLESS preferences,
        // or regenerate a damaged primary from its last-known-good backup.
        if(restoredPrefs.needsSave)persistUserSettings();
        // All input paths (touch, grid-editor exit, BPM) use this single
        // transition. Audio loop engagement remains a separate state.
        auto selectEncoderMode=[&](PerformanceMode next) {
            // CUES recalled loops may temporarily take the encoder; restore
            // the latest NORMAL assignment on CUES exit, not the cue's mode.
            if(navView!=LiveCuesNav::View::Cues && !browsing && !settingsOpen)
                normalEncoderFocus=next;
            if(performanceMode==next) return;
            performanceMode=next;
            encoderHeaderDirty=true;
            transportDirty=true; // LIVE mode highlight only; audio unaffected.
            footerDirty=true;
            bpmDirty=true; // Clear old BPM edit pulse when leaving it.
        };
        int lastClock=-1;
        double zoomSeconds=Settings::kDefaultWaveSeconds;
        // Loading and UI handover state are owned by the TrackSession module.
        // Audio is still owned solely by the existing Player instance.
        TrackSession trackSession;
        using PreparedSong=TrackSession::PreparedSong;
        bool revealingTrack=false;
        Clock::time_point revealStart{};
        constexpr auto kRevealDuration=std::chrono::milliseconds(460);
        LoopWaveCamera::Camera loopWaveCamera;
        LoopWaveCamera::View lastLoopTouchCamera{};
        LoopWaveCamera::View loopDragCameraAnchor{};
        LoopWaveCamera::View loopCameraSettleFrom{};
        Clock::time_point loopCameraSettleStart{};
        bool loopCameraSettling=false,loopDragMoved=false;
        InputRouter::TouchGestures touchGestures; // UI-thread touch DOWN ownership.
        WaveformScrub::Anchor scrubAnchor{};
        UiScrubDisplayClock::ClockView scrubDisplay;
        bool scrubStarted=false;
        double gridVisibleStart=0.0;
        // Current fixed edit reference (track seconds). Changes only when
        // changing the selected beat or dragging the draft grid, not on zoom.
        double gridAnchorSeconds=0.0;
        double gridZoomFactor=1.0; // 1.0 = exactly one four-beat guide across 800 px.
        auto gridView=[&]() -> GridViewWindow {
            return (track && gridEditing)?gridEditor.window(*track,gridZoomFactor):GridViewWindow{};
        };
        std::uint64_t lastPosition=0;
        VisualMotionClock visualClock;
#if defined(DECK001_B12_TRACE)
        B12VisualTrace b12Trace;
#endif
        int lastHeartLevel=-1; // 8-bit visual pulse; no heap work in frame loop.
        bool lastPlaying=false, lastLoopActive=false, wasBrowsing=false, wasSettingsOpen=false;
        std::uint64_t lastLoopStart=0,lastLoopEnd=0;
        auto lastOverview=Clock::now()-std::chrono::seconds(1);
        int lastUsbPulsePhase=-1;
        auto clearDirty=[&] {
            viewState.invalidateAll();
            lastPosition=0;lastClock=-1;lastHeartLevel=-1;visualClock.reset();
        };


        if constexpr(Settings::kPrintFps)
            MemoryDiagnostics::print("startup",track.get(),&cache,&contourData,&waveTiles,&contourWave);
        if(initial.empty()) library.request("INTERNAL", "");
        // Prepare next song and waveform off-thread. A fully stopped deck can
        // surrender its previous PCM to this SAME worker BEFORE decoding the
        // replacement. Moving the Player into the worker keeps destructor/join
        // work off the UI thread. Playing/CUE-draining decks use old behavior.
        auto startLoad=[&](const std::string& file,bool restorePrevious=false,bool automatic=false) {
            if(!automatic && autoPilot.enabled()){
                // A deliberate manual replacement takes priority. If a mix is
                // already committed it will finish; normal load is gated below.
                autoPilot.disengage();autoPilotNotice.clear();footerDirty=detailDirty=true;
            }
            if(trackSession.loadingTrack || trackSession.seamlessAwaiting)return; // One in-flight load; no stale generation can win.
            waveScene.beginLoad();
            const auto begin=trackSession.begin({file,
                AppSourceIdentity::forLoad(file,usbRoot,library.usbIdentity(),usbSessionId()),
                path,restorePrevious,automatic,uiSettings.seamlessEnabled,cuePreviewActive},
                player,track);
            if(!begin.started)return;
            if(keyShift.open) {keyShift.close();++navEpoch;}
            if(!automatic){browsing=false;settingsOpen=false;}
            confirmingLiveLoad=false;proposedLoadIndex=-1;
            if(begin.retiredCurrent) {
                // GUI-only resources of the old song; Player and PCM have
                // already been transferred to the existing decoder worker.
                cache=UiWaveCache{};contourData=ContourAnalysis{};
                waveTiles.reset();contourWave.reset();
                gridEditor.close();gridEditing=false;confirmGridExit=false;
                cuePreviewActive=false;
                // The old stopped deck and its PCM are already retired.
                // Do not keep presenting stale physical CUE colors/slots
                // during the new source's loading baseline. This only clears
                // UI state: it never deletes the previous track's metadata.
                storedCues.reset(0);
                lastTriggeredCue=-1;
                ++navEpoch; // Reject touches captured against retired source.
            }
            fullRedraw=begin.retiredCurrent;
            detailDirty=overviewDirty=transportDirty=footerDirty=browserDirty=true;
            std::cout<<"Preparing track in background: "<<file
                     <<" | early_pcm_release="<<(begin.retiredCurrent?"yes":"no")<<'\n';
        };
        // Borrowed audio/analysis views are assembled only on the UI thread.
        // The renderer owns its own appearance timeline but never audio state.
        auto drawSeamlessWave=[&](MultitrackLayout::Mode layoutMode) {
            const bool visible=!browsing && !settingsOpen && !gridEditing &&
                bool(track) && bool(player) && (trackSession.pendingSeamlessLoad || trackSession.seamlessAwaiting) &&
                (!trackSession.autoPilotRequestedLoad || trackSession.seamlessAwaiting);
            const bool scheduled=visible && trackSession.seamlessAwaiting &&
                (player->seamlessStatus()==2 || player->seamlessStatus()==3) &&
                trackSession.seamlessAwaitingSong && trackSession.seamlessAwaitingSong->song;
            UiWaveScene::IncomingFrame frame;
            frame.visible=visible;
            frame.linked=MultitrackLayout::remote(layoutMode);
            frame.layout=layoutMode;
            frame.autoPilot=autoPilot.inFlight();
            frame.outgoing=track.get();
            frame.outgoingCache=&cache;frame.outgoingTiles=&waveTiles;
            frame.outgoingSeconds=(player&&track&&track->sampleRate>0)?
                player->visualTransport().precisePosition/track->sampleRate:0.0;
            frame.outgoingLoop=player?player->loop():LoopRegion{};
            frame.outgoingCamera=lastLoopTouchCamera;
            frame.outgoingCues=cueVisuals(track?track->sampleRate:0.0);
            frame.scheduled=scheduled;
            frame.incomingGain=player?player->seamlessAudibleIncomingGain():0.0f;
            if(scheduled) {
                frame.song=trackSession.seamlessAwaitingSong->song.get();
                frame.cache=&trackSession.seamlessAwaitingSong->cache;
                const auto &slots=trackSession.seamlessAwaitingSong->legacyCues;
                if(frame.song->sampleRate>0)
                  for(std::size_t ci=0;ci<slots.size();++ci){
                    const auto &cue=slots[ci];
                    if(cue.type==Cues::Type::Empty)continue;
                    auto &dest=frame.incomingCues[ci];
                    dest.assigned=true;dest.loop=cue.type==Cues::Type::Loop;
                    dest.startSeconds=double(cue.start)/frame.song->sampleRate;
                    dest.endSeconds=double(cue.end)/frame.song->sampleRate;
                    dest.savedBeats=cue.savedBeats;
                  }
                frame.contour=&trackSession.seamlessAwaitingSong->contour;
                frame.sourceSeconds=player->seamlessIncomingVisualPosition()/frame.song->sampleRate;
                const auto sourceVisual=player->visualTransport();
                frame.incomingFramesPerSecond=(track && track->sampleRate>0) ?
                    frame.song->sampleRate*std::max(0.0,sourceVisual.sourceFramesPerSecond)/track->sampleRate : 0.0;
            }
            frame.zoomSeconds=zoomSeconds;
            frame.centrePlayhead=uiSettings.centrePlayhead;
            // Multitrack always uses CLASSIC visually; saved mode is untouched.
            frame.mode=WaveformMode::FrequencyBlue;
            frame.outgoingTitle=currentMetadata.title.empty()?path:currentMetadata.title;
            if(trackSession.seamlessAwaitingSong)
                frame.incomingTitle=trackSession.seamlessAwaitingSong->metadata.title;
            if(frame.incomingTitle.empty())frame.incomingTitle=trackSession.seamlessAwaitingPath;
            frame.grid=uiSettings.gridVisibility;
            frame.color=uiSettings.contourColorStyle;
            frame.gradient=uiSettings.contourGradient;
            waveScene.paintIncoming(frame,Clock::now());
        };
        // One UI activation path for ordinary LOAD and completed seamless
        // handovers. The latter promotes the already-audible source without
        // closing/reopening ALSA; metadata/waveform swap happens afterward.
        auto activatePrepared=[&](PreparedSong&& ready,
                                  const std::optional<Metadata::Packet>& db,
                                  const std::string& newPath,bool seamless) {
            const bool validDb=db && db->op==Metadata::Op::Loaded;
            if(validDb && db->hasGrid && db->grid.manual && db->grid.valid &&
               std::isfinite(db->grid.bpm) && db->grid.bpm>=60 && db->grid.bpm<=220 &&
               std::isfinite(db->grid.firstBeat)) {
                auto& g=ready.song->beatGrid;
                g.bpm=db->grid.bpm;g.rawBpm=db->grid.rawBpm;
                g.firstBeatSeconds=db->grid.firstBeat;
                g.confidence=db->grid.confidence;g.estimated=true;g.manual=true;
                g.integerTempoSelected=db->grid.integerTempo!=0;g.fromCache=true;
            }
            const std::int64_t initialCue=uiSettings.autoCueEnabled && ready.song->autoCueAnalyzed
                 ?static_cast<std::int64_t>(ready.song->autoCueFrame):-1;
            if(seamless) {
                if(!player || !player->adoptSeamlessTrack(ready.song,initialCue))
                    throw std::runtime_error("Seamless output source was not promoted");
                auto retired=player->releaseRetiredSeamless();
                auto oldUiTrack=std::move(track);
                // Lifetime-owned queue; no detached thread or unbounded
                // accumulation of resident PCM during repeated transitions.
                retiredAudio.retire({std::move(retired),std::move(oldUiTrack)});
            }else {
                if(player)player->fadeOutForTrackChange();
                player.reset();
            }
            track=std::move(ready.song);
            loopWaveCamera.reset(); // New source identity, new loop viewport epoch.
            cache=std::move(ready.cache);
            contourData=std::move(ready.contour);
            waveTiles.reset();contourWave.reset();
            if(!seamless) {
                // Prepare a persistent mixer-ready worker for every 44.1 kHz
                // initial source, EVEN WHEN Settings is OFF. Thus OFF->ON
                // takes effect on the next track selection, with no hot
                // ALSA/worker replacement while audio is playing. OFF still
                // means ordinary non-crossfaded LOAD. Other source rates
                // retain the legacy worker until multi-rate is validated.
                const bool persistentReady=
                    SeamlessModePolicy::supportsPersistentWorker(track->sampleRate);
                if(uiSettings.seamlessEnabled && !persistentReady)
                    std::cerr<<"SEAMLESS: source is not 44.1 kHz; live transition unavailable for this track\n";
                player=std::make_unique<Player>(track,audioDevice,initialCue,persistentReady,uiSettings.keylockFftBackend,uiSettings.keylockEngine);
                if(trackSession.loadingRecoveryTrack && trackSession.recoveryTrack.sourceFrame<track->totalFrames)
                    player->seek(trackSession.recoveryTrack.sourceFrame);
            }
            player->setKeylockMode(uiSettings.keylockMode);
            player->setScrubConfiguration(3,uiSettings.scratchQuality,1);
            player->setFx(fxSelection);
            modulinoControls.disconnected();cuePreviewActive=false;
            liveLoopBeats=Settings::kLoopBeats;
            gridEditor.close();gridEditing=false;confirmGridExit=false;
            path=newPath;rememberTrackSource(path);
            currentTrackIdentity=validDb?*db:Metadata::Packet{};
            storedCues.reset(track->totalFrames);
            Cues::Slots slots=ready.legacyCues;
            if(validDb) {
                slots={};
                if(db->hasCues)for(int i=0;i<8;++i) {
                    const auto& c=db->cues[i];
                    slots[i]={static_cast<Cues::Type>(c.kind),c.start,c.end,c.beats};
                    if(!Cues::valid(slots[i],track->totalFrames))slots[i]={};
                }
            }
            for(int i=0;i<8;++i) {
                const auto& c=slots[i];
                if(c.type==Cues::Type::Point)storedCues.putPoint(i,c.start);
                else if(c.type==Cues::Type::Loop)
                    storedCues.putLoop(i,c.start,c.end,c.savedBeats);
            }
            navView=LiveCuesNav::View::Default;++navEpoch;
            panelNavigation.discard();
            lastTriggeredCue=-1;
            currentMetadata=std::move(ready.metadata);
            keyShift.load(currentMetadata.key);
            if constexpr(Settings::kPrintFps)
                MemoryDiagnostics::print("active-track",track.get(),&cache,&contourData,&waveTiles,&contourWave);
            error.clear();browsing=settingsOpen=confirmingLiveLoad=false;
            trackSession.recoveryTrack={};trackSession.loadingRecoveryTrack=false;
            if(trackSession.loadMemory) {
                trackSession.loadMemory->mark(TrackLoadLifecycle::LoadMilestone::Activated);
                trackSession.firstDisplayPending=trackSession.loadMemory;
                trackSession.loadMemory->report(seamless?"seamless-complete":"loaded",
                    player?player->alsaUnderruns():0);
                trackSession.loadMemory.reset();
            }
            revealingTrack=!seamless;
            revealStart=Clock::now();clearDirty();
            if(seamless && autoPilot.inFlight()){
                autoPilot.complete(path);footerDirty=detailDirty=true;
                std::cout<<"AUTO PILOT: "<<autoPilot.label()<<" after "<<path<<'\n';
            }
            trackSession.autoPilotRequestedLoad=false;
            std::cout<<(seamless?"Seamless promoted: ":"Loaded: ")<<path<<'\n';
        };
        const TrackSession::Hooks sessionHooks{
            [&](PreparedSong&& ready,const std::optional<Metadata::Packet>& db,
                const std::string& newPath,bool seamless) {
                activatePrepared(std::move(ready),db,newPath,seamless);
            },
            [&]() {
                if(track && !browsing && !settingsOpen && !gridEditing)
                    waveScene.capturePromotion(Clock::now());
            },
            [&]() { waveScene.beginLoad(); }
        };
        if(!initial.empty())startLoad(initial);
        auto requestLoad=[&](int index) {
            if(trackSession.loadingTrack || trackSession.seamlessAwaiting)return;
            if(index<0 || index>=static_cast<int>(browser.files.size())) return;
            if(browser.enterDirectory(index)) {
                library.request(browser.usbSource?"USB":"INTERNAL",browser.folder);
                browserDirty=detailDirty=true;return;
            }
            if(track && browser.files[index]==path) {
                panelNavigation.close(navView,browsing,settingsOpen);++navEpoch;
                clearDirty();return;
            }
            if(player && player->transportMoving() &&
               uiSettings.seamlessEnabled && player->seamlessExperimental() &&
               !autoPilot.inFlight() && !cuePreviewActive) {
                // Existing TrackSession performs compatibility checks and keeps
                // the audible source playing if incoming preparation fails.
                startLoad(browser.files[index]);
                return;
            }
            if(player && player->transportMoving()) {
                proposedLoadIndex=index;
                confirmingLiveLoad=true;++navEpoch; // Fresh touch-down required for a modal action.
                liveWarningStart=Clock::now();liveWarningLastTick=-1;
                detailDirty=true;browserDirty=true;transportDirty=true;
                std::cout<<"Deck playing: confirm LOAD to replace or CANCEL to continue.\n";
            } else startLoad(browser.files[index]);
        };
        auto refreshLibrary=[&]() {
            // Re-listing is delegated entirely to the separate scanner process.
            // No metadata, stat or directory accesses on the UI/audio thread.
            library.request(browser.usbSource?"USB":"INTERNAL",browser.folder);
            browserDirty=true;
        };
        auto changeBrowseSource=[&](bool usb) {
            browser.source(usb);
            library.request(usb?"USB":"INTERNAL","");
            browsing=true;browserDirty=detailDirty=true;
        };
        auto toggleLoop=[&]() {
            if(!player || !track)return;
            const auto result=DeckController::togglePreparedLoop(*player,*track,liveLoopBeats);
            if(result==DeckController::LoopResult::MissingGrid) {
                std::cerr<<"Loop unavailable: set BPM/grid first\n";
                return;
            }
            if(result==DeckController::LoopResult::OutsideTrack) {
                std::cerr<<"Loop unavailable: no valid beatgrid-aligned interval\n";
                return;
            }
            detailDirty=overviewDirty=footerDirty=transportDirty=true;
        };
        auto navigationGrid=[&]() -> BeatNavigation::Grid {
            if (!track || track->sampleRate<=0 || !track->beatGrid.estimated
                || track->beatGrid.bpm<=0) return {};
            return {track->sampleRate*60.0/track->beatGrid.bpm,
                    track->beatGrid.firstBeatSeconds*track->sampleRate,
                    BeatNavigation::quantizeSizeBeats(uiSettings.quantizeSize)};
        };
        // Beatgrid editing is a self-contained UI-thread transaction. Neither
        // the grid model nor its controller owns Player or MetadataClient.
        UiGridActions::Context gridCtx{
            gridEditor,gridEditing,confirmGridExit,gridExitTarget,
            priorPerformanceLoop,track,player,gridZoomFactor,gridAnchorSeconds,
            gridVisibleStart,viewState,metadata,currentTrackIdentity,browser,path,
            panelNavigation,navView,browsing,settingsOpen,navEpoch,uiSettings,
            clearDirty,refreshLibrary,
            [&](PerformanceMode m){selectEncoderMode(m);},
            [&](){return performanceMode;}
        };
        auto updateGridGuide=[&](bool keepViewport=false) {
            UiGridActions::updateGuide(gridCtx,keepViewport);
        };
        UiPanelActions::Context panelCtx{
            panelNavigation,navView,browsing,settingsOpen,confirmingLiveLoad,
            navEpoch,uiSettings,browser,viewState,waveTiles,contourWave,
            backlight,*display,debugHud,player,track,zoomSeconds,
            clearDirty,persistUserSettings,refreshLibrary,changeBrowseSource,
            requestLoad,navigationGrid
        };
        auto keyShiftAvailable=[&] {
            return player && track && KeylockSignalsmith::available() &&
                !trackSession.loadingTrack && !trackSession.seamlessAwaiting &&
                !browsing && !settingsOpen && !gridEditing && !confirmGridExit && !confirmingLiveLoad;
        };
        auto touchView=[&] {
            InputRouter::View v{bool(track),gridEditing,settingsOpen,browsing,
                confirmGridExit,confirmingLiveLoad,browser.selected,browser.page,navEpoch,
                keyShiftAvailable() && !keyShift.open,keyShift.open};
            // A drag is owned only when DOWN starts within a *visible* active
            // loop on the main single-track detail waveform, never the overview.
            const bool dual=trackSession.pendingSeamlessLoad || trackSession.seamlessAwaiting ||
                autoPilot.inFlight();
            if(player && track && !gridEditing && !settingsOpen && !browsing &&
               !keyShift.open && !confirmingLiveLoad && !confirmGridExit &&
               !trackSession.loadingTrack && !dual && !player->previewPending() &&
               track->sampleRate>0 && lastLoopTouchCamera.windowSeconds>0) {
                const auto loop=player->loop();
                const auto grid=navigationGrid();
                if(loop.active && loop.end>loop.start && grid.valid()) {
                    const double x0=(static_cast<double>(loop.start)/track->sampleRate-
                        lastLoopTouchCamera.fromSeconds)*Ui::detailW/lastLoopTouchCamera.windowSeconds;
                    const double x1=(static_cast<double>(loop.end)/track->sampleRate-
                        lastLoopTouchCamera.fromSeconds)*Ui::detailW/lastLoopTouchCamera.windowSeconds;
                    v.loopStartX=std::clamp(static_cast<int>(std::ceil(x0)),0,Ui::detailW-1);
                    v.loopEndX=std::clamp(static_cast<int>(std::floor(x1)),0,Ui::detailW-1);
                    v.pixelsPerHalfBeat=Ui::detailW*0.5*grid.framesPerBeat/
                        (track->sampleRate*lastLoopTouchCamera.windowSeconds);
                    v.loopDragAllowed=v.pixelsPerHalfBeat>0;
                }
            }
            // Scrubbing is strictly stopped-only. A stopped LOOP prioritizes
            // audible waveform positioning; playing LOOP drag is untouched.
            v.stoppedScrubAllowed=player && track && track->totalFrames>1 &&
                !player->playing() && !player->transportMoving() &&
                !gridEditing && !browsing && !settingsOpen && !keyShift.open &&
                !confirmGridExit && !confirmingLiveLoad &&
                !trackSession.loadingTrack && !dual && !player->previewPending() &&
                 navView!=LiveCuesNav::View::Fx && lastLoopTouchCamera.windowSeconds>0.0;
            return v;
        };
        std::string dismissedUpdate;
        bool previousUpdateVisible=false;
        Clock::time_point lastUpdateStatus{};
        const std::string releaseStore=std::string(std::getenv("HOME")?
            std::getenv("HOME"):"/home/toomom")+"/deck001-releases";
        DeckLinkUpdateUi::TransferStatus preparedUpdate;
        bool devSourceEnabled=DeckDevSourceMode::enabled(releaseStore);
        const std::string usbPairConfig=std::string(std::getenv("HOME")?
            std::getenv("HOME"):"/home/toomom")+"/.config/deck001/updater";
        DeckUsbPair::Pending pendingMacPair;

        std::string lastUpdatePhase;
        int lastUpdatePercent=-1;
        const auto updateOffer=[&](){
            // Independent OTA receiver: firmware discovery is NOT tied to the
            // waveform, MASTER election, or live native Ethernet peer status.
            if(preparedUpdate.offerVisible() &&
               (!preparedUpdate.development() || devSourceEnabled) &&
               DeckLinkUpdateUi::newer(preparedUpdate.version,Settings::kVersion) &&
               (preparedUpdate.version+"|"+preparedUpdate.detail)!=dismissedUpdate && !settingsOpen)
                return preparedUpdate.version;
            return std::string{};
        };
        auto act=[&](Hit hit) {
            if(hit.action==UiAction::PeerUpdateLater) {
                dismissedUpdate=preparedUpdate.version+"|"+preparedUpdate.detail;
                viewState.fullRedraw=true;
                return;
            }
            if(hit.action==UiAction::PeerUpdateAccept) {
                // Verified bundle is already staged, without interrupting playback.
                // This is the ONLY path that may request a boot transition.
                if(preparedUpdate.ready() &&
                   (!preparedUpdate.development() || devSourceEnabled) &&
                   DeckLinkUpdateUi::newer(preparedUpdate.version,Settings::kVersion) &&
                   (!player || (!player->playing() && !player->transportMoving())) &&
                   !autoPilot.inFlight()) {
                    if((preparedUpdate.development()?
                            DeckUpdateApproval::requestDevelopment(releaseStore,preparedUpdate.version):
                            DeckUpdateApproval::request(releaseStore, preparedUpdate.version))) {
                        // Supervisor re-verifies the exact staged release
                        // before it can enter a trial. This UI cannot pick a
                        // release, claim success, or restart an active player.
                        exitRequested=1;
                    }else error="FIRMWARE APPROVAL SAVE FAILED";
                    viewState.fullRedraw=true;
                }
                return;
            }
            if(hit.action==UiAction::SettingsDevSourceToggle) {
                const bool desired=!devSourceEnabled;
                if(!DeckDevSourceMode::set(releaseStore,desired))
                    error="DEV SOURCE MODE SAVE FAILED";
                else devSourceEnabled=desired;
                viewState.fullRedraw=true;
                return;
            }
            if(hit.action==UiAction::SettingsPairMac) {
                // Physical presence required, one exact authenticated request ID.
                if(!pendingMacPair.valid())error="NO MAC PAIRING REQUEST";
                else if(!DeckUsbPair::approve(usbPairConfig,pendingMacPair))
                    error="PAIRING APPROVAL FAILED";
                viewState.detailDirty=true;
                return;
            }
            if(hit.action==UiAction::SettingsSoftwareUpdate) {
                // Re-open an existing signed update offer using the CLEAN01
                // approval path. Never write restart-request or lifecycle state
                // from this settings action.
                if(preparedUpdate.offerVisible() &&
                   (!preparedUpdate.development() || devSourceEnabled) &&
                   DeckLinkUpdateUi::newer(preparedUpdate.version,Settings::kVersion)) {
                    dismissedUpdate.clear();
                    settingsOpen=false;
                    viewState.fullRedraw=true;
                } else {
                    error="NO VERIFIED FIRMWARE UPDATE AVAILABLE";
                    viewState.detailDirty=true;
                }
                return;
            }
            if(hit.action==UiAction::LinkAssignMaster) {
                // The MASTER label is hidden on a follower. Its historical
                // touch rectangle must not become an invisible takeover key.
                const auto status=deckLink.snapshot();
                if(status.connected && !status.localMaster && status.takeoverAvailable &&
                   deckLink.claimMaster()) {
                    viewState.encoderHeaderDirty=true;viewState.detailDirty=true;
                } else if(status.connected && !status.localMaster) {
                    error="TAKE MASTER REQUIRES v2.2.90 PEERS";
                    viewState.detailDirty=true;
                }
                return;
            }
            if(hit.action==UiAction::LinkToggleSync || hit.action==UiAction::LinkSyncOff ||
               hit.action==UiAction::LinkSyncBpm || hit.action==UiAction::LinkSyncBeat) {
                const auto link=deckLink.snapshot();
                const auto mode=hit.action==UiAction::LinkSyncOff?DeckLink::SyncMode::Off:
                    hit.action==UiAction::LinkSyncBpm?DeckLink::SyncMode::Bpm:
                    hit.action==UiAction::LinkSyncBeat?DeckLink::SyncMode::Beat:
                    static_cast<DeckLink::SyncMode>((static_cast<unsigned>(link.syncMode)+1)%3);
                if(link.connected && link.peerMaster && deckLink.setSyncMode(mode)) {
                    // Preference survives incompatible tempo and missing grid;
                    // playback stays independent until the engine can apply it.
                    viewState.encoderHeaderDirty=true;
                    viewState.detailDirty=true;
                }
                return;
            }

            auto setShift=[&](int amount) {
                amount=std::clamp(amount,-6,6);
                if(player && player->setKeyShift(amount)) {
                    keyShift.semitones=amount;
                    detailDirty=footerDirty=true;
                }
            };
            switch(hit.action) {
            case UiAction::KeyShiftOpen:
                if(keyShiftAvailable()) {keyShift.open=true;++navEpoch;detailDirty=true;}
                return;
            case UiAction::KeyShiftClose:
                keyShift.close();++navEpoch;detailDirty=true;
                return;
            case UiAction::KeyShiftEdit:
                if(keyShift.open) {
                    keyShift.editingOriginal=!keyShift.editingOriginal;
                    keyShift.originalMinor=keyShift.original && keyShift.original->minor;
                    detailDirty=true;
                }
                return;
            case UiAction::KeyShiftMode:
                if(keyShift.open && keyShift.editingOriginal) {
                    keyShift.originalMinor=!keyShift.originalMinor;
                    detailDirty=true;
                }
                return;
            case UiAction::KeyShiftNote:
                if(keyShift.open && keyShift.editingOriginal) {
                    keyShift.original=KeyShift::Key{hit.index,keyShift.originalMinor};
                    keyShift.editingOriginal=false;detailDirty=true;
                }else if(keyShift.open)setShift(keyShift.shiftForNote(hit.index));
                return;
            case UiAction::KeyShiftStep:
                if(keyShift.open)setShift(hit.index?keyShift.semitones+hit.index:0);
                return;
            default:break;
            }
            // The stacked A/B waveform is a read-only visual in this stage.
            // Zoom/grid touch targets are not drawn there, so a tap on their
            // former coordinates must not silently operate on outgoing A.
            const bool stackedReadOnly=!browsing && !settingsOpen && !gridEditing &&
                (trackSession.pendingSeamlessLoad || trackSession.seamlessAwaiting) &&
                (!trackSession.autoPilotRequestedLoad || trackSession.seamlessAwaiting);
            if(stackedReadOnly && (hit.action==UiAction::ZoomIn ||
               hit.action==UiAction::ZoomOut || hit.action==UiAction::GridEditorOpen))return;
            // Only conflicting transport controls are gated after the
            // transition has been committed. Browse/Settings/UI stay live.
            const bool committed=trackSession.seamlessAwaiting && player && player->seamlessStatus()==2;
            if(autoPilot.enabled() && (hit.action==UiAction::Seek ||
               hit.action==UiAction::JumpBackward || hit.action==UiAction::JumpForward))return;
            // Once B is being primed/scheduled, lock source-changing performance
            // controls so an in-flight transition cannot use a stale BPM/grid.
            if(autoPilot.inFlight() && (hit.action==UiAction::BpmWhole ||
               hit.action==UiAction::BpmFraction || hit.action==UiAction::CuesPad ||
               hit.action==UiAction::CycleKeylock || hit.action==UiAction::LoopEngage || hit.action==UiAction::Loop ||
               hit.action==UiAction::GridEditorOpen))return;
            if(committed && (hit.action==UiAction::Seek ||
               hit.action==UiAction::JumpBackward || hit.action==UiAction::JumpForward ||
               hit.action==UiAction::CuesPad || hit.action==UiAction::LoopEngage ||
               hit.action==UiAction::Loop || hit.action==UiAction::CycleKeylock ||
               hit.action==UiAction::GridEditorOpen || hit.action==UiAction::BpmWhole ||
               hit.action==UiAction::BpmFraction))return;
            if(hit.action==UiAction::ReloadPrevious) {
                if(!track && !trackSession.loadingTrack && trackSession.recoveryTrack)
                    startLoad(trackSession.recoveryTrack.path,true); // Explicit retry only; async and USB-safe.
                return;
            }
            if(confirmGridExit) {
                UiGridActions::handleDialog(gridCtx,hit);
                return;
            }
            if(hit.action==UiAction::FxDismiss) {
                if(navView==LiveCuesNav::View::Fx) {
                    navView=LiveCuesNav::View::Default;
                    ++navEpoch;
                    clearDirty();
                }
                return;
            }
            if(hit.action==UiAction::FxToggle) {
                if(!gridEditing && !confirmingLiveLoad && !trackSession.loadingTrack) {
                    navView=navView==LiveCuesNav::View::Fx?
                        LiveCuesNav::View::Default:LiveCuesNav::View::Fx;
                    ++navEpoch;
                    if(navView==LiveCuesNav::View::Fx) {
                        if(browsing || settingsOpen) panelNavigation.discard();
                        browsing=false;settingsOpen=false;
                        // Last selected effect is assigned immediately, without
                        // changing its signed amount or rhythmic period.
                        selectEncoderMode(PerformanceMode::Fx);
                        if(player)player->setFx(fxSelection);
                    }
                    clearDirty();
                }
                return;
            }
            if(hit.action==UiAction::SettingsLayerToggle ||
               hit.action==UiAction::OpenSettingsPanel)
                hit.action=UiAction::Settings; // legacy command compatibility
            if(navView==LiveCuesNav::View::Fx &&
               (hit.action==UiAction::Settings || hit.action==UiAction::Browse)) {
                // Leaving FX for a panel must not bookmark/reopen the popup.
                navView=LiveCuesNav::View::Default;
                ++navEpoch;
            }
            if(hit.action==UiAction::FxFilter || hit.action==UiAction::FxReverb ||
               hit.action==UiAction::FxDelay || hit.action==UiAction::FxGater) {
                const auto type=hit.action==UiAction::FxFilter?DeckFx::Type::Filter:
                                hit.action==UiAction::FxReverb?DeckFx::Type::Reverb:
                                hit.action==UiAction::FxDelay?DeckFx::Type::Delay:DeckFx::Type::Gater;
                fxSelection.select(type);
                if(player)player->setFx(fxSelection);
                selectEncoderMode(PerformanceMode::Fx);
                // Selecting one of the four floating tiles closes the popup;
                // the FX bottom icon now represents the selected effect.
                if(navView==LiveCuesNav::View::Fx) {
                    navView=LiveCuesNav::View::Default;
                    ++navEpoch;
                }
                clearDirty();
                return;
            }
            if(hit.action==UiAction::LiveToggle) {
                if(!gridEditing && !confirmingLiveLoad && !trackSession.loadingTrack) {
                    navView=navView==LiveCuesNav::View::Live?
                        LiveCuesNav::View::Default:LiveCuesNav::View::Live;
                    ++navEpoch;
                    if(navView==LiveCuesNav::View::Live){browsing=false;settingsOpen=false;}
                    // LIVE has no implicit knob takeover. Recalled cue loops
                    // must not overwrite the previous NORMAL function.
                    if(performanceMode!=normalEncoderFocus)
                        selectEncoderMode(normalEncoderFocus);
                    clearDirty();
                }
                return;
            }
            if(hit.action==UiAction::CuesToggle) {
                if(!gridEditing && !confirmingLiveLoad && !trackSession.loadingTrack) {
                    const bool leaving=navView==LiveCuesNav::View::Cues;
                    navView=leaving?LiveCuesNav::View::Default:LiveCuesNav::View::Cues;
                    ++navEpoch;
                    if(!leaving){browsing=false;settingsOpen=false;}
                    else selectEncoderMode(normalEncoderFocus);
                    clearDirty();
                }
                return;
            }
            if(hit.action==UiAction::CuesBankA || hit.action==UiAction::CuesBankB) {
                if(navView==LiveCuesNav::View::Cues && !browsing && !settingsOpen) {
                    const int nextBank=hit.action==UiAction::CuesBankA?0:1;
                    if(nextBank!=cuesBank){cuesBank=nextBank;++navEpoch;}
                    transportDirty=footerDirty=true;
                }
                return;
            }
            if(hit.action==UiAction::CuesPad) {
                if(navView!=LiveCuesNav::View::Cues || browsing || settingsOpen || gridEditing ||
                   confirmingLiveLoad || trackSession.loadingTrack || !track || !player ||
                   hit.index<0 || hit.index>=8)return;
                const int index=hit.index;
                const auto result=CuePadController::press(storedCues,*player,*track,index,
                    modulinoControls.shift(),uiSettings.quantized,navigationGrid());
                if(result.selectedLoopMode)selectEncoderMode(PerformanceMode::Loop);
                if(result.recalled) {
                    lastTriggeredCue=index;lastCueTriggerAt=Clock::now();
                }
                const bool changed=result.changed;
                if(changed && !metadata.saveCues(currentTrackIdentity,storedCues.slots()))
                    std::cerr<<"CUES UNSAVED: storage queue full (session retained)\n";
                detailDirty=overviewDirty=transportDirty=footerDirty=true;
                return;
            }
                        if(hit.action==UiAction::SyncUnavailable) return; // Disabled until real sync.
            if(hit.action!=UiAction::None && hit.action!=UiAction::BpmWhole &&
               hit.action!=UiAction::BpmFraction &&
               (performanceMode==PerformanceMode::BpmWhole ||
                performanceMode==PerformanceMode::BpmFraction)) {
                selectEncoderMode(PerformanceMode::None);
            }
            if(UiGridActions::handle(gridCtx,hit,trackSession.loadingTrack))return;
            const bool wasCuesBeforePanel=navView==LiveCuesNav::View::Cues;
            if(UiPanelActions::handleSettings(hit,panelCtx)) {
                if(wasCuesBeforePanel && navView!=LiveCuesNav::View::Cues &&
                   performanceMode!=normalEncoderFocus)
                    selectEncoderMode(normalEncoderFocus);
                return;
            }
            if(hit.action==UiAction::LoopEngage) {
                if(!gridEditing && !browsing && !settingsOpen) {
                    selectEncoderMode(PerformanceMode::Loop);
                    toggleLoop();
                    transportDirty=footerDirty=true;
                }
                return;
            }
            if(hit.action==UiAction::Loop) {
                // The physical NeoKey LOOP and the touch LOOP use the same
                // action as the encoder click: select mode AND toggle audio loop.
                // Closing a panel must not reset the underlying performance view.
                panelNavigation.close(navView,browsing,settingsOpen);++navEpoch;
                selectEncoderMode(PerformanceMode::Loop);
                if(!autoPilot.inFlight() &&
                   !(trackSession.seamlessAwaiting && player && player->seamlessStatus()==2))
                    toggleLoop();
                clearDirty();return;
            }
            if(hit.action==UiAction::SelectBeatMode) {
                panelNavigation.close(navView,browsing,settingsOpen);++navEpoch;
                selectEncoderMode(AppPerformance::toggleBeat(performanceMode));
                clearDirty();return;
            }
            if(hit.action==UiAction::ToggleAutoPilot) {
                if(autoPilot.enabled()){
                    autoPilot.disengage();autoPilotNotice.clear();
                    std::cout<<"AUTO PILOT "<<autoPilot.label()<<'\n';
                } else {
                    const auto queue=browser.playablePaths();
                    const bool ready=track && player && player->playing() &&
                        player->seamlessExperimental() && !cuePreviewActive &&
                        !trackSession.loadingTrack && !trackSession.seamlessAwaiting && !player->loop().active &&
                        autoPilot.engage(queue,path);
                    if(!ready){
                        autoPilotNotice="NO QUEUE";
                        error="AUTO PILOT NEEDS PLAYING 44.1K TRACK + CURRENT FOLDER QUEUE";
                        std::cerr<<error<<'\n';
                    }else{
                        autoPilotNotice.clear();error.clear();
                        std::cout<<"AUTO PILOT ENABLED: "<<autoPilot.queuedTracks()
                                 <<" tracks; next "<<autoPilot.next()<<'\n';
                    }
                }
                detailDirty=footerDirty=true;return;
            }
            if(hit.action==UiAction::ToggleDebugInfo) {
                debugHud.setEnabled(!debugHud.enabled());
                persistUserSettings();
                fullRedraw=true;detailDirty=true; // Refit/restores entire track title.
                std::cout<<"DEBUG INFO "<<(debugHud.enabled()?"ON":"OFF")<<'\n';
                return;
            }
            if(hit.action==UiAction::BpmWhole || hit.action==UiAction::BpmFraction) {
                const auto requested=hit.action==UiAction::BpmWhole?
                    PerformanceMode::BpmWhole:PerformanceMode::BpmFraction;
                selectEncoderMode(AppPerformance::toggleBpm(performanceMode,requested));
                if(settingsOpen || browsing) {
                    panelNavigation.close(navView,browsing,settingsOpen);++navEpoch;
                    confirmingLiveLoad=false;proposedLoadIndex=-1;
                    clearDirty(); // Expose waveform and correct performance-mode selection.
                }
                bpmDirty=transportDirty=footerDirty=true;
                std::cout<<"BPM encoder "<<(performanceMode==PerformanceMode::BpmWhole?"whole (1.0)":
                       performanceMode==PerformanceMode::BpmFraction?"tenths (0.1)":"off")<<'\n';
                return;
            }
            if(hit.action==UiAction::PlayStop) {
                if(player) player->toggle();
                transportDirty=true;
                return;
            }
            if(confirmingLiveLoad) {
                if(hit.action==UiAction::ConfirmLiveLoad) {
                    const int next=proposedLoadIndex;
                    confirmingLiveLoad=false;proposedLoadIndex=-1;
                    ++navEpoch; // Reject any event captured while warning was visible.
                    if(next>=0 && next<static_cast<int>(browser.files.size())) startLoad(browser.files[next]);
                } else if(hit.action==UiAction::CancelLiveLoad || hit.action==UiAction::Browse) {
                    confirmingLiveLoad=false;proposedLoadIndex=-1;
                    ++navEpoch;
                    detailDirty=browserDirty=transportDirty=true;
                }
                return;
            }
            if(UiPanelActions::handleNavigation(hit,panelCtx)) {
                if(wasCuesBeforePanel && navView!=LiveCuesNav::View::Cues &&
                   performanceMode!=normalEncoderFocus)
                    selectEncoderMode(normalEncoderFocus);
                return;
            }
            switch(hit.action) {
            case UiAction::ZoomIn:
                zoomSeconds=std::max(Settings::kMinWaveSeconds,zoomSeconds/1.5);
                detailDirty=true;
                break;
            case UiAction::ZoomOut:
                zoomSeconds=std::min(Settings::kMaxWaveSeconds,zoomSeconds*1.5);
                detailDirty=true;
                break;
            case UiAction::Loop: selectEncoderMode(PerformanceMode::Loop);toggleLoop();break;
            case UiAction::SelectBeatMode: selectEncoderMode(AppPerformance::toggleBeat(performanceMode));transportDirty=true;break;
            case UiAction::JumpBackward:
            case UiAction::JumpForward:
                if(player && track && navigationGrid().valid())
                    player->beatJump(hit.action==UiAction::JumpForward?1:-1,
                                     beatJumpBeats,uiSettings.quantized,navigationGrid());
                detailDirty=overviewDirty=footerDirty=true;
                break;
            case UiAction::Seek:
                if(player && track) player->navigateTo(static_cast<std::uint64_t>(
                   std::clamp(hit.fraction,0.0,1.0)*track->totalFrames),uiSettings.quantized,navigationGrid());
                detailDirty=overviewDirty=footerDirty=true;
                break;
            default:break;
            }
        };

        // All control sources converge here; the router executes on this SAME UI
        // thread and forwards actions to the existing UI and Player controllers.
        auto applyDeckCommand=[&](DeckCommand command) {
            UiCommandRouter::route(command,{
                player.get(),track.get(),liveLoopBeats,navigationGrid(),beatJumpBeats,
                uiSettings.quantized,gridEditing,settingsOpen,browsing,
                confirmingLiveLoad,confirmGridExit,trackSession.loadingTrack,
                trackSession.seamlessAwaiting && player && player->seamlessStatus()==2,
                autoPilot.enabled(),autoPilot.inFlight(),browser,viewState,
                [&] { const auto link=deckLink.snapshot();
                    return link.connected && link.peerMaster &&
                           link.syncMode!=DeckLink::SyncMode::Off; }()
            },[&](UiAction action){act({action});},
              [&](PerformanceMode mode){selectEncoderMode(mode);});
        };

        UiPhysicalActions::Context physicalCtx{
            encoder,modulinoControls,lastNeoKeyRoute,touchGestures,navView,
            browsing,settingsOpen,gridEditing,confirmingLiveLoad,confirmGridExit,
            false,cuesBank,navEpoch,performanceMode,beatJumpBeats,uiSettings,
            browser,player,track,gridEditor,gridZoomFactor,gridAnchorSeconds,
            gridVisibleStart,zoomSeconds,viewState,
            [&](Hit h){act(h);},
            [&](DeckCommand cmd){applyDeckCommand(cmd);},
            [&](PerformanceMode m){selectEncoderMode(m);},
            [&](){
                // FX NeoKey assigns the last touch-selected effect, never opens
                // the FX menu or changes the selected effect.
                panelNavigation.close(navView,browsing,settingsOpen);++navEpoch;
                selectEncoderMode(PerformanceMode::Fx);
                if(player)player->setFx(fxSelection);
                clearDirty();
            },
            [&](){return navigationGrid();},fxSelection
        };
        std::signal(SIGINT,onSignal);
        std::signal(SIGTERM,onSignal);
        const bool keyboard=::isatty(STDIN_FILENO)!=0;
        const bool vblankPaced=display->vblankSynchronized();
        std::cout<<"Waveform scheduler: "
                 <<(vblankPaced ? "KMS page-flip paced (no fixed FPS clock)" :
                    "legacy FB with bounded fallback timer")
                 <<" | panel mode "<<display->refreshHz()<<" Hz"<<'\n';
        const auto fallbackInterval=std::chrono::milliseconds(Settings::kFramebufferFallbackFrameMs);
        auto nextFallbackFrame=Clock::now();
        UiPerformanceMonitor performanceMonitor;
        DeckLinkRuntime::Publisher linkPublisher;
        DeckLinkRuntime::LockTracker linkedLockTracker;
        bool remoteStripTouchBlocked=false;
        int lastLoadingAnimFrame=-1;
        bool previousLinkedTempoLocked=false;
        bool previousTempoApplied=false;
        double previousLinkedDisplayedBpm=-1.0;
        DeckBootReadiness::announce();
        while(!exitRequested) {
            // Native Ethernet receive/send stays in the non-RT DECK LINK worker.
            // Local ALSA playback is completely independent of Ethernet.
            DeckLinkRuntime::Playback localPlayback;
            localPlayback.track=track.get();
            localPlayback.trackOwner=track;
            localPlayback.bpm=player?player->tempoBpm():0.0;
            localPlayback.playing=player && player->playing();
            if(track && player && track->sampleRate>0) {
                const auto audible=player->visualTransport();
                localPlayback.sourceSeconds=audible.precisePosition/track->sampleRate;
                localPlayback.sourceSpeed=std::max(0.0,audible.sourceFramesPerSecond/track->sampleRate);
                localPlayback.navigationSerial=audible.visualSerial;
                const auto audibleLoop=player->loop();
                localPlayback.loopActive=audibleLoop.active && audibleLoop.end>audibleLoop.start;
                if(localPlayback.loopActive){
                    localPlayback.loopStart=double(audibleLoop.start)/track->sampleRate;
                    localPlayback.loopEnd=double(audibleLoop.end)/track->sampleRate;
                }
                localPlayback.audiblePositionValid=true;
            }
            // The worker advises whether any connected peer still requires
            // the legacy 1,536-bin moving window; avoid preparing it for a
            // group using the acknowledged static waveform cache protocol.
            const auto previousPeer=deckLink.snapshot();
            const bool legacyDetailNeeded=previousPeer.needsLegacyDetail;
            auto localLink=linkPublisher.prepare(localPlayback,false,
                Settings::kVersion,Clock::now(),&currentMetadata,&path,legacyDetailNeeded);
            // The displayed physical unit number is not the network identity.
            // Send once per sample in the optional v91 detailed-wave packet.
            static const int physicalLinkNumber=[] {
                const std::string label=CuesUi::physicalDeckLabel();
                return label.size()>=7?std::clamp(std::atoi(label.c_str()+5),0,99):0;
            }();
            localLink.deviceNumber=static_cast<std::uint8_t>(physicalLinkNumber);
            localLink.linkedTempoApplied=previousTempoApplied;
            localLink.linkedBeatLocked=previousLinkedTempoLocked;
            const bool linkChanged=deckLink.tick(localLink);
            const auto linked=deckLink.snapshot();
            // Continuous stopped scrub updates are visual-only and must wake
            // the peer display immediately, without redrawing stationary local
            // WaveTiles. If identity/metadata/grid/status also changes, fall
            // back to the normal full-detail invalidation.
            const bool stoppedPeerScrub=linkChanged && bool(track) &&
                previousPeer.connected && linked.connected &&
                previousPeer.peerId==linked.peerId &&
                previousPeer.peerMotionValid && linked.peerMotionValid &&
                !previousPeer.peerPlaying && !linked.peerPlaying &&
                previousPeer.motion.trackGeneration==linked.motion.trackGeneration &&
                previousPeer.motion.eventSerial==linked.motion.eventSerial &&
                previousPeer.motion.gridRevision==linked.motion.gridRevision &&
                previousPeer.motion.looping==linked.motion.looping &&
                previousPeer.hasTrackView==linked.hasTrackView &&
                previousPeer.staticWave==linked.staticWave &&
                previousPeer.peerGridAtomic==linked.peerGridAtomic &&
                previousPeer.peerBpm==linked.peerBpm &&
                previousPeer.syncMode==linked.syncMode &&
                previousPeer.localMaster==linked.localMaster &&
                previousPeer.peerReportFresh==linked.peerReportFresh &&
                previousPeer.remoteMotionRedrawEvents!=linked.remoteMotionRedrawEvents &&
                std::abs(previousPeer.motion.sourceSeconds-linked.motion.sourceSeconds)>0.002;
            viewState.remoteScrubDirty=stoppedPeerScrub;
            if(linkChanged) {
                viewState.encoderHeaderDirty=true;
                viewState.footerDirty=true; // read-only link chain is in status row
                if(!stoppedPeerScrub)detailDirty=true;
            }
            // Keep the original loading sine moving even when no Player runs.
            // The old renderer only repainted it when an unrelated dirty flag
            // changed, leaving the animation visually frozen.
            if(trackSession.loadingTrack && !trackSession.pendingSeamlessLoad &&
               !browsing && !settingsOpen) {
                const int loadingTick=int(std::chrono::duration_cast<
                    std::chrono::milliseconds>(Clock::now().time_since_epoch()).count()/50);
                if(loadingTick!=lastLoadingAnimFrame) {
                    lastLoadingAnimFrame=loadingTick;viewState.detailDirty=true;
                }
            } else lastLoadingAnimFrame=-1;
            static bool priorQualifiedBeatLock=false;
            if(!linked.connected || linked.syncMode!=DeckLink::SyncMode::Beat)
                priorQualifiedBeatLock=false;
            // Keep the 1.6 s LINK LOST border pulse visible even if local
            // transport is paused; no audio-thread timers or I/O.
            if(linked.staleWaveform && !browsing && !settingsOpen) {
                static int lastLossTick=-1;
                const int tick=int(std::chrono::duration_cast<std::chrono::milliseconds>(
                    Clock::now().time_since_epoch()).count()/90);
                if(tick!=lastLossTick){lastLossTick=tick;detailDirty=true;}
            }
            if(Clock::now()-lastUpdateStatus>=std::chrono::milliseconds(400)) {
                lastUpdateStatus=Clock::now();
                preparedUpdate=DeckLinkUpdateUi::read(releaseStore+"/update-ui.state");
                if(settingsOpen && uiSettings.settingsTab==5){
                    auto pair=DeckUsbPair::read(usbPairConfig);
                    if(pair!=pendingMacPair){pendingMacPair=std::move(pair);viewState.detailDirty=true;}
                }

            }
            const bool updateVisible=!updateOffer().empty() &&
                (!player || !player->playing()) && !autoPilot.inFlight() &&
                !confirmingLiveLoad;
            const std::string phase=preparedUpdate.valid?preparedUpdate.state:std::string{};
            const int percent=preparedUpdate.progress;
            if(updateVisible!=previousUpdateVisible ||
               (updateVisible && (phase!=lastUpdatePhase || percent!=lastUpdatePercent))) {
                viewState.fullRedraw=true;
                previousUpdateVisible=updateVisible;
                lastUpdatePhase=phase;
                lastUpdatePercent=percent;
            }
            bool linkedTempoLocked=false;
            bool linkedTempoApplied=false;
            bool linkedPhaseValid=false;
            double linkedPhaseErrorBeats=0.0;
            if(player) {
                // Sync target remains a control-thread decision, not an audio
                // callback read. The phase trim is published exactly once.
                const auto follower=DeckLinkRuntime::planFollower(linked,localLink,bool(track));
                linkedPhaseValid=follower.phaseValid;
                linkedPhaseErrorBeats=follower.phaseErrorBeats;
                if(follower.setTempo) {
                    // An incompatible track must never silently turn off the
                    // plug-and-play SYNC preference. Recheck on the next track.
                    if(player->setLinkedTempoBpm(follower.bpm)) {
                        linkedTempoApplied=true;
                        linkedTempoLocked=follower.beatMode && linkedLockTracker.tick(true,
                            follower.phaseValid,follower.phaseErrorBeats,Clock::now());
                    }
                }
                player->setLinkedPhaseObservation(follower.phaseErrorBeats,
                    follower.phaseValid && linkedTempoApplied,
                    follower.beatMode && linkedTempoApplied,
                    linkedTempoLocked,linked.peerAgeSeconds);
                if(!follower.setTempo || !follower.phaseValid)
                    linkedLockTracker.reset();
            } else linkedLockTracker.reset();
            if(player && prefs.debugInfo && linked.connected &&
               linked.syncMode==DeckLink::SyncMode::Beat) {
                static Clock::time_point lastSyncDiag{};
                const auto diagNow=Clock::now();
                if(diagNow-lastSyncDiag>=std::chrono::seconds(5)) {
                    lastSyncDiag=diagNow;
                    const auto d=player->linkSyncDiagnostics();
                    std::fprintf(stderr,
                        "DECK LINK AUDIO v2.2.93 phase=%.4f beats trim=%.4f%% peer_age=%.0fms keylock_routes=%llu alsa_xruns=%u\n",
                        d.phaseErrorBeats,d.appliedTrimPercent,d.peerAgeMs,
                        static_cast<unsigned long long>(d.routeTransitions),d.underruns);
                }
            }
            if(previousTempoApplied!=linkedTempoApplied){
                viewState.bpmDirty=true;
                viewState.footerDirty=true;
                viewState.encoderHeaderDirty=true;
            }
            previousTempoApplied=linkedTempoApplied;
            // Mixxx-inspired separation: report base grid vs effective tempo
            // and phase-lock state independently. UI thread only, gated by
            // existing DEBUG INFO. Do not report this as real audio alignment.
            if(player && prefs.debugInfo) {
                static int previousDecision=-1,previousSchedule=-1;
                const int decision=player->seamlessDecision();
                const int state=player->seamlessStatus();
                if(state!=previousSchedule || decision!=previousDecision) {
                    previousSchedule=state;previousDecision=decision;
                    if(state==2 || state==4){
                        const auto* incoming=trackSession.seamlessAwaitingSong &&
                            trackSession.seamlessAwaitingSong->song?
                            trackSession.seamlessAwaitingSong->song.get():nullptr;
                        std::fprintf(stderr,
                            "MUSICAL PLAN state=%d reason=%s A_base=%.3f A_effective=%.3f A_conf=%.3f A_manual=%d B_base=%.3f B_conf=%.3f B_manual=%d\n",
                            state,DeckAudio::LiveSeamlessMixer::decisionName(
                               static_cast<DeckAudio::LiveSeamlessMixer::Decision>(decision)),
                            track?track->beatGrid.bpm:0.0,player->tempoBpm(),
                            track?track->beatGrid.confidence:0.0,
                            track&&track->beatGrid.manual?1:0,
                            incoming?incoming->beatGrid.bpm:0.0,
                            incoming?incoming->beatGrid.confidence:0.0,
                            incoming&&incoming->beatGrid.manual?1:0);
                    }
                }
            }
            const bool beatAcquiring=linked.connected && linked.peerMaster &&
                linked.syncMode==DeckLink::SyncMode::Beat &&
                linked.syncEnabled && !linkedTempoLocked && player && player->playing() &&
                linked.peerPlaying;
            const bool beatSyncLost=beatAcquiring && priorQualifiedBeatLock;
            const bool beatSyncing=beatAcquiring && !priorQualifiedBeatLock;
            // Track/phase diagnostics are published on UI thread only.
            // Capture actual lock loss reason data; never alter servo/timing.
            if(prefs.debugInfo) {
                static bool lastLoggedBeatLocked=false;
                if(beatSyncLost || linkedTempoLocked!=lastLoggedBeatLocked){
                    std::fprintf(stderr,
                        "DECK LINK LOCK event=%s gen=%u grid_rev=%u valid=%d phase_err=%.5f peer_age=%.1fms peer_bpm=%.3f effective=%.3f mode=%d\n",
                        beatSyncLost?"BEAT_LOST":(linkedTempoLocked?"LOCKED":"UNLOCKED"),
                        linked.hasTrackView?linked.trackView.generation:0,
                        linked.peerGridRevision,linkedPhaseValid?1:0,
                        linkedPhaseErrorBeats,linked.peerAgeSeconds*1000.0,
                        linked.peerBpm,player?player->tempoBpm():0.0,
                        int(linked.syncMode));
                    lastLoggedBeatLocked=linkedTempoLocked;
                }
            }
            if(linkedTempoLocked)priorQualifiedBeatLock=true;
            if(!linked.connected || linked.syncMode!=DeckLink::SyncMode::Beat)
                priorQualifiedBeatLock=false;
            const bool tempoWithinLimit=!player || !track || linked.peerBpm<=0.0 ||
                player->originalBpm()<=0.0 ||
                (linked.peerBpm>=player->originalBpm()*0.8 &&
                 linked.peerBpm<=player->originalBpm()*1.2);
            const auto uiSync=UiSyncPresentation::resolve({
                linked.connected,linked.localMaster,linked.staleWaveform,
                static_cast<int>(linked.syncMode),linked.syncEnabled,
                linkedTempoApplied,linkedTempoLocked,beatAcquiring,
                beatSyncLost,tempoWithinLimit});
            static auto previousUiSync=UiSyncPresentation::State::Disconnected;
            if(uiSync.state!=previousUiSync){
                viewState.encoderHeaderDirty=true;viewState.bpmDirty=true;
                viewState.footerDirty=true;
                if(settingsOpen)viewState.fullRedraw=true;
                previousUiSync=uiSync.state;
            }
            if(linkedTempoLocked!=previousLinkedTempoLocked) {
                viewState.bpmDirty=true;
                viewState.encoderHeaderDirty=true;
                viewState.detailDirty=true;
                viewState.footerDirty=true;
                previousLinkedTempoLocked=linkedTempoLocked;
            }
            static bool lastLinkStatus=false,lastLinkChain=false,lastLinkStale=false;
            const bool linkNow=linked.connected,chainNow=linkedTempoLocked||linkedTempoApplied;
            const bool staleNow=linked.staleWaveform;
            if(linkNow!=lastLinkStatus||chainNow!=lastLinkChain||staleNow!=lastLinkStale){
                viewState.footerDirty=true;viewState.bpmDirty=true;
                viewState.encoderHeaderDirty=true;
                lastLinkStatus=linkNow;lastLinkChain=chainNow;lastLinkStale=staleNow;
            }
            // Only animate what is visible. Audio in Browse/Settings does not
            // cause a busy frame loop: the waveform is currently hidden.
            const bool waveformVisible=track && !browsing && !settingsOpen && !confirmingLiveLoad;
            const bool animationActive=(waveformVisible && (scrubStarted || (player && player->transportMoving()))) ||
                (!browsing && !settingsOpen && !confirmingLiveLoad &&
                 RemoteView::visible(uiSettings.remoteViewMode) && linked.connected && linked.peerPlaying) ||
                (waveformVisible && trackSession.seamlessAwaiting && player && player->seamlessStatus()==2) ||
                (waveformVisible && waveScene.bridgeActive(Clock::now())) ||
                (revealingTrack && !browsing && !settingsOpen) ||
                (trackSession.loadingTrack && !browsing && !settingsOpen);
            const auto now=Clock::now();
            const auto remaining=std::chrono::duration_cast<std::chrono::milliseconds>(nextFallbackFrame-now).count();
            // On KMS finishFrame() waits for the *actual* page flip. No second
            // software cadence or timer is allowed to drift against VBlank.
            const int timeout=animationActive && vblankPaced ? 0 :
                animationActive ? static_cast<int>(std::clamp<long long>(remaining,0,16)) : 50;
            pollfd fds[3]{};
            int count=0,keyboardIndex=-1,touchIndex=-1;
            if(keyboard) {keyboardIndex=count;fds[count++]={STDIN_FILENO,POLLIN,0};}
            if(touch.fd()>=0) {touchIndex=count;fds[count++]={touch.fd(),POLLIN,0};}
            if(midi.fd()>=0)fds[count++]={midi.fd(),POLLIN,0};
            const int response=::poll(fds,count,timeout);
            if(response<0 && errno!=EINTR) throw std::runtime_error("input poll failed");
            if(response>0 && keyboardIndex>=0 && (fds[keyboardIndex].revents&POLLIN)) {
                char chars[64];
                const auto n=::read(STDIN_FILENO,chars,sizeof chars);
                for(ssize_t i=0;i<n;++i) {
                    const char key=chars[i];
                    const auto intent=InputRouter::keyboard(key,{
                        confirmGridExit,confirmingLiveLoad,gridEditing,browsing});
                    if(intent.action!=UiAction::None)act({intent.action});
                    if(intent.hasDeckCommand)applyDeckCommand(intent.command);
                    using Special=InputRouter::KeyboardSpecial;
                    switch(intent.special) {
                    case Special::GridBpmDown:case Special::GridBpmUp:
                        if(track && track->beatGrid.estimated) {
                            if(player && player->loop().active)toggleLoop();
                            track->beatGrid.bpm=std::clamp(track->beatGrid.bpm+
                               (intent.special==Special::GridBpmDown?-1:1)*Settings::kBpmManualStep,
                               Settings::kBpmMin,Settings::kBpmMax);
                            track->beatGrid.manual=true;
                            if(!metadata.saveGrid(currentTrackIdentity,track->beatGrid))
                                std::cerr<<"Grid UNSAVED: queue full\n";
                            bpmDirty=detailDirty=true;
                        }break;
                    case Special::GridPhaseBack:case Special::GridPhaseForward:
                        if(track && track->beatGrid.estimated) {
                            if(player && player->loop().active)toggleLoop();
                            track->beatGrid.firstBeatSeconds+=
                                (intent.special==Special::GridPhaseBack?-1:1)*Settings::kGridPhaseStepSeconds;
                            track->beatGrid.manual=true;
                            if(!metadata.saveGrid(currentTrackIdentity,track->beatGrid))
                                std::cerr<<"Grid UNSAVED: queue full\n";
                            detailDirty=true;
                        }break;
                    case Special::GridReset:
                        if(track) {
                            if(player && player->loop().active)toggleLoop();
                            // v2.2.118h4: back to the stick's prepared grid when the track has one
                            if(!(currentTrackIdentity.path[0] &&
                                 loadStickBeatGrid(currentTrackIdentity.path,track->beatGrid)))
                                estimateBeatGrid(*track);
                            if(!metadata.saveGrid(currentTrackIdentity,track->beatGrid,true))
                                std::cerr<<"Grid reset UNSAVED: queue full\n";
                            bpmDirty=detailDirty=true;
                        }break;
                    case Special::Quit:exitRequested=1;break;
                    case Special::None:break;
                    }
                }
            }
            if(response>0 && touchIndex>=0 && (fds[touchIndex].revents&POLLIN)) {
                TouchPoint point{};
                while(touch.readEvent(point)) {
                    // The lower linked waveform is a read-only visual; never
                    // seek, scratch or change loops on the remote strip.
                    if(point.kind==TouchKind::Down) {
                        const bool mixing=track && player &&
                            (trackSession.pendingSeamlessLoad || trackSession.seamlessAwaiting) &&
                            (!trackSession.autoPilotRequestedLoad || trackSession.seamlessAwaiting);
                        const auto view=MultitrackLayout::choose(mixing,
                            RemoteView::visible(uiSettings.remoteViewMode) && (linked.connected || linked.staleWaveform),
                            RemoteView::strip(uiSettings.remoteViewMode));
                        const int localLaneHeight=MultitrackLayout::lanes(view).a.h;
                        const bool canToggle=waveformVisible && track &&
                            (linked.connected || linked.staleWaveform) &&
                            !browsing && !settingsOpen && !gridEditing && !confirmingLiveLoad &&
                            navView!=LiveCuesNav::View::Fx && !keyShift.open;
                        if(canToggle && Ui::remoteToggleHit(point.x,point.y,
                                localLaneHeight,mixing)) {
                            // ONLY the dedicated lower REMOTE row is toggled.
                            // Never replace or refocus the LOCAL overview.
                            uiSettings.remoteViewMode=RemoteView::next(uiSettings.remoteViewMode);
                            persistUserSettings();
                            viewState.fullRedraw=true;viewState.overviewDirty=true;
                            viewState.detailDirty=viewState.footerDirty=true;
                            remoteStripTouchBlocked=true;
                            continue;
                        }
                        const bool editArea=
                            Ui::actionControlHit(0,point.x,point.y,localLaneHeight) ||
                            Ui::actionControlHit(1,point.x,point.y,localLaneHeight) ||
                            Ui::actionControlHit(2,point.x,point.y,localLaneHeight);
                        remoteStripTouchBlocked=(mixing && editArea) ||
                            ((linked.connected || linked.staleWaveform) &&
                              RemoteView::visible(uiSettings.remoteViewMode) &&
                              !browsing && !settingsOpen && !gridEditing &&
                              MultitrackLayout::protectedRemote(view,point.x,point.y));
                    }
                    if(remoteStripTouchBlocked) {
                        if(point.kind==TouchKind::Up)remoteStripTouchBlocked=false;
                        continue;
                    }
                    if(modulinoControls.shift())modulinoControls.markShiftUsed();
                    // Snapshot the control owner on DOWN; never route from UP alone.
                    const auto touchHit=[&](int x,int y)->Hit {
                        if(updateVisible && y<Ui::barY) {
                            const auto choice=DeckLinkUpdateUi::hit(x,y);
                            if(choice==DeckLinkUpdateUi::Decision::Outside)
                                return {UiAction::None};
                            if(choice==DeckLinkUpdateUi::Decision::Accept &&
                               preparedUpdate.ready())return {UiAction::PeerUpdateAccept};
                            return choice==DeckLinkUpdateUi::Decision::Later?
                                Hit{UiAction::PeerUpdateLater}:Hit{UiAction::None};
                        }
                        if(keyShift.open)return UiKeyShift::hit(x,y,keyShift);
                        // Owner of the navigation row is ALWAYS the shared
                        // five-rectangle model, even above Browse and Settings.
                        if(!confirmingLiveLoad && !confirmGridExit) {
                            // Touch geometry matches the renderer exactly;
                            // black button gutters intentionally have no action.
                            if(y>=Ui::barY && y<Ui::barY+Ui::barH)
                                return LiveCuesTouch::hit(x,y,navView,cuesBank);
                            if(navView==LiveCuesNav::View::Fx && !browsing && !settingsOpen &&
                               !gridEditing && !trackSession.loadingTrack &&
                               y>=0 && y<Ui::barY) {
                                // Popup owns touches above the nav while open.
                                // An outside tap closes it, NEVER seeks or toggles a loop.
                                const Hit effect=FxOverlay::hit(x,y);
                                return effect.action!=UiAction::None?effect:Hit{UiAction::FxDismiss};
                            }
                            if(navView==LiveCuesNav::View::Cues && !browsing && !settingsOpen &&
                               !(track && waveformVisible && !gridEditing &&
                                  ((linked.connected || linked.staleWaveform) ||
                                    trackSession.pendingSeamlessLoad || trackSession.seamlessAwaiting))) {
                                const int bank=CuesUi::bankHit(x,y);
                                if(bank==0)return {UiAction::CuesBankA};
                                if(bank==1)return {UiAction::CuesBankB};
                            }
                        }
                        if(!track && !trackSession.loadingTrack && !error.empty() && trackSession.recoveryTrack &&
                           !browsing && !settingsOpen &&
                           TrackLoadLifecycle::reloadHit(x,y))
                            return {UiAction::ReloadPrevious};
                        return confirmingLiveLoad?hitLiveLoadConfirm(x,y):
                               confirmGridExit?hitGridExitDialog(x,y):
                               gridEditing?hitGridEditor(x,y):
                               browsing?hitBrowser(x,y,!browser.folder.empty(),library.usbReady(),browser.usbSource):
                               settingsOpen?hitSettings(x,y,uiSettings.settingsFirst,uiSettings.waveformMode,uiSettings.settingsTab):
                               hitMain(x,y,(RemoteView::visible(uiSettings.remoteViewMode) && linked.connected &&
                               !(trackSession.pendingSeamlessLoad || trackSession.seamlessAwaiting))?
                               MultitrackLayout::lanes(MultitrackLayout::choose(false,true,
                                   RemoteView::strip(uiSettings.remoteViewMode))).a.h:Ui::detailH,
                               !(trackSession.pendingSeamlessLoad || trackSession.seamlessAwaiting));
                    };
                    const auto inputView=touchView();
                    const Hit currentHit=point.kind==TouchKind::Move?
                        Hit{}:touchHit(point.x,point.y);
                    const bool wasLoopDrag=touchGestures.loopDragHeld();
                    const bool wasScrub=touchGestures.scrubHeld();
                    const auto routed=touchGestures.consume(point,inputView,currentHit);
                    if(point.kind==TouchKind::Down && touchGestures.scrubHeld() &&
                       player && track && player->beginScrub()) {
                        scrubStarted=true;
                        scrubAnchor.firstFrame=static_cast<double>(player->position());
                        scrubDisplay.begin(scrubAnchor.firstFrame,Clock::now());
                        scrubAnchor.framesPerPixel=track->sampleRate*
                            VinylScrub::secondsAcrossScreen(static_cast<VinylScrub::Precision>(
                                uiSettings.scratchPrecision))/Ui::detailW;
                    }
                    if(point.kind==TouchKind::Up && wasScrub && scrubStarted && player) {
                        if(routed.type==InputRouter::TouchAction::ScrubEnd && track)
                            player->moveScrub(scrubAnchor.target(routed.deltaX,track->totalFrames));
                        player->endScrub();
                        scrubStarted=false;
                        scrubDisplay.end();
                        detailDirty=overviewDirty=true;
                    } else if(point.kind==TouchKind::Move && wasScrub &&
                              !touchGestures.scrubHeld() && scrubStarted && player) {
                        player->endScrub();
                        scrubStarted=false;
                        scrubDisplay.end();
                    }
                    if(point.kind==TouchKind::Down && touchGestures.loopDragHeld()) {
                        loopDragCameraAnchor=lastLoopTouchCamera;
                        loopDragMoved=false;
                        loopCameraSettling=false;
                    }
                    if(point.kind==TouchKind::Up && wasLoopDrag && loopDragMoved &&
                       loopDragCameraAnchor.locked) {
                        loopCameraSettleFrom=loopDragCameraAnchor;
                        loopCameraSettleStart=Clock::now();
                        loopCameraSettling=true;
                    }
                    if(!touchGestures.loopDragHeld())loopDragCameraAnchor={};
                    switch(routed.type) {
                    case InputRouter::TouchAction::ScrubMove:
                        if(scrubStarted && player && track) {
                            const double exact=scrubAnchor.target(routed.deltaX,track->totalFrames);
                            player->moveScrub(exact);
                            scrubDisplay.target(exact,Clock::now());
                            detailDirty=overviewDirty=true;
                        }
                        break;
                    case InputRouter::TouchAction::ScrubEnd:
                        // The gesture was ended above, after publishing its
                        // final sample-accurate target. No waveform tap/seek.
                        break;
                    case InputRouter::TouchAction::GridMove: {
                        // Rightward finger motion shifts grid phase left;
                        // no audio seek or display calls inside InputRouter.
                        const double span=gridView().spanSeconds;
                        const double seconds=-routed.deltaX*span/Ui::detailW;
                        gridEditor.shiftSeconds(seconds);
                        gridAnchorSeconds+=seconds;
                        gridVisibleStart=GridZoomAnchor::startForCenter(gridAnchorSeconds,span);
                        if(track)track->beatGrid=gridEditor.draft();
                        detailDirty=footerDirty=true;
                        break;
                    }
                    case InputRouter::TouchAction::LoopMove:
                        if(player && track && player->loop().active &&
                           navigationGrid().valid() && routed.steps!=0 &&
                           !trackSession.pendingSeamlessLoad &&
                           !trackSession.seamlessAwaiting && !autoPilot.inFlight()) {
                            if(player->slideActiveLoop(routed.steps,navigationGrid())) {
                                touchGestures.confirmLoopMove(routed.steps);
                                loopDragMoved=true;
                                detailDirty=overviewDirty=footerDirty=true;
                            }
                        }
                        break;
                    case InputRouter::TouchAction::SettingsScroll:
                        uiSettings.settingsSelected=std::clamp(uiSettings.settingsSelected+routed.steps,0,
                            settingsTabRowCount(uiSettings.waveformMode,uiSettings.settingsTab)-1);
                        uiSettings.settingsFirst=std::clamp(uiSettings.settingsSelected-(Ui::settingsRows-1),0,
                            std::max(0,settingsTabRowCount(uiSettings.waveformMode,uiSettings.settingsTab)-Ui::settingsRows));
                        detailDirty=true;
                        break;
                    case InputRouter::TouchAction::BrowserScroll:
                        if(!browser.files.empty()) {
                            browser.scroll(routed.steps);browserDirty=true;
                        }
                        break;
                    case InputRouter::TouchAction::GridCommit:
                        updateGridGuide(true);
                        break;
                    case InputRouter::TouchAction::OverviewSeek:
                        // One uiSettings.quantized/unquantized navigation on finger UP.
                        act({UiAction::Seek,routed.fraction});
                        break;
                    case InputRouter::TouchAction::WaveformTap:
                        // Toggle the prepared live loop at the CURRENT audible
                        // position; a waveform tap must never seek the track.
                        // Preserve the previously selected encoder mode.
                        if(uiSettings.waveformTouchMode==WaveformTouch::Mode::TapLoop &&
                           !gridEditing && !trackSession.loadingTrack && !autoPilot.inFlight() &&
                           !(trackSession.pendingSeamlessLoad || trackSession.seamlessAwaiting) &&
                           !(trackSession.seamlessAwaiting && player && player->seamlessStatus()==2))
                            toggleLoop();
                        break;
                    case InputRouter::TouchAction::Tap:
                        if(routed.selectedBrowserRow) {
                            requestLoad(browser.selected);
                            browserDirty=true;
                        } else if(routed.hit.action==UiAction::PlayStop) {
                            applyDeckCommand({DeckCommandType::TogglePlay,1,1,DeckCommandSource::Touch});
                        } else if(routed.hit.action==UiAction::ToggleQuantize) {
                            applyDeckCommand({DeckCommandType::ToggleQuantize,1,1,DeckCommandSource::Touch});
                        } else act(routed.hit);
                        break;
                    case InputRouter::TouchAction::None: break;
                    }
                }
            }
            if(touchGestures.keylockHold(touchView(),Clock::now()))act({UiAction::KeyShiftOpen});

            const auto midiBatch=midi.tick();
            for(std::size_t i=0;i<midiBatch.count;++i)applyDeckCommand(midiBatch.commands[i]);

            // Modulino A=PLAY, B=transport CUE, C=SHIFT. Events are produced
            // by the SAME I2C worker as the Adafruit encoder. Never access I2C
            // from this UI thread and never access either device from audio.
            if(encoder.modulinoEventOverflow()) {
                // A lost release must never leave pitch bent or preview held.
                modulinoControls.disconnected();
                if(player)player->setPitchNudgeDirection(0);
                if(player && cuePreviewActive)player->returnToTransportCue();
                cuePreviewActive=false;
            }
            ModulinoButtonEvent buttonEvent{};
            while(encoder.consumeModulino(buttonEvent)) {
                const auto command=modulinoControls.edge(buttonEvent.button,buttonEvent.pressed);
                // SHIFT tap has no audio dependency: bank switching must also
                // work when no song is loaded. A SHIFT chord never generates it.
                if(command==ModulinoAction::ShiftTap) {
                    if(navView==LiveCuesNav::View::Cues && !browsing && !settingsOpen && !gridEditing) {
                        cuesBank=1-cuesBank;
                        ++navEpoch; // invalidate pending touch gesture owner
                        detailDirty=transportDirty=footerDirty=true;
                        encoderHeaderDirty=true;
                        // LED update follows the same bank-state path as touch A/B.
                        std::cout<<"CUES bank "<<(cuesBank==0?'A':'B')<<" (SHIFT click)\n";
                    }
                    continue;
                }
                if(!player || !track || trackSession.loadingTrack) {
                    if(player)player->setPitchNudgeDirection(0);
                    cuePreviewActive=false;
                    continue;
                }
                switch(command) {
                case ModulinoAction::Play:
                    if(cuePreviewActive) {
                        // Pressing PLAY while holding CUE latches playback.
                        cuePreviewActive=false;
                    } else {
                        applyDeckCommand({DeckCommandType::TogglePlay,1,1,DeckCommandSource::Modulino});
                    }
                    transportDirty=true;
                    break;
                case ModulinoAction::CueDown:
                    if(trackSession.seamlessAwaiting && player && player->seamlessStatus()==2)break;
                    if(player->transportCueFrame()<0) {
                        // Don't set transport cue during active audible motion.
                        if(!player->transportMoving())player->setTransportCueAtCurrent();
                    } else if(player->playing() && !cuePreviewActive) {
                        player->returnToTransportCue();
                    } else if(!player->transportMoving() && !player->atTransportCue()) {
                        // CDJ-style: stopped AWAY from the initialized transport
                        // CUE sets a new MANUAL point. Never use the cached
                        // Auto Cue position again until a new track is loaded.
                        player->setTransportCueAtCurrent();
                    } else {
                        // New press supersedes an unfinished CueFade/drain.
                        // NEVER gate it on transportMoving(): that dropped
                        // rapid taps and made CUE appear locked until PLAY.
                        cuePreviewActive=player->startTransportCuePreview();
#if defined(DECK001_B12_TRACE)
                        if(cuePreviewActive)b12Trace.begin(Clock::now());
#endif
                    }
                    detailDirty=overviewDirty=transportDirty=true;
                    break;
                case ModulinoAction::CueUp:
                    if(cuePreviewActive) {
                        cuePreviewActive=false;
                        player->returnToTransportCue();
                        detailDirty=overviewDirty=transportDirty=true;
                    }
                    break;
                case ModulinoAction::NudgeDown:
                    if(!(trackSession.seamlessAwaiting && player && player->seamlessStatus()==2))
                        player->setPitchNudgeDirection(-1);
                    break;
                case ModulinoAction::NudgeUp:
                    if(!(trackSession.seamlessAwaiting && player && player->seamlessStatus()==2))
                        player->setPitchNudgeDirection(1);
                    break;
                case ModulinoAction::NudgeStop:
                    player->setPitchNudgeDirection(0);break;
                case ModulinoAction::ShiftTap:break;
                case ModulinoAction::None:break;
                }
            }
            if(player && !modulinoControls.shift() && modulinoControls.nudgeDirection()==0 &&
               player->pitchNudgeDirection()!=0)player->setPitchNudgeDirection(0);

            physicalCtx.loadingTrack=trackSession.loadingTrack;
            UiPhysicalActions::tick(physicalCtx);
            // Metadata process and scanner never share our ALSA crash domain.
            // All receive/send work here is bounded MSG_DONTWAIT socket IPC.
            // AUTO PILOT v1: frozen current-folder playlist, non-blocking
            // preparation and the SAME Player::offerSeamless pathway as manual LOAD.
            // No extra audio worker or decode work in this thread.
            if(autoPilot.state()==AutoPilot::State::Enabled && track && player &&
               player->playing() && !trackSession.loadingTrack && !trackSession.seamlessAwaiting &&
               !cuePreviewActive && !confirmingLiveLoad && !player->loop().active){
                const auto remaining=AutoPilot::remainingSeconds(track->totalFrames,
                    double(player->position()),track->sampleRate,
                    player->originalBpm(),player->tempoBpm());
                if(remaining<=AutoPilot::preparationLeadSeconds(player->tempoBpm())){
                    const std::string next=autoPilot.next();
                    if(autoPilot.begin(next)){
                        startLoad(next,false,true);
                        footerDirty=true;detailDirty=true;
                        std::cout<<"AUTO PILOT: preparing "<<next<<'\n';
                    }
                }
            }
            if(autoPilot.enabled() && !autoPilot.inFlight() && player &&
               !player->playing() && !trackSession.loadingTrack){
                autoPilot.disengage();footerDirty=detailDirty=true;
            }
            // UI-thread TrackSession polls decoder, metadata and seamless handover.
            // Never enters the ALSA worker; callbacks retain the existing
            // source promotion and display synchronization behavior.
            const auto loadEvents=trackSession.tick(metadata,player.get(),track,
                autoPilot,uiSettings.keylockMode,sessionHooks,
                uiSettings.keylockEngine,uiSettings.keylockFftBackend);
            if(!loadEvents.error.empty())error=loadEvents.error;
            if(loadEvents.redraw)detailDirty=overviewDirty=footerDirty=true;
            if(loadEvents.fullRedraw)clearDirty();
            if(keyShift.open && !keyShiftAvailable()) {keyShift.close();++navEpoch;detailDirty=true;}
            scanner.tick(library.connected());
            if(library.poll()) {
                if(library.ready()) {
                    browser.replaceEntries(library.entries());
                    browserDirty=true;
                }
                if(library.usbReady()!=previousUsbReady) {
                    previousUsbReady=library.usbReady();
                    ++unknownUsbGeneration;
                    fullRedraw=true;
                    // Browse refresh is asynchronous; never probe USB here.
                    if(browser.usbSource) {
                        if(!library.usbReady()) {
                            browser.clearRows();browser.folder.clear();
                        }
                        refreshLibrary();
                    }
                }
                // Preparing -> ready and identity changes also repaint status.
                fullRedraw=true;
            }
            // Also handle status consumed by another nonblocking library.request().
            // No removable-media I/O occurs in this process.
            if(loadedTrackFromUsb && loadedTrackUsbId.empty() &&
               library.usbReady() && !usbLost)
                loadedTrackUsbId=library.usbIdentity();
            const bool newUsbLost=UsbIndicator::missingOriginal(
                loadedTrackFromUsb,loadedTrackUsbId,library.usbReady(),
                library.usbIdentity(),usbLost);
            if(usbLost!=newUsbLost){usbLost=newUsbLost;fullRedraw=true;}
            const auto browserStatus=[&]() -> std::string {
                return AppBrowserStatus::message(library.connected(),
                                                  library.ready(),library.error());
            };
            const auto tick=Clock::now();
            // One immutable status snapshot is shared by full/footer and icon-only
            // drawing. This prevents intermittent full-brightness flashes.
            const bool planeVisible=bool(track) && !browsing && !settingsOpen &&
                !gridEditing && !confirmingLiveLoad;
            const bool fullFrameAtStart=fullRedraw;
            const bool footerDirtyAtStart=footerDirty;
            performanceMonitor.tickKeylockDiagnostics(player.get(),tick);
            const double revealFraction=revealingTrack?std::clamp(
                std::chrono::duration<double>(tick-revealStart).count()/
                std::chrono::duration<double>(kRevealDuration).count(),0.0,1.0):1.0;
            if(revealingTrack && revealFraction>=1.0) {
                revealingTrack=false;detailDirty=overviewDirty=true;
            }
            if(waveScene.bridgeActive(tick) && !browsing && !settingsOpen) {
                detailDirty=overviewDirty=true; // Only for a bounded handover bridge.
            }
            const bool frameDue=vblankPaced ? animationActive : tick>=nextFallbackFrame;
#if defined(DECK001_B12_TRACE)
            bool b12DetailRedrawn=false;
            const bool b12DetailDirtyBefore=detailDirty;
#endif
            if(!vblankPaced && frameDue) {
                // Skip a missed fallback frame; never render a catch-up burst.
                nextFallbackFrame=tick+fallbackInterval;
            }
            // Read position and uiSettings.quantized-transition countdown coherently.
            // Neither the display nor its ghost playhead schedules audio.
            const VisualTransport visual=player?player->visualTransport():VisualTransport{};
            const auto position=visual.position;
            const double ghostSeconds=visual.pendingQuantizedJump ?
                visual.secondsUntilJump : 0.0;
            const bool running=player && player->playing();
            const bool transportMoving=player && player->transportMoving();
            const bool waveformMoving=transportMoving || scrubStarted;
            const auto loop=player?player->loop():LoopRegion{};
            const auto storedCue=player?player->transportCueFrame():-1;
            const double transportCueSeconds=track && storedCue>=0 && track->sampleRate>0 ?
                static_cast<double>(storedCue)/track->sampleRate : -1.0;
            const auto ledMillis=std::chrono::duration_cast<std::chrono::milliseconds>(
                Clock::now().time_since_epoch()).count();
            const auto usbIndicator=UsbIndicator::show(library.usbReady(),
                library.usbPreparing() || (browser.usbSource && library.usbReady() && !library.ready()),usbLost);
            const bool usbBlinking=usbIndicator==UsbIndicator::State::Preparing ||
                                   usbIndicator==UsbIndicator::State::MissingOriginal;
            const bool usbBright=usbIndicator==UsbIndicator::State::Preparing ?
                ((ledMillis/350)%2==0) : ((ledMillis/500)%2==0);
            const int usbPulsePhase=usbBlinking?(usbBright?1:0):-1;
            const bool usbHeaderDirty=usbPulsePhase!=lastUsbPulsePhase;
            lastUsbPulsePhase=usbPulsePhase;
            // Temporary waveform encoder assignment is DISPLAY ONLY. Both
            // zoom and beat jump revert immediately on finger release.
            const bool waveformHoldTemporary=touchGestures.waveformHeld(navEpoch) &&
                !gridEditing && uiSettings.waveformTouchMode!=WaveformTouch::Mode::TapLoop;
            const bool waveformHoldBeat=waveformHoldTemporary &&
                uiSettings.waveformTouchMode==WaveformTouch::Mode::BeatJump;
            // The header needs one short, truthful mode name. The longer
            // description (including values/SHIFT actions) is not a header label.
            const std::string currentFocus=EncoderFocus::headerLabel(
                performanceMode,browsing,settingsOpen,gridEditing,
                waveformHoldTemporary || (gridEditing && touchGestures.waveformHeld(navEpoch)),
                waveformHoldBeat,fxSelection.selected);
            // LED frame is a pure UI-thread snapshot; presentation sends only
            // changed targets to the existing I2C worker atomics.
            const bool cueFlashLive=lastTriggeredCue>=0 &&
                Clock::now()-lastCueTriggerAt<std::chrono::milliseconds(650);
            const bool cueFlashBright=((ledMillis/130)%2)==0;
            ledPresenter.apply(encoder,UiLedController::render({
                navView,browsing,settingsOpen,cuesBank,&storedCues.slots(),
                bool(track),gridEditing,confirmingLiveLoad,confirmGridExit,
                cueFlashLive?lastTriggeredCue:-1,cueFlashBright,
                waveformHoldTemporary,waveformHoldBeat,
                performanceMode==PerformanceMode::Loop,performanceMode==PerformanceMode::Beat,
                waveformMoving,running,storedCue>=0,player && player->atTransportCue(),
                modulinoControls.shift(),modulinoControls.nudgeDirection(),
                static_cast<std::uint64_t>(ledMillis),uiSettings.knobLedLevel,
                fxSelection.selected,performanceMode==PerformanceMode::Fx,fxSelection.bypassed}));
            const double normalVisibleFrame=track && track->sampleRate>0 ?
                visualClock.sample(visual.precisePosition,visual.sourceFramesPerSecond,
                    transportMoving && !visual.awaitingFreshAudio,visual.visualSerial,
                    loop.active?static_cast<double>(loop.start):0.0,
                    loop.active?static_cast<double>(loop.end):0.0,
                    track->sampleRate*Settings::kVisualClockDiscontinuityMs*0.001,
                    Settings::kVisualClockCorrectionMs,Clock::now()) : 0.0;
            const double visibleFrame=scrubStarted? scrubDisplay.position(Clock::now()):normalVisibleFrame;
            const double seconds=track && track->sampleRate>0?visibleFrame/track->sampleRate:0;
            auto uiBeat=UiBeatClock::sample(seconds,
                track && track->beatGrid.estimated?track->beatGrid.bpm:0.0,
                track?track->beatGrid.firstBeatSeconds:0.0,running);
            // A stopped deck cannot generate local audible beat phase. For
            // linked BPM/BEAT status, a PLAYING peer with an authoritative
            // motion+grid may supply a musical beat reference instead. Never
            // invent a phase from elapsed wall time or packet cadence.
            if(!uiBeat.valid && linked.connected && linked.peerPlaying &&
               linked.peerMotionValid && linked.peerGridBpm>0.0 &&
               linked.remoteVisualClock.valid()) {
                uiBeat=UiBeatClock::sample(linked.remoteVisualClock.position(tick),
                    linked.peerGridBpm,linked.peerFirstBeatSeconds,true);
            }
            const auto autoPilotFrame=autoPilotIndicator.sample(
                tick,autoPilot.state(),planeVisible,uiBeat);
            // Loop-focused detail view: music-anchored waveform, moving
            // playhead. Overview remains full-track. Wait for an audible
            // uiSettings.quantized CUE handoff before locking to a recalled loop.
            auto loopCameraView=track?loopWaveCamera.sample(
                loop,seconds,track->sampleRate,zoomSeconds,
                uiSettings.centrePlayhead?Settings::kCentrePlayheadFraction:Settings::kExtendedPlayheadFraction,
                Ui::detailW,visual.pendingQuantizedJump,false,
                visual.pendingRelativeLoopMove || loop.boundarySlide):
                LoopWaveCamera::View{};
            if(track && touchGestures.loopDragHeld() && loopDragCameraAnchor.locked &&
               loopDragCameraAnchor.windowSeconds>0.0) {
                // Keep the waveform stationary during the drag; the actual
                // playhead keeps moving under the finger.
                loopCameraView=loopDragCameraAnchor;
                loopCameraView.playheadX=std::clamp(static_cast<int>(std::lround(
                    (seconds-loopCameraView.fromSeconds)/loopCameraView.windowSeconds*
                    (Ui::detailW-1))),0,Ui::detailW-1);
            } else if(loopCameraSettling && loopCameraSettleFrom.locked &&
                      loopCameraView.locked && loopCameraSettleFrom.windowSeconds>0) {
                // Smoothly pan to the relocated loop after finger release,
                // never visually teleport the playhead on UP. If the new end
                // is already behind audible playback, wait until the actual
                // old-cycle wrap before starting this camera pan.
                const bool waitingForWrap=loop.boundarySlide &&
                    (visibleFrame<static_cast<double>(loop.start) ||
                     visibleFrame>=static_cast<double>(loop.end));
                if(waitingForWrap)loopCameraSettleStart=Clock::now();
                const double t=waitingForWrap?0.0:std::clamp(
                    std::chrono::duration<double>(Clock::now()-loopCameraSettleStart).count()/0.4,
                    0.0,1.0);
                if(t>=1.0)loopCameraSettling=false;
                else {
                    const double ease=t*t*(3.0-2.0*t);
                    loopCameraView.fromSeconds=loopCameraSettleFrom.fromSeconds+
                        (loopCameraView.fromSeconds-loopCameraSettleFrom.fromSeconds)*ease;
                    loopCameraView.playheadX=std::clamp(static_cast<int>(std::lround(
                        (seconds-loopCameraView.fromSeconds)/loopCameraView.windowSeconds*
                        (Ui::detailW-1))),0,Ui::detailW-1);
                }
            } else if(!track || !loop.active || !loopCameraView.locked) {
                loopCameraSettling=false;
            }
            lastLoopTouchCamera=loopCameraView;

            // 0..255 beat-synchronous heart; sample clock and current grid only.
            // When stopped or grid unavailable it becomes black immediately.
            // LED reflects transport independently of on-screen HEART preference.
            // Browse/Settings overrides the encoder status temporarily. Detect
            // view-only changes without relying on the nav/full-frame redraw.
            const char* currentHeaderMode=currentFocus.c_str();
            if(sceneComposer.lastHeaderMode!=currentHeaderMode) encoderHeaderDirty=true;
            const int heartLevel=static_cast<int>(std::lround(
                255.0*UiBeatClock::heart(uiBeat,uiSettings.heartEnabled)));
            const double liveBpm=player?player->tempoBpm():0.0;
            // The blue follower BPM must track the MASTER's *changing* BPM,
            // not repaint only when lock first engages. Otherwise the value
            // can look frozen even while Player follows the new tempo.
            if((linkedTempoLocked || linkedTempoApplied) &&
               (previousLinkedDisplayedBpm<0 ||
                std::abs(liveBpm-previousLinkedDisplayedBpm)>0.035))
                bpmDirty=true;
            previousLinkedDisplayedBpm=liveBpm;
            if(loop.start!=lastLoopStart || loop.end!=lastLoopEnd ||
               loop.active!=lastLoopActive) {
                detailDirty=overviewDirty=true;
            }
            std::string playbackError=player?player->error():error;
            if(playbackError.empty() && metadata.unsaved() && !metadata.lastError().empty())
                playbackError="METADATA UNSAVED - CHECK STORAGE";
            else if(playbackError.empty() && metadata.rollbackPending())
                playbackError="ROLLBACK COPY PENDING";
            // Shared beat sample, independent of HEART visibility, and drawn
            // only in the tiny BPM region. Never start a synthetic oscillator.
            const bool musicalSyncPulse=uiSync.state==UiSyncPresentation::State::BpmApplied ||
                uiSync.state==UiSyncPresentation::State::BeatLocked;
            if(musicalSyncPulse && uiBeat.valid) {
                const auto pulseTick=std::chrono::duration_cast<std::chrono::milliseconds>(
                    tick.time_since_epoch()).count()/67;
                if(pulseTick!=lastUiBeatPulseTick) {
                    lastUiBeatPulseTick=pulseTick;
                    bpmDirty=true;
                }
            } else lastUiBeatPulseTick=-1;
            if(bpmPart()!=BpmEditPart::None) {
                // Only repaint the small BPM region at ~15 Hz; no waveform invalidation.
                const int tick=static_cast<int>(std::chrono::duration_cast<std::chrono::milliseconds>(
                    Clock::now().time_since_epoch()).count()/67);
                if(tick!=lastBpmPulseTick) {lastBpmPulseTick=tick;bpmDirty=true;}
            }
            if(debugHud.enabled())
                debugHud.tick(Clock::now(),player?player->alsaUnderruns():0);
            const auto priorDrawnFrames=performanceMonitor.drawnFrames;
            // UI scene composition owns full/dirty paints only. Input, ALSA,
            // metadata, UI pacing and the one KMS finishFrame stay here.
            const bool compactFooterRendered=UiSceneComposer::paint({
                canvas,*display,track.get(),player.get(),cache,waveTiles,contourWave,contourData,
                gridEditor,waveScene,browser,uiSettings,trackSession,debugHud,currentMetadata,
                path,error,viewState,performanceMonitor,
                lastClock,lastPosition,lastHeartLevel,lastPlaying,lastLoopActive,
                lastLoopStart,lastLoopEnd,wasBrowsing,wasSettingsOpen,lastOverview,
                liveWarningLastTick,sceneComposer.lastHeaderMode,
                navView,cuesBank,performanceMode,liveLoopBeats,beatJumpBeats,
                gridEditing,confirmGridExit,confirmingLiveLoad,proposedLoadIndex,
                browsing,settingsOpen,usbLost,library.usbReady(),usbBright,usbHeaderDirty,
                waveformVisible,frameDue,waveformMoving,running,revealingTrack,
                lastCueTriggerAt,liveWarningStart,
                seconds,zoomSeconds,ghostSeconds,gridVisibleStart,transportCueSeconds,
                revealFraction,heartLevel,liveBpm,position,loop,visual,loopCameraView,
                autoPilotFrame,usbIndicator,currentHeaderMode,
                bpmPart(),gridView(),cueVisuals(track?track->sampleRate:0),
                browserStatus(),std::string(autoPilotNotice.empty()?autoPilot.label():autoPilotNotice),playbackError,
                [&](MultitrackLayout::Mode mode){drawSeamlessWave(mode);}
#if defined(DECK001_B12_TRACE)
                ,&b12DetailRedrawn
#endif
                ,player?player->fxType():fxSelection.selected,
                player?player->fxAmount():fxSelection.amount(),
                fxSelection.bypassed,
                player?player->fxPeriodIndex():fxSelection.periodIndex(),
                waveformHoldTemporary?PerformanceMode::None:performanceMode,
                &keyShift,
                {linked.connected,linked.localMaster,linkedTempoLocked,linked.peerMaster,
                 linked.localMaster?linked.lockedFollowerCount>0:linkedTempoLocked,
                 linked.localMaster?(linked.tempoFollowerCount>0 && linked.lockedFollowerCount==0):
                     (linked.syncMode==DeckLink::SyncMode::Bpm && linkedTempoApplied),
                 beatSyncing,beatSyncLost,linked.staleWaveform,false,true,uiSync},
                linked,
                linkedTempoLocked,
                linkedTempoApplied,
                autoPilot.enabled(),autoPilot.inFlight(),
                preparedUpdate.valid?preparedUpdate.state:std::string{},
                preparedUpdate.valid?preparedUpdate.version:std::string{},
                pendingMacPair.valid()?pendingMacPair.code:std::string{},
                pendingMacPair.valid()?pendingMacPair.fingerprint:std::string{},
                devSourceEnabled,uiSettings.remoteViewMode,
                localLink.deviceNumber,
                uiBeat,uiSync
            });
            if(updateVisible) {
                DeckLinkUpdateUi::paint(canvas,preparedUpdate.version,
                    preparedUpdate.state,preparedUpdate.progress,preparedUpdate.detail);
                display->presentRect(canvas,DeckLinkUpdateUi::x,DeckLinkUpdateUi::y,
                    DeckLinkUpdateUi::w,DeckLinkUpdateUi::h);
            }
            // Animate just the plane region when the footer was not already
            // painted this frame. No waveform dirtying and no new frame timer.
            UiFrameRenderer::presentAutoPilotIcon(*display,canvas,autoPilotFrame,
                fullFrameAtStart||footerDirtyAtStart,compactFooterRendered);
            // Preserve the existing single KMS page-flip / frame boundary.
            const auto flipBegin=Settings::kPrintFps?Clock::now():Clock::time_point{};
            UiFrameRenderer::finishFrame(*display,animationActive);
            if(trackSession.loadMemory){
                const auto elapsed=std::chrono::duration_cast<std::chrono::microseconds>(
                    Clock::now()-tick).count();
                if(elapsed>0)trackSession.loadMemory->observeUiFrame(static_cast<std::uint64_t>(elapsed));
            }
            if(const auto firstMs=trackSession.firstVisible(bool(track),!browsing && !settingsOpen))
                std::cout<<"TRACK FIRST DISPLAY elapsed_ms="<<*firstMs<<'\n';
#if defined(DECK001_B12_TRACE)
            if(b12Trace.active() && player){
                b12Trace.sample(Clock::now(),player->b12VisualSnapshot(),visual,visibleFrame,
                    waveformMoving,cuePreviewActive,animationActive,frameDue,
                    b12DetailDirtyBefore,b12DetailRedrawn,display->lastFlipTimestampUs());
            }
#endif
            performanceMonitor.afterFlip({*display,debugHud,player.get(),track.get(),
                waveformVisible,cuePreviewActive,revealingTrack,trackSession.loadingTrack,
                browsing,settingsOpen,vblankPaced,priorDrawnFrames,
                flipBegin,Settings::kPrintFps?Clock::now():Clock::time_point{}});

        }
        player.reset(); // Close ALSA before restoring framebuffer.
    } catch(const std::exception& e) {
        std::cerr << "DECK 001 error: " << e.what() << '\n';
        return 1;
    }
    return 0;
}
