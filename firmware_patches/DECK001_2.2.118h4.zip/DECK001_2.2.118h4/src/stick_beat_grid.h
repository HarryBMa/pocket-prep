#pragma once
// v2.2.118h4: the beat grid a prep app (DKPRP, or rekordbox itself) wrote to the USB stick, so a prepared
// track needs no analysis on the deck. Read-only, no library: PIONEER/rekordbox/export.pdb maps the audio
// file to its ANLZ0000.DAT, whose PQTZ section lists every beat (bar position 1-4, time in ms).
// Any problem (no export, track not in it, missing / damaged file, a grid that is not one straight tempo)
// returns false and the deck analyses the track as before. Never call it on an audio callback.
#include <string>
#include <vector>

struct BeatGrid;

bool loadStickBeatGrid(const std::string& audioPath, BeatGrid& grid);

namespace StickBeatGrid {
struct Beat { int number = 0; double ms = 0; };                    // number: 1-4 position in the bar
// "/PIONEER/USBANLZ/.../ANLZ0000.DAT" for a track's "/Contents/..." path (case-insensitive), "" if none.
std::string anlzPathFor(const std::string& pdbFile, const std::string& trackPath);
bool readPqtz(const std::string& anlzFile, std::vector<Beat>& beats);
// One straight grid through the beats (max deviation 5 ms), bar line from the beats numbered 1.
bool gridFromBeats(const std::vector<Beat>& beats, BeatGrid& grid);
}  // namespace StickBeatGrid
